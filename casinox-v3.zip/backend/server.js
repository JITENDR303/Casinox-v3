require('dotenv').config();
const express    = require('express');
const http       = require('http');
const { Server } = require('socket.io');
const mongoose   = require('mongoose');
const cors       = require('cors');
const helmet     = require('helmet');
const rateLimit  = require('express-rate-limit');
const apiRouter  = require('./routes/api');
const gamesRouter= require('./routes/games');
const walletRouter= require('./routes/wallet');
const socketHandler = require('./socket/index');

const app    = express();
const server = http.createServer(app);
const allowedOrigins = [
  process.env.FRONTEND_URL || 'http://localhost:5000',
  'http://localhost:5000',
  /\.replit\.dev$/,
  /\.pike\.replit\.dev$/,
];

const io     = new Server(server, {
  cors: { origin: allowedOrigins, methods: ['GET','POST'], credentials: true },
  transports: ['websocket', 'polling'],
});

global.io = io; // available to webhook without req.app

// ─── Middleware ───────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: allowedOrigins, credentials: true }));

// Raw body for Razorpay webhook
app.use('/api/wallet/webhook/razorpay', express.raw({ type: 'application/json' }));
app.use(express.json({ limit: '5mb' }));

app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, max: 500, standardHeaders: true }));
app.use('/api/auth/', rateLimit({ windowMs: 15 * 60 * 1000, max: 30 }));
app.use('/api/games/', rateLimit({ windowMs: 60 * 1000, max: 120 })); // 2 bets/sec max

// ─── Routes ──────────────────────────────────────────────────
app.use('/api', apiRouter);
app.use('/api/games', gamesRouter);
app.use('/api/wallet', walletRouter);

app.get('/api/health', (req, res) => res.json({ status: 'ok', time: new Date(), uptime: process.uptime() }));

// Make io accessible in routes
app.set('io', io);

// ─── Socket ──────────────────────────────────────────────────
socketHandler(io);

// ─── MongoDB + Start ─────────────────────────────────────────
const PORT = process.env.PORT || 8000;

mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/casinox', {
  maxPoolSize: 10,
  serverSelectionTimeoutMS: 5000,
}).then(() => {
  console.log('✅ MongoDB connected');
  server.listen(PORT, () => console.log(`🎰 CasinoX v3 running → http://localhost:${PORT}`));
}).catch(err => {
  console.error('❌ MongoDB connection failed:', err.message);
  process.exit(1);
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down...');
  server.close();
  await mongoose.disconnect();
  process.exit(0);
});
