const jwt  = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    if (!token) return res.status(401).json({ error: 'No token' });

    const { id } = jwt.verify(token, process.env.JWT_SECRET);
    const user   = await User.findById(id);
    if (!user)          return res.status(401).json({ error: 'User not found' });
    if (user.isBanned)  return res.status(403).json({ error: 'Account banned' });

    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Invalid token' });
  }
};

const adminAuth = async (req, res, next) => {
  await auth(req, res, () => {
    if (!['admin', 'moderator'].includes(req.user.role))
      return res.status(403).json({ error: 'Admin access required' });
    next();
  });
};

module.exports = { auth, adminAuth };
