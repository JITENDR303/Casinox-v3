const mongoose = require('mongoose');

const transactionSchema = new mongoose.Schema({
  userId:        { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  type:          { type: String, enum: ['deposit','withdrawal','win','loss','bonus','refund','admin_credit','admin_debit','referral','daily_reward'], required: true },
  amount:        { type: Number, required: true },
  balanceBefore: { type: Number },
  balanceAfter:  { type: Number },
  game:          { type: String, default: null },
  description:   { type: String, default: '' },
  meta:          { type: mongoose.Schema.Types.Mixed, default: {} },
}, { timestamps: true });

transactionSchema.index({ userId: 1, createdAt: -1 });
transactionSchema.index({ type: 1 });

module.exports = mongoose.model('Transaction', transactionSchema);
