const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');

const userSchema = new mongoose.Schema({
  username:        { type: String, required: true, unique: true, trim: true, lowercase: true, minlength: 3, maxlength: 20 },
  email:           { type: String, required: true, unique: true, trim: true, lowercase: true },
  passwordHash:    { type: String, required: true },
  balance:         { type: Number, default: 100, min: 0 },
  bonusBalance:    { type: Number, default: 0, min: 0 },
  role:            { type: String, enum: ['user', 'admin', 'moderator'], default: 'user' },
  avatarSeed:      { type: String, default: () => Math.random().toString(36).slice(2) },

  // VIP / XP
  xp:              { type: Number, default: 0 },
  vipLevel:        { type: Number, default: 0, min: 0, max: 5 },
  totalWagered:    { type: Number, default: 0 },
  totalWon:        { type: Number, default: 0 },
  totalDeposited:  { type: Number, default: 0 },
  totalWithdrawn:  { type: Number, default: 0 },

  // Referral
  referralCode:    { type: String, unique: true, sparse: true },
  referredBy:      { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  referralEarnings:{ type: Number, default: 0 },

  // Daily rewards
  lastDailyReward: { type: Date, default: null },
  dailyStreak:     { type: Number, default: 0 },

  // Status
  isBanned:        { type: Boolean, default: false },
  banReason:       { type: String, default: '' },
  lastSeen:        { type: Date, default: Date.now },

  // Provably fair
  clientSeed:      { type: String, default: () => crypto.randomBytes(16).toString('hex') },
  serverSeedHash:  { type: String, default: '' },
  nonce:           { type: Number, default: 0 },
}, { timestamps: true });

// Indexes
userSchema.index({ username: 1 });
userSchema.index({ email: 1 });
userSchema.index({ referralCode: 1 });
userSchema.index({ totalWagered: -1 });

// Hash password
userSchema.pre('save', async function (next) {
  if (!this.isModified('passwordHash')) return next();
  this.passwordHash = await bcrypt.hash(this.passwordHash, 12);
  next();
});

// Generate referral code
userSchema.pre('save', function (next) {
  if (!this.referralCode) {
    this.referralCode = crypto.randomBytes(4).toString('hex').toUpperCase();
  }
  next();
});

userSchema.methods.comparePassword = function (pwd) {
  return bcrypt.compare(pwd, this.passwordHash);
};

// Update VIP level based on total wagered
userSchema.methods.updateVIP = function () {
  const thresholds = [0, 1000, 10000, 50000, 200000, 1000000];
  for (let i = thresholds.length - 1; i >= 0; i--) {
    if (this.totalWagered >= thresholds[i]) {
      this.vipLevel = i;
      break;
    }
  }
};

userSchema.methods.toSafe = function () {
  const obj = this.toObject();
  delete obj.passwordHash;
  delete obj.__v;
  return obj;
};

module.exports = mongoose.model('User', userSchema);
