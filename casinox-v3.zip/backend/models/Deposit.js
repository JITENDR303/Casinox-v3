const mongoose = require('mongoose');

const depositSchema = new mongoose.Schema({
  userId:          { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  amount:          { type: Number, required: true },
  status:          { type: String, enum: ['pending','submitted','processing','approved','rejected','expired'], default: 'pending', index: true },

  // UPI manual
  upiId:           { type: String, default: '' },
  transactionId:   { type: String, default: '', index: true },
  screenshotUrl:   { type: String, default: '' },

  // Razorpay / Cashfree
  gatewayOrderId:  { type: String, default: '', index: true },
  gatewayPaymentId:{ type: String, default: '' },
  gatewaySignature:{ type: String, default: '' },
  gateway:         { type: String, enum: ['manual','razorpay','cashfree'], default: 'manual' },

  // Admin
  adminNote:       { type: String, default: '' },
  reviewedBy:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  reviewedAt:      { type: Date, default: null },

  expiresAt:       { type: Date, default: () => new Date(Date.now() + 30 * 60 * 1000) }, // 30 min
}, { timestamps: true });

depositSchema.index({ userId: 1, createdAt: -1 });
depositSchema.index({ transactionId: 1 }, { sparse: true });

module.exports = mongoose.model('Deposit', depositSchema);
