const mongoose = require('mongoose');

const gameSessionSchema = new mongoose.Schema({
  userId:      { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  gameType:    { type: String, required: true, index: true },
  betAmount:   { type: Number, required: true },
  multiplier:  { type: Number, default: 0 },
  payout:      { type: Number, default: 0 },
  profit:      { type: Number, default: 0 },
  won:         { type: Boolean, default: false },
  result:      { type: mongoose.Schema.Types.Mixed, default: {} },
  active:      { type: Boolean, default: false },
  // Provably fair
  serverSeed:  { type: String, default: '' },
  clientSeed:  { type: String, default: '' },
  nonce:       { type: Number, default: 0 },
  hash:        { type: String, default: '' },
}, { timestamps: true });

gameSessionSchema.index({ userId: 1, createdAt: -1 });
gameSessionSchema.index({ gameType: 1, createdAt: -1 });
gameSessionSchema.index({ won: 1, createdAt: -1 });

module.exports = mongoose.model('GameSession', gameSessionSchema);
