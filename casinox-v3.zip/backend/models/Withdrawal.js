const mongoose = require('mongoose');

const withdrawalSchema = new mongoose.Schema({
  userId:    { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
  amount:    { type: Number, required: true },
  fee:       { type: Number, default: 0 },
  netAmount: { type: Number },      // amount - fee
  upiId:     { type: String, required: true },
  status:    { type: String, enum: ['pending','approved','rejected','processing'], default: 'pending', index: true },
  adminNote: { type: String, default: '' },
  reviewedBy:{ type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  reviewedAt:{ type: Date, default: null },
}, { timestamps: true });

withdrawalSchema.index({ userId: 1, createdAt: -1 });
withdrawalSchema.pre('save', function (next) {
  const FEE_RATE = 0.02; // 2% fee
  this.fee = parseFloat((this.amount * FEE_RATE).toFixed(2));
  this.netAmount = parseFloat((this.amount - this.fee).toFixed(2));
  next();
});

module.exports = mongoose.model('Withdrawal', withdrawalSchema);
