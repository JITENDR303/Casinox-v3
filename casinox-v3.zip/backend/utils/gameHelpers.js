const User = require('../models/User');
const Transaction = require('../models/Transaction');
const GameSession = require('../models/GameSession');

/**
 * Atomically update user balance and log transaction.
 * Returns the updated balance.
 */
async function updateBalance(userId, amount, type, game, description, session = null) {
  const opts = session ? { session } : {};

  const user = await User.findById(userId).session(session || null);
  if (!user) throw new Error('User not found');

  const before = user.balance;
  const after  = parseFloat((before + amount).toFixed(2));

  if (after < 0) throw new Error('Insufficient balance');

  user.balance = after;
  if (type === 'loss' || type === 'wager') {
    user.totalWagered += Math.abs(amount);
    user.xp += Math.floor(Math.abs(amount) * 0.1); // XP for wagering
  }
  if (type === 'win') {
    user.totalWon += amount;
  }
  user.updateVIP();
  await user.save(opts);

  await Transaction.create([{
    userId,
    type,
    amount,
    balanceBefore: before,
    balanceAfter: after,
    game,
    description,
  }], opts.session ? { session } : {});

  return after;
}

/**
 * Calculate mines multiplier for N safe tiles revealed out of 25 - mineCount
 */
function calcMinesMultiplier(totalMines, safeRevealed) {
  if (safeRevealed === 0) return 1;
  let mult = 1;
  for (let i = 0; i < safeRevealed; i++) {
    const safeTilesLeft = 25 - totalMines - i;
    const tilesLeft = 25 - i;
    mult *= tilesLeft / safeTilesLeft;
  }
  return parseFloat((mult * 0.97).toFixed(4));
}

/**
 * Keno multiplier table based on picks and hits
 */
const KENO_MULTIPLIERS = {
  1:  { 0: 0, 1: 3.8 },
  2:  { 0: 0, 1: 1,   2: 11 },
  3:  { 0: 0, 1: 0.5, 2: 3,   3: 47 },
  4:  { 0: 0, 1: 0,   2: 2,   3: 9,   4: 100 },
  5:  { 0: 0, 1: 0,   2: 1.5, 3: 4,   4: 20,  5: 310 },
  6:  { 0: 0, 1: 0,   2: 1,   3: 2,   4: 7,   5: 50,  6: 750 },
  7:  { 0: 0, 1: 0,   2: 0.5, 3: 1.5, 4: 4,   5: 15,  6: 120, 7: 2500 },
  8:  { 0: 0, 1: 0,   2: 0.5, 3: 1,   4: 3,   5: 9,   6: 50,  7: 500,  8: 10000 },
  9:  { 0: 0, 1: 0,   2: 0,   3: 0.5, 4: 2,   5: 4,   6: 20,  7: 100,  8: 2000, 9: 25000 },
  10: { 0: 0, 1: 0,   2: 0,   3: 0.5, 4: 1.5, 5: 3.5, 6: 10,  7: 50,   8: 500,  9: 5000, 10: 100000 },
};

function getKenoMultiplier(picks, hits) {
  return KENO_MULTIPLIERS[picks]?.[hits] || 0;
}

/**
 * Hilo card value (for comparison)
 */
function cardRank(rank) {
  const map = { '2':2,'3':3,'4':4,'5':5,'6':6,'7':7,'8':8,'9':9,'10':10,'J':11,'Q':12,'K':13,'A':14 };
  return map[rank] || 0;
}

module.exports = { updateBalance, calcMinesMultiplier, getKenoMultiplier, cardRank };
