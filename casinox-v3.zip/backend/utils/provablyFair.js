const crypto = require('crypto');

/**
 * Provably Fair System
 *
 * Verification flow:
 * 1. Server generates serverSeed and gives user the SHA256 hash BEFORE game
 * 2. User optionally sets clientSeed
 * 3. After game, server reveals serverSeed — user can verify
 *
 * Combined: HMAC-SHA256(serverSeed, clientSeed:nonce)
 */

// Generate a new server seed
function generateServerSeed() {
  return crypto.randomBytes(32).toString('hex');
}

// Hash for public commitment
function hashServerSeed(serverSeed) {
  return crypto.createHash('sha256').update(serverSeed).digest('hex');
}

// Generate random float 0..1 from seeds
function generateFloat(serverSeed, clientSeed, nonce) {
  const hmac = crypto.createHmac('sha256', serverSeed);
  hmac.update(`${clientSeed}:${nonce}`);
  const hash = hmac.digest('hex');

  // Use first 8 hex chars → 32-bit number → 0..1
  const dec = parseInt(hash.slice(0, 8), 16);
  return dec / 0xffffffff;
}

// Generate an integer in [min, max]
function generateInt(serverSeed, clientSeed, nonce, min, max) {
  const f = generateFloat(serverSeed, clientSeed, nonce);
  return Math.floor(f * (max - min + 1)) + min;
}

// Generate dice roll 0..100
function generateDiceRoll(serverSeed, clientSeed, nonce) {
  return parseFloat((generateFloat(serverSeed, clientSeed, nonce) * 100).toFixed(2));
}

// Generate crash point using bust multiplier formula
function generateCrashPoint(serverSeed, clientSeed, nonce) {
  const r = generateFloat(serverSeed, clientSeed, nonce);
  if (r < 0.04) return 1.00; // 4% instant crash
  return parseFloat(Math.max(1.00, (0.99 / r)).toFixed(2));
}

// Generate mine positions (count mines in 25 grid)
function generateMinePositions(serverSeed, clientSeed, nonce, mineCount) {
  const positions = Array.from({ length: 25 }, (_, i) => i);
  // Fisher-Yates using provably fair floats
  for (let i = positions.length - 1; i > 0; i--) {
    const f = generateFloat(serverSeed, clientSeed, nonce + i);
    const j = Math.floor(f * (i + 1));
    [positions[i], positions[j]] = [positions[j], positions[i]];
  }
  return positions.slice(0, mineCount);
}

// Generate deck shuffle
function generateDeckShuffle(serverSeed, clientSeed, nonce) {
  const deck = [];
  const suits = ['♠', '♥', '♦', '♣'];
  const ranks = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
  for (const suit of suits) for (const rank of ranks) deck.push({ rank, suit });

  for (let i = deck.length - 1; i > 0; i--) {
    const f = generateFloat(serverSeed, clientSeed, nonce + i);
    const j = Math.floor(f * (i + 1));
    [deck[i], deck[j]] = [deck[j], deck[i]];
  }
  return deck;
}

// Generate keno draw (20 numbers from 1-80)
function generateKenoDraw(serverSeed, clientSeed, nonce, count = 20) {
  const pool = Array.from({ length: 80 }, (_, i) => i + 1);
  const drawn = [];
  for (let i = pool.length - 1; i > pool.length - 1 - count; i--) {
    const f = generateFloat(serverSeed, clientSeed, nonce + (pool.length - 1 - i));
    const j = Math.floor(f * (i + 1));
    [pool[i], pool[j]] = [pool[j], pool[i]];
    drawn.push(pool[i]);
  }
  return drawn.sort((a, b) => a - b);
}

// Verify: given serverSeed, clientSeed, nonce → compute expected result
function verify(serverSeed, clientSeed, nonce, gameType) {
  const hash = hashServerSeed(serverSeed);
  let result;
  switch (gameType) {
    case 'dice':   result = generateDiceRoll(serverSeed, clientSeed, nonce); break;
    case 'crash':  result = generateCrashPoint(serverSeed, clientSeed, nonce); break;
    case 'limbo':  result = generateFloat(serverSeed, clientSeed, nonce); break;
    default:       result = generateFloat(serverSeed, clientSeed, nonce);
  }
  return { serverSeed, clientSeed, nonce, hash, result };
}

module.exports = {
  generateServerSeed,
  hashServerSeed,
  generateFloat,
  generateInt,
  generateDiceRoll,
  generateCrashPoint,
  generateMinePositions,
  generateDeckShuffle,
  generateKenoDraw,
  verify,
};
