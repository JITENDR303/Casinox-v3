const jwt  = require('jsonwebtoken');
const User = require('../models/User');
const GameSession = require('../models/GameSession');
const pf   = require('../utils/provablyFair');

module.exports = (io) => {
  let crashState = { phase: 'waiting', multiplier: 1.0, crashAt: 2.0, roundId: null, startTime: null, players: {} };
  let crashInterval = null;

  function nextCrashPoint() {
    return pf.generateCrashPoint(pf.generateServerSeed(), pf.generateServerSeed(), 1);
  }

  async function processCashout(socketId, player, mult) {
    if (player.cashedOut) return;
    player.cashedOut = true; player.cashoutAt = mult;
    const payout = parseFloat((player.bet * mult).toFixed(2));
    try {
      const u = await User.findByIdAndUpdate(player.userId, { $inc: { balance: payout, totalWon: payout } }, { new: true });
      await GameSession.create({ userId: player.userId, gameType: 'crash', betAmount: player.bet, multiplier: mult, payout, profit: payout - player.bet, won: true, result: { cashoutAt: mult, crashAt: crashState.crashAt } });
      io.to(socketId).emit('crash:cashedout', { multiplier: mult, payout, balance: u?.balance });
      io.emit('crash:playercashout', { username: player.username, multiplier: mult, payout });
      io.emit('live:bet', { game: 'crash', username: player.username, bet: player.bet, payout, multiplier: mult, won: true });
    } catch (e) { console.error('cashout err:', e.message); }
  }

  function startCrashRound() {
    crashState = { phase: 'waiting', multiplier: 1.0, crashAt: nextCrashPoint(), roundId: `${Date.now()}`, startTime: null, players: {} };
    io.emit('crash:waiting', { roundId: crashState.roundId, countdown: 7 });
    let cd = 7;
    const cdt = setInterval(() => { io.emit('crash:countdown', { countdown: --cd }); if (cd <= 0) clearInterval(cdt); }, 1000);

    setTimeout(() => {
      crashState.phase = 'running'; crashState.startTime = Date.now();
      io.emit('crash:start', { roundId: crashState.roundId });
      crashInterval = setInterval(async () => {
        const elapsed = (Date.now() - crashState.startTime) / 1000;
        crashState.multiplier = parseFloat(Math.pow(Math.E, 0.09 * elapsed).toFixed(2));
        for (const [sid, p] of Object.entries(crashState.players)) {
          if (!p.cashedOut && p.autoCashout && crashState.multiplier >= p.autoCashout) await processCashout(sid, p, p.autoCashout);
        }
        io.emit('crash:tick', { multiplier: crashState.multiplier });
        if (crashState.multiplier >= crashState.crashAt) {
          clearInterval(crashInterval);
          crashState.phase = 'crashed';
          io.emit('crash:crash', { crashAt: crashState.crashAt });
          for (const [, p] of Object.entries(crashState.players)) {
            if (!p.cashedOut) GameSession.create({ userId: p.userId, gameType: 'crash', betAmount: p.bet, multiplier: 0, payout: 0, profit: -p.bet, won: false, result: { crashAt: crashState.crashAt } }).catch(() => {});
          }
          setTimeout(startCrashRound, 5000);
        }
      }, 100);
    }, 7000);
  }

  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (token) { try { socket.userId = jwt.verify(token, process.env.JWT_SECRET).id; } catch {} }
    next();
  });

  io.on('connection', async (socket) => {
    socket.emit('crash:state', { phase: crashState.phase, multiplier: crashState.multiplier, roundId: crashState.roundId, players: Object.values(crashState.players).map(p => ({ username: p.username, bet: p.bet })) });
    if (socket.userId) socket.join(`user:${socket.userId}`);
    io.emit('online:count', { count: io.engine.clientsCount });

    socket.on('chat:send', async ({ message }) => {
      if (!socket.userId || !message?.trim()) return;
      const user = await User.findById(socket.userId).select('username avatarSeed vipLevel').lean();
      if (!user) return;
      io.emit('chat:message', { userId: socket.userId, username: user.username, avatarSeed: user.avatarSeed, vipLevel: user.vipLevel, message: message.trim().slice(0, 200), ts: Date.now() });
    });

    socket.on('crash:bet', async ({ betAmount, autoCashout }) => {
      if (!socket.userId || crashState.phase !== 'waiting' || crashState.players[socket.id]) return;
      const bet = parseFloat(betAmount);
      if (isNaN(bet) || bet < 1) return;
      const user = await User.findById(socket.userId);
      if (!user || user.balance < bet) { socket.emit('crash:error', { message: 'Insufficient balance' }); return; }
      await User.findByIdAndUpdate(socket.userId, { $inc: { balance: -bet, totalWagered: bet } });
      crashState.players[socket.id] = { userId: socket.userId, username: user.username, bet, autoCashout: autoCashout ? parseFloat(autoCashout) : null, cashedOut: false };
      socket.emit('crash:betplaced', { bet, balance: parseFloat((user.balance - bet).toFixed(2)) });
      io.emit('crash:players', { count: Object.keys(crashState.players).length, players: Object.values(crashState.players).map(p => ({ username: p.username, bet: p.bet })) });
    });

    socket.on('crash:cashout', async () => {
      const p = crashState.players[socket.id];
      if (!p || p.cashedOut || crashState.phase !== 'running') return;
      await processCashout(socket.id, p, crashState.multiplier);
    });

    socket.on('disconnect', () => {
      delete crashState.players[socket.id];
      io.emit('online:count', { count: io.engine.clientsCount });
    });
  });

  startCrashRound();
};
