const express = require('express');
const router  = express.Router();
const jwt     = require('jsonwebtoken');
const User    = require('../models/User');
const GameSession = require('../models/GameSession');
const Transaction  = require('../models/Transaction');
const { auth, adminAuth } = require('../middleware/auth');
const { updateBalance } = require('../utils/gameHelpers');

// ══════════════════════════════════════════════════════════════
// AUTH
// ══════════════════════════════════════════════════════════════
router.post('/auth/register', async (req, res) => {
  try {
    const { username, email, password, referralCode } = req.body;
    if (!username || !email || !password)
      return res.status(400).json({ error: 'All fields required' });
    if (username.length < 3 || username.length > 20)
      return res.status(400).json({ error: 'Username must be 3–20 characters' });
    if (password.length < 6)
      return res.status(400).json({ error: 'Password must be at least 6 characters' });

    // Find referrer
    let referrerId = null;
    if (referralCode) {
      const ref = await User.findOne({ referralCode: referralCode.toUpperCase() });
      if (ref) referrerId = ref._id;
    }

    const user = new User({ username, email, passwordHash: password, referredBy: referrerId });
    await user.save();

    // Give referrer bonus
    if (referrerId) {
      await updateBalance(referrerId, 25, 'referral', null, `Referral bonus — ${username} joined`);
      await User.findByIdAndUpdate(referrerId, { $inc: { referralEarnings: 25 } });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: user.toSafe() });
  } catch (e) {
    if (e.code === 11000) return res.status(400).json({ error: 'Username or email already taken' });
    console.error(e);
    res.status(500).json({ error: 'Registration failed' });
  }
});

router.post('/auth/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    const user = await User.findOne({
      $or: [{ username: username?.toLowerCase() }, { email: username?.toLowerCase() }]
    });
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });
    if (user.isBanned) return res.status(403).json({ error: `Account banned: ${user.banReason || 'Contact support'}` });

    const valid = await user.comparePassword(password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });

    user.lastSeen = new Date();
    await user.save();

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '7d' });
    res.json({ token, user: user.toSafe() });
  } catch (e) {
    res.status(500).json({ error: 'Login failed' });
  }
});

router.get('/auth/me', auth, (req, res) => res.json({ user: req.user.toSafe ? req.user.toSafe() : req.user }));

router.post('/auth/change-password', auth, async (req, res) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = await User.findById(req.user._id);
    if (!await user.comparePassword(currentPassword)) return res.status(400).json({ error: 'Current password incorrect' });
    if (newPassword.length < 6) return res.status(400).json({ error: 'Password too short' });
    user.passwordHash = newPassword;
    await user.save();
    res.json({ message: 'Password updated' });
  } catch (e) { res.status(500).json({ error: 'Failed' }); }
});

router.post('/auth/seed', auth, async (req, res) => {
  const { clientSeed } = req.body;
  if (!clientSeed || clientSeed.length < 6) return res.status(400).json({ error: 'Seed too short (min 6)' });
  await User.findByIdAndUpdate(req.user._id, { clientSeed, nonce: 0 });
  res.json({ message: 'Seed updated', clientSeed });
});

// ══════════════════════════════════════════════════════════════
// ADMIN
// ══════════════════════════════════════════════════════════════
router.get('/admin/stats', adminAuth, async (req, res) => {
  try {
    const [
      totalUsers, todayUsers, activeUsers,
      allSessions, todaySessions,
    ] = await Promise.all([
      User.countDocuments(),
      User.countDocuments({ createdAt: { $gte: new Date(Date.now() - 24*60*60*1000) } }),
      User.countDocuments({ lastSeen: { $gte: new Date(Date.now() - 5*60*1000) } }),
      Transaction.aggregate([
        { $group: { _id: '$type', total: { $sum: '$amount' }, count: { $sum: 1 } } }
      ]),
      GameSession.aggregate([
        { $match: { createdAt: { $gte: new Date(Date.now() - 24*60*60*1000) } } },
        { $group: { _id: null, wagered: { $sum: '$betAmount' }, paid: { $sum: '$payout' }, count: { $sum: 1 } } }
      ]),
    ]);

    const txMap = {};
    allSessions.forEach(t => { txMap[t._id] = t; });

    const deposits    = (txMap['deposit']?.total || 0);
    const withdrawals = Math.abs(txMap['withdrawal']?.total || 0);
    const today       = todaySessions[0] || { wagered: 0, paid: 0, count: 0 };

    res.json({
      users:       { total: totalUsers, today: todayUsers, active: activeUsers },
      deposits:    { volume: deposits, count: txMap['deposit']?.count || 0 },
      withdrawals: { volume: withdrawals, count: txMap['withdrawal']?.count || 0 },
      profit:      parseFloat((deposits - withdrawals).toFixed(2)),
      games:       { today: today.count, wagered: today.wagered, paid: today.paid },
      houseEdge:   parseFloat(((today.wagered - today.paid) / (today.wagered || 1) * 100).toFixed(2)),
    });
  } catch (e) { res.status(500).json({ error: 'Failed' }); }
});

router.get('/admin/users', adminAuth, async (req, res) => {
  const { search = '', page = 1 } = req.query;
  const query = search ? { $or: [{ username: new RegExp(search, 'i') }, { email: new RegExp(search, 'i') }] } : {};
  const users = await User.find(query)
    .select('-passwordHash -serverSeedHash -clientSeed')
    .sort({ createdAt: -1 }).skip((page-1)*50).limit(50).lean();
  res.json({ users });
});

router.post('/admin/users/:id/balance', adminAuth, async (req, res) => {
  try {
    const { amount, reason } = req.body;
    const newBal = await updateBalance(req.params.id, parseFloat(amount), amount > 0 ? 'admin_credit' : 'admin_debit', null, reason || 'Admin adjustment');
    const io = req.app.get('io');
    if (io) io.to(`user:${req.params.id}`).emit('balance:update', { balance: newBal });
    res.json({ newBalance: newBal });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.post('/admin/users/:id/ban', adminAuth, async (req, res) => {
  const { ban, reason } = req.body;
  await User.findByIdAndUpdate(req.params.id, { isBanned: ban, banReason: reason || '' });
  res.json({ message: ban ? 'User banned' : 'User unbanned' });
});

router.post('/admin/users/:id/role', adminAuth, async (req, res) => {
  const { role } = req.body;
  if (!['user','admin','moderator'].includes(role)) return res.status(400).json({ error: 'Invalid role' });
  await User.findByIdAndUpdate(req.params.id, { role });
  res.json({ message: 'Role updated' });
});

router.get('/admin/games', adminAuth, async (req, res) => {
  const { game, page = 1 } = req.query;
  const query = game ? { gameType: game } : {};
  const sessions = await GameSession.find(query)
    .sort({ createdAt: -1 }).skip((page-1)*50).limit(50)
    .populate('userId', 'username').lean();
  res.json({ sessions });
});

module.exports = router;
