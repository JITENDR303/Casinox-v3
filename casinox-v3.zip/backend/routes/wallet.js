const express   = require('express');
const router    = express.Router();
const crypto    = require('crypto');
const User       = require('../models/User');
const Deposit    = require('../models/Deposit');
const Withdrawal = require('../models/Withdrawal');
const Transaction= require('../models/Transaction');
const { auth, adminAuth } = require('../middleware/auth');
const { updateBalance } = require('../utils/gameHelpers');

const ALLOWED_AMOUNTS = [10, 20, 50, 100, 500, 1000, 2000];
const MIN_WITHDRAW    = 100;
const MAX_WITHDRAW    = 10000;
const WITHDRAWAL_FEE  = 0.02; // 2%

// ─── Wallet overview ────────────────────────────────────────
router.get('/overview', auth, async (req, res) => {
  const [deposits, withdrawals, transactions] = await Promise.all([
    Deposit.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(20).lean(),
    Withdrawal.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(20).lean(),
    Transaction.find({ userId: req.user._id }).sort({ createdAt: -1 }).limit(30).lean(),
  ]);
  res.json({
    balance:      req.user.balance,
    bonusBalance: req.user.bonusBalance,
    deposits, withdrawals, transactions,
  });
});

// ─── Daily reward ────────────────────────────────────────────
router.post('/daily-reward', auth, async (req, res) => {
  const user = await User.findById(req.user._id);
  const now  = new Date();
  const last = user.lastDailyReward;

  const isSameDay = last && (now - last) < 24 * 60 * 60 * 1000 &&
    last.getDate() === now.getDate();

  if (isSameDay) {
    const nextReward = new Date(last.getTime() + 24 * 60 * 60 * 1000);
    return res.status(400).json({ error: 'Already claimed today', nextReward });
  }

  const daysSinceLast = last ? Math.floor((now - last) / (24 * 60 * 60 * 1000)) : 1;
  const streak        = daysSinceLast === 1 ? (user.dailyStreak + 1) : 1;

  // Streak-based reward
  const baseReward   = 10;
  const streakBonus  = Math.min(streak * 5, 50); // cap at ₹50 bonus
  const vipBonus     = user.vipLevel * 5;
  const rewardAmount = parseFloat((baseReward + streakBonus + vipBonus).toFixed(2));

  user.lastDailyReward = now;
  user.dailyStreak     = streak;
  await user.save();

  const newBal = await updateBalance(user._id, rewardAmount, 'daily_reward', null, `Daily reward (streak ${streak})`);

  const io = req.app.get('io');
  if (io) io.to(`user:${user._id}`).emit('balance:update', { balance: newBal });

  res.json({ reward: rewardAmount, streak, balance: newBal, nextReward: new Date(now.getTime() + 24 * 60 * 60 * 1000) });
});

// ─── UPI Deposit — Initiate ───────────────────────────────────
router.post('/deposit/initiate', auth, async (req, res) => {
  try {
    const { amount } = req.body;
    const amt = parseFloat(amount);
    if (!ALLOWED_AMOUNTS.includes(amt))
      return res.status(400).json({ error: 'Invalid deposit amount' });

    // Prevent spam — max 3 pending per hour
    const pendingCount = await Deposit.countDocuments({
      userId: req.user._id,
      status: { $in: ['pending', 'submitted'] },
      createdAt: { $gte: new Date(Date.now() - 60 * 60 * 1000) },
    });
    if (pendingCount >= 3)
      return res.status(400).json({ error: 'Too many pending deposits. Please wait.' });

    const deposit = await Deposit.create({
      userId: req.user._id,
      amount: amt,
      gateway: 'manual',
      status: 'pending',
    });

    const upiId   = process.env.UPI_ID   || 'casinox@upi';
    const upiName = process.env.UPI_NAME  || 'CasinoX';
    const txnNote = `CX-${deposit._id.toString().slice(-8).toUpperCase()}`;
    const upiLink = `upi://pay?pa=${upiId}&pn=${encodeURIComponent(upiName)}&am=${amt}&cu=INR&tn=${txnNote}`;

    res.json({ deposit, upiId, upiName, upiLink, txnNote, allowedAmounts: ALLOWED_AMOUNTS });
  } catch (e) {
    res.status(500).json({ error: 'Failed to initiate deposit' });
  }
});

// ─── UPI Deposit — Submit proof ───────────────────────────────
router.post('/deposit/submit', auth, async (req, res) => {
  try {
    const { depositId, transactionId, upiId, screenshotUrl } = req.body;
    if (!depositId || !transactionId?.trim())
      return res.status(400).json({ error: 'Transaction ID required' });

    // Validate screenshot size if provided (max ~2MB base64)
    if (screenshotUrl && screenshotUrl.length > 2_800_000)
      return res.status(400).json({ error: 'Screenshot too large. Please use a smaller image.' });

    // Check duplicate txn ID
    const dup = await Deposit.findOne({ transactionId: transactionId.trim(), status: { $ne: 'rejected' } });
    if (dup) return res.status(400).json({ error: 'This Transaction ID already submitted' });

    const deposit = await Deposit.findOneAndUpdate(
      { _id: depositId, userId: req.user._id, status: 'pending' },
      { transactionId: transactionId.trim(), upiId: upiId || '', screenshotUrl: screenshotUrl || '', status: 'submitted' },
      { new: true }
    );
    if (!deposit) return res.status(404).json({ error: 'Deposit not found or already processed' });

    const io = req.app.get('io');
    if (io) io.emit('admin:newDeposit', { userId: req.user._id.toString(), amount: deposit.amount, depositId: deposit._id });

    res.json({ message: 'Deposit submitted! Balance credited after admin verification (usually within 30 min).', deposit });
  } catch (e) {
    res.status(500).json({ error: 'Submission failed' });
  }
});

// ─── Razorpay: Create order ───────────────────────────────────
router.post('/deposit/razorpay/create', auth, async (req, res) => {
  try {
    if (!process.env.RAZORPAY_KEY_ID) return res.status(400).json({ error: 'Razorpay not configured' });

    const Razorpay = require('razorpay');
    const rzp = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_SECRET });

    const { amount } = req.body;
    const amt = parseFloat(amount);
    if (!ALLOWED_AMOUNTS.includes(amt)) return res.status(400).json({ error: 'Invalid amount' });

    const order = await rzp.orders.create({
      amount: amt * 100, // paise
      currency: 'INR',
      receipt: `cx_${req.user._id}_${Date.now()}`,
    });

    const deposit = await Deposit.create({
      userId: req.user._id,
      amount: amt,
      gateway: 'razorpay',
      gatewayOrderId: order.id,
      status: 'pending',
    });

    res.json({ orderId: order.id, depositId: deposit._id, amount: amt, keyId: process.env.RAZORPAY_KEY_ID, username: req.user.username, email: req.user.email });
  } catch (e) {
    console.error('Razorpay create order error:', e);
    res.status(500).json({ error: 'Failed to create payment order' });
  }
});

// ─── Razorpay: Verify payment ────────────────────────────────
router.post('/deposit/razorpay/verify', auth, async (req, res) => {
  try {
    const { depositId, razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;

    // Verify signature
    const expectedSig = crypto
      .createHmac('sha256', process.env.RAZORPAY_SECRET)
      .update(`${razorpay_order_id}|${razorpay_payment_id}`)
      .digest('hex');

    if (expectedSig !== razorpay_signature)
      return res.status(400).json({ error: 'Invalid payment signature' });

    // Prevent double-credit
    const existing = await Deposit.findOne({ gatewayPaymentId: razorpay_payment_id });
    if (existing) return res.status(400).json({ error: 'Payment already processed' });

    const deposit = await Deposit.findOneAndUpdate(
      { _id: depositId, userId: req.user._id, status: 'pending' },
      { gatewayPaymentId: razorpay_payment_id, gatewaySignature: razorpay_signature, status: 'approved', reviewedAt: new Date() },
      { new: true }
    );
    if (!deposit) return res.status(404).json({ error: 'Deposit not found' });

    // Credit balance
    const newBal = await updateBalance(req.user._id, deposit.amount, 'deposit', null, 'Razorpay deposit');
    await User.findByIdAndUpdate(req.user._id, { $inc: { totalDeposited: deposit.amount } });

    const io = req.app.get('io');
    if (io) io.to(`user:${req.user._id}`).emit('balance:update', { balance: newBal });

    res.json({ message: '✅ Payment verified! Balance credited.', balance: newBal });
  } catch (e) {
    console.error('Razorpay verify error:', e);
    res.status(500).json({ error: 'Payment verification failed' });
  }
});

// ─── Razorpay Webhook ────────────────────────────────────────
router.post('/webhook/razorpay', express.raw({ type: 'application/json' }), async (req, res) => {
  try {
    const sig       = req.headers['x-razorpay-signature'];
    const secret    = process.env.RAZORPAY_WEBHOOK_SECRET;
    const expected  = crypto.createHmac('sha256', secret).update(req.body).digest('hex');

    if (sig !== expected) return res.status(400).json({ error: 'Invalid webhook signature' });

    const event = JSON.parse(req.body);
    if (event.event === 'payment.captured') {
      const payment = event.payload.payment.entity;
      const deposit = await Deposit.findOne({ gatewayOrderId: payment.order_id, status: 'pending' });

      if (deposit && !deposit.gatewayPaymentId) {
        deposit.gatewayPaymentId = payment.id;
        deposit.status = 'approved';
        deposit.reviewedAt = new Date();
        await deposit.save();

        const newBal = await updateBalance(deposit.userId, deposit.amount, 'deposit', null, 'Razorpay webhook');
        await User.findByIdAndUpdate(deposit.userId, { $inc: { totalDeposited: deposit.amount } });

        const io = global.io;
        if (io) io.to(`user:${deposit.userId}`).emit('balance:update', { balance: newBal });
      }
    }
    res.json({ received: true });
  } catch (e) {
    console.error('Webhook error:', e);
    res.status(500).json({ error: 'Webhook failed' });
  }
});

// ─── Withdrawal Request ──────────────────────────────────────
router.post('/withdraw/request', auth, async (req, res) => {
  try {
    const { amount, upiId } = req.body;
    const amt = parseFloat(amount);
    if (!upiId?.trim())   return res.status(400).json({ error: 'UPI ID required' });
    if (amt < MIN_WITHDRAW) return res.status(400).json({ error: `Minimum withdrawal: ₹${MIN_WITHDRAW}` });
    if (amt > MAX_WITHDRAW) return res.status(400).json({ error: `Maximum withdrawal: ₹${MAX_WITHDRAW}` });

    const user = await User.findById(req.user._id);
    if (amt > user.balance) return res.status(400).json({ error: 'Insufficient balance' });

    // Max 2 pending withdrawals
    const pending = await Withdrawal.countDocuments({ userId: req.user._id, status: 'pending' });
    if (pending >= 2) return res.status(400).json({ error: 'Max 2 pending withdrawals allowed' });

    // Deduct balance first
    user.balance = parseFloat((user.balance - amt).toFixed(2));
    await user.save();

    const withdrawal = await Withdrawal.create({ userId: req.user._id, amount: amt, upiId: upiId.trim() });

    await Transaction.create({
      userId: req.user._id,
      type: 'withdrawal',
      amount: -amt,
      balanceBefore: user.balance + amt,
      balanceAfter: user.balance,
      description: `Withdrawal request to ${upiId} (${withdrawal._id})`,
    });

    const io = req.app.get('io');
    if (io) {
      io.to(`user:${req.user._id}`).emit('balance:update', { balance: user.balance });
      io.emit('admin:newWithdrawal', { userId: req.user._id.toString(), amount: amt });
    }

    res.json({ message: 'Withdrawal requested. Processing within 24 hours.', withdrawal, netAmount: withdrawal.netAmount, fee: withdrawal.fee });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Withdrawal failed' });
  }
});

// ─── ADMIN: Deposits ─────────────────────────────────────────
router.get('/admin/deposits', adminAuth, async (req, res) => {
  const { status = 'submitted', page = 1 } = req.query;
  const deposits = await Deposit.find({ status })
    .sort({ createdAt: -1 })
    .skip((page - 1) * 50).limit(50)
    .populate('userId', 'username email')
    .lean();
  res.json({ deposits });
});

router.post('/admin/deposit/:id/approve', adminAuth, async (req, res) => {
  try {
    const deposit = await Deposit.findOne({ _id: req.params.id, status: 'submitted' });
    if (!deposit) return res.status(404).json({ error: 'Deposit not found' });

    deposit.status = 'approved'; deposit.reviewedBy = req.user._id; deposit.reviewedAt = new Date();
    await deposit.save();

    const newBal = await updateBalance(deposit.userId, deposit.amount, 'deposit', null, 'Admin approved deposit');
    await User.findByIdAndUpdate(deposit.userId, { $inc: { totalDeposited: deposit.amount } });

    const io = req.app.get('io');
    if (io) io.to(`user:${deposit.userId}`).emit('balance:update', { balance: newBal });

    res.json({ message: 'Deposit approved', newBalance: newBal });
  } catch (e) {
    res.status(500).json({ error: 'Approval failed' });
  }
});

router.post('/admin/deposit/:id/reject', adminAuth, async (req, res) => {
  const { reason } = req.body;
  const deposit = await Deposit.findOneAndUpdate(
    { _id: req.params.id, status: { $in: ['pending','submitted'] } },
    { status: 'rejected', adminNote: reason || 'Rejected', reviewedBy: req.user._id, reviewedAt: new Date() },
    { new: true }
  );
  if (!deposit) return res.status(404).json({ error: 'Not found' });
  res.json({ message: 'Deposit rejected' });
});

// ─── ADMIN: Withdrawals ──────────────────────────────────────
router.get('/admin/withdrawals', adminAuth, async (req, res) => {
  const { status = 'pending' } = req.query;
  const withdrawals = await Withdrawal.find({ status })
    .sort({ createdAt: -1 }).limit(100)
    .populate('userId', 'username email')
    .lean();
  res.json({ withdrawals });
});

router.post('/admin/withdrawal/:id/approve', adminAuth, async (req, res) => {
  const w = await Withdrawal.findOneAndUpdate(
    { _id: req.params.id, status: 'pending' },
    { status: 'approved', reviewedBy: req.user._id, reviewedAt: new Date() },
    { new: true }
  );
  if (!w) return res.status(404).json({ error: 'Not found' });
  res.json({ message: 'Withdrawal approved', upiId: w.upiId, amount: w.netAmount });
});

router.post('/admin/withdrawal/:id/reject', adminAuth, async (req, res) => {
  try {
    const { reason } = req.body;
    const w = await Withdrawal.findOne({ _id: req.params.id, status: 'pending' });
    if (!w) return res.status(404).json({ error: 'Not found' });

    w.status = 'rejected'; w.adminNote = reason; w.reviewedBy = req.user._id; w.reviewedAt = new Date();
    await w.save();

    // Refund
    const newBal = await updateBalance(w.userId, w.amount, 'refund', null, 'Withdrawal rejected — refunded');
    const io = req.app.get('io');
    if (io) io.to(`user:${w.userId}`).emit('balance:update', { balance: newBal });

    res.json({ message: 'Withdrawal rejected and balance refunded' });
  } catch (e) {
    res.status(500).json({ error: 'Rejection failed' });
  }
});

module.exports = router;
