const express = require('express');
const router  = express.Router();
const mongoose = require('mongoose');
const { auth } = require('../middleware/auth');
const User        = require('../models/User');
const GameSession = require('../models/GameSession');
const { updateBalance, calcMinesMultiplier, getKenoMultiplier, cardRank } = require('../utils/gameHelpers');
const pf = require('../utils/provablyFair');

// ─── Helpers ─────────────────────────────────────────────────
function validateBet(bet, balance) {
  if (isNaN(bet) || bet <= 0) return 'Invalid bet amount';
  if (bet < 1)                return 'Minimum bet is ₹1';
  if (bet > balance)          return 'Insufficient balance';
  return null;
}

async function getSeeds(user) {
  const serverSeed = pf.generateServerSeed();
  const clientSeed = user.clientSeed || pf.generateServerSeed();
  const nonce      = (user.nonce || 0) + 1;
  await User.findByIdAndUpdate(user._id, { nonce, serverSeedHash: pf.hashServerSeed(serverSeed) });
  return { serverSeed, clientSeed, nonce };
}

function broadcastWin(req, game, username, bet, payout, multiplier) {
  const io = req.app.get('io');
  if (io && payout > bet) io.emit('live:bet', { game, username, bet, payout, multiplier, won: true, ts: Date.now() });
}

// ══════════════════════════════════════════════════════════════
// DICE
// ══════════════════════════════════════════════════════════════
router.post('/dice', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, target, direction } = req.body;
    const bet = parseFloat(betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });
    if (target < 2 || target > 98) return res.status(400).json({ error: 'Target must be 2-98' });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const roll       = pf.generateDiceRoll(serverSeed, clientSeed, nonce);
    const winChance  = direction === 'over' ? (100 - target) / 100 : target / 100;
    const multiplier = parseFloat((0.99 / winChance).toFixed(4));
    const won        = direction === 'over' ? roll > target : roll < target;
    const payout     = won ? parseFloat((bet * multiplier).toFixed(2)) : 0;
    const profit     = parseFloat((payout - bet).toFixed(2));

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'dice', `Dice ${direction} ${target}`, session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'dice', `Dice win x${multiplier}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'dice', betAmount: bet,
      multiplier, payout, profit, won,
      result: { roll, target, direction },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'dice', req.user.username, bet, payout, multiplier);
    res.json({ roll, won, payout, profit, multiplier, serverSeedHash: pf.hashServerSeed(serverSeed), balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    console.error(e);
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// LIMBO  (set target multiplier, win if result >= target)
// ══════════════════════════════════════════════════════════════
router.post('/limbo', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, targetMultiplier } = req.body;
    const bet    = parseFloat(betAmount);
    const target = parseFloat(targetMultiplier);
    const err    = validateBet(bet, req.user.balance);
    if (err)                      return res.status(400).json({ error: err });
    if (isNaN(target) || target < 1.01) return res.status(400).json({ error: 'Target must be >= 1.01' });
    if (target > 1000000)         return res.status(400).json({ error: 'Target too high' });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const result     = pf.generateCrashPoint(serverSeed, clientSeed, nonce);
    const won        = result >= target;
    const multiplier = won ? target : 0;
    const payout     = won ? parseFloat((bet * target).toFixed(2)) : 0;
    const profit     = parseFloat((payout - bet).toFixed(2));

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'limbo', `Limbo x${target}`, session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'limbo', `Limbo win x${target}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'limbo', betAmount: bet,
      multiplier: result, payout, profit, won,
      result: { result, target, won },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'limbo', req.user.username, bet, payout, target);
    res.json({ result, target, won, payout, profit, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// MINES — Start
// ══════════════════════════════════════════════════════════════
router.post('/mines/start', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, minesCount } = req.body;
    const bet   = parseFloat(betAmount);
    const mines = parseInt(minesCount);
    const err   = validateBet(bet, req.user.balance);
    if (err)                          return res.status(400).json({ error: err });
    if (mines < 1 || mines > 24)      return res.status(400).json({ error: 'Mines must be 1-24' });

    // Cancel any existing active mines session
    await GameSession.deleteMany({ userId: req.user._id, gameType: 'mines', active: true });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const minePositions = pf.generateMinePositions(serverSeed, clientSeed, nonce, mines);

    await updateBalance(req.user._id, -bet, 'loss', 'mines', `Mines bet (${mines} mines)`, session);

    const gs = await GameSession.create([{
      userId: req.user._id, gameType: 'mines', betAmount: bet,
      multiplier: 1, payout: 0, profit: -bet, won: false, active: true,
      result: { minePositions, mines, revealed: [] },
      serverSeed, clientSeed, nonce,
      hash: pf.hashServerSeed(serverSeed),
    }], { session });

    await session.commitTransaction();
    res.json({
      sessionId: gs[0]._id,
      mines,
      serverSeedHash: pf.hashServerSeed(serverSeed),
      balance: req.user.balance - bet,
    });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Failed to start mines' });
  } finally { session.endSession(); }
});

// MINES — Reveal tile
router.post('/mines/reveal', auth, async (req, res) => {
  try {
    const { sessionId, tileIndex } = req.body;
    if (tileIndex < 0 || tileIndex > 24) return res.status(400).json({ error: 'Invalid tile' });

    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'mines', active: true });
    if (!gs) return res.status(404).json({ error: 'No active mines game' });

    const { minePositions, mines, revealed } = gs.result;
    if (revealed.includes(tileIndex)) return res.status(400).json({ error: 'Tile already revealed' });

    const isMine = minePositions.includes(tileIndex);
    revealed.push(tileIndex);

    const safeRevealed = revealed.filter(t => !minePositions.includes(t)).length;
    const totalSafe    = 25 - mines;
    const multiplier   = calcMinesMultiplier(mines, safeRevealed);
    const currentPayout= parseFloat((gs.betAmount * multiplier).toFixed(2));

    if (isMine) {
      gs.active = false; gs.won = false; gs.result.revealed = revealed;
      await gs.save();
      return res.json({ isMine: true, minePositions, balance: req.user.balance });
    }

    if (safeRevealed >= totalSafe) {
      // Auto cashout — all safe tiles found
      gs.active = false; gs.won = true; gs.multiplier = multiplier;
      gs.payout = currentPayout; gs.profit = currentPayout - gs.betAmount;
      gs.result.revealed = revealed;
      await gs.save();
      const newBal = await updateBalance(req.user._id, currentPayout, 'win', 'mines', `Mines full clear x${multiplier}`);
      broadcastWin(req, 'mines', req.user.username, gs.betAmount, currentPayout, multiplier);
      return res.json({ isMine: false, safeRevealed, multiplier, autoWon: true, payout: currentPayout, minePositions, balance: newBal });
    }

    gs.result = { minePositions, mines, revealed };
    gs.multiplier = multiplier;
    gs.markModified('result');
    await gs.save();

    res.json({ isMine: false, safeRevealed, multiplier, currentPayout });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Reveal failed' });
  }
});

// MINES — Cashout
router.post('/mines/cashout', auth, async (req, res) => {
  try {
    const { sessionId } = req.body;
    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'mines', active: true });
    if (!gs) return res.status(404).json({ error: 'No active game' });

    const { minePositions, mines, revealed } = gs.result;
    const safeRevealed = revealed.filter(t => !minePositions.includes(t)).length;
    if (safeRevealed === 0) return res.status(400).json({ error: 'Reveal at least one safe tile first' });

    const multiplier   = calcMinesMultiplier(mines, safeRevealed);
    const payout       = parseFloat((gs.betAmount * multiplier).toFixed(2));

    gs.active = false; gs.won = true; gs.multiplier = multiplier;
    gs.payout = payout; gs.profit = payout - gs.betAmount;
    gs.result.revealed = revealed;
    gs.markModified('result');
    await gs.save();

    const newBal = await updateBalance(req.user._id, payout, 'win', 'mines', `Mines cashout x${multiplier}`);
    broadcastWin(req, 'mines', req.user.username, gs.betAmount, payout, multiplier);

    res.json({ won: true, multiplier, payout, profit: payout - gs.betAmount, minePositions, balance: newBal });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Cashout failed' });
  }
});

// ══════════════════════════════════════════════════════════════
// TOWER  (climb rows, avoid traps)
// ══════════════════════════════════════════════════════════════
const TOWER_CONFIG = {
  easy:   { cols: 4, traps: 1, baseMultiplier: 1.35 },
  medium: { cols: 3, traps: 1, baseMultiplier: 1.45 },
  hard:   { cols: 2, traps: 1, baseMultiplier: 1.95 },
  expert: { cols: 2, traps: 1, baseMultiplier: 2.5  },
};

router.post('/tower/start', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, risk = 'medium' } = req.body;
    const bet    = parseFloat(betAmount);
    const config = TOWER_CONFIG[risk];
    if (!config) return res.status(400).json({ error: 'Invalid risk level' });
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    await GameSession.deleteMany({ userId: req.user._id, gameType: 'tower', active: true });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);

    // Pre-generate trap positions for all 9 rows
    const rows = [];
    for (let r = 0; r < 9; r++) {
      const trapCol = pf.generateInt(serverSeed, clientSeed, nonce + r, 0, config.cols - 1);
      rows.push(trapCol);
    }

    await updateBalance(req.user._id, -bet, 'loss', 'tower', `Tower bet (${risk})`, session);

    const gs = await GameSession.create([{
      userId: req.user._id, gameType: 'tower', betAmount: bet,
      multiplier: 1, payout: 0, profit: -bet, won: false, active: true,
      result: { rows, risk, config, currentRow: 0, multiplier: 1 },
      serverSeed, clientSeed, nonce,
      hash: pf.hashServerSeed(serverSeed),
    }], { session });

    await session.commitTransaction();
    res.json({
      sessionId: gs[0]._id,
      risk,
      cols: config.cols,
      totalRows: 9,
      serverSeedHash: pf.hashServerSeed(serverSeed),
      balance: req.user.balance - bet,
    });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Failed to start tower' });
  } finally { session.endSession(); }
});

router.post('/tower/climb', auth, async (req, res) => {
  try {
    const { sessionId, chosenCol } = req.body;
    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'tower', active: true });
    if (!gs) return res.status(404).json({ error: 'No active tower game' });

    const { rows, risk, config, currentRow } = gs.result;
    if (currentRow >= 9) return res.status(400).json({ error: 'Tower already completed' });

    const trapCol  = rows[currentRow];
    const isTrapped = chosenCol === trapCol;
    const nextRow  = currentRow + 1;
    const mult     = parseFloat(Math.pow(config.baseMultiplier, nextRow).toFixed(4));

    if (isTrapped) {
      gs.active = false; gs.won = false;
      gs.result.currentRow = nextRow;
      gs.markModified('result');
      await gs.save();
      return res.json({ isTrapped: true, trapCol, rows, balance: req.user.balance });
    }

    gs.result.currentRow = nextRow;
    gs.multiplier = mult;
    gs.markModified('result');
    await gs.save();

    if (nextRow >= 9) {
      // Auto-cashout at top
      const payout = parseFloat((gs.betAmount * mult).toFixed(2));
      gs.active = false; gs.won = true; gs.payout = payout; gs.profit = payout - gs.betAmount;
      await gs.save();
      const newBal = await updateBalance(req.user._id, payout, 'win', 'tower', `Tower top! x${mult}`);
      broadcastWin(req, 'tower', req.user.username, gs.betAmount, payout, mult);
      return res.json({ isTrapped: false, nextRow, multiplier: mult, completed: true, payout, rows, balance: newBal });
    }

    res.json({ isTrapped: false, nextRow, multiplier: mult, currentPayout: parseFloat((gs.betAmount * mult).toFixed(2)) });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Climb failed' });
  }
});

router.post('/tower/cashout', auth, async (req, res) => {
  try {
    const { sessionId } = req.body;
    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'tower', active: true });
    if (!gs) return res.status(404).json({ error: 'No active tower game' });
    if (gs.result.currentRow === 0) return res.status(400).json({ error: 'Climb at least one row first' });

    const payout = parseFloat((gs.betAmount * gs.multiplier).toFixed(2));
    gs.active = false; gs.won = true; gs.payout = payout; gs.profit = payout - gs.betAmount;
    await gs.save();

    const newBal = await updateBalance(req.user._id, payout, 'win', 'tower', `Tower cashout x${gs.multiplier}`);
    broadcastWin(req, 'tower', req.user.username, gs.betAmount, payout, gs.multiplier);
    res.json({ won: true, multiplier: gs.multiplier, payout, rows: gs.result.rows, balance: newBal });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Cashout failed' });
  }
});

// ══════════════════════════════════════════════════════════════
// KENO  (pick 1-10 numbers, 20 drawn from 80)
// ══════════════════════════════════════════════════════════════
router.post('/keno', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, picks } = req.body; // picks: array of numbers
    const bet   = parseFloat(betAmount);
    const err   = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });
    if (!Array.isArray(picks) || picks.length < 1 || picks.length > 10)
      return res.status(400).json({ error: 'Choose 1-10 numbers' });
    if (picks.some(p => p < 1 || p > 80 || !Number.isInteger(p)))
      return res.status(400).json({ error: 'Numbers must be 1-80' });
    if (new Set(picks).size !== picks.length)
      return res.status(400).json({ error: 'Duplicate numbers not allowed' });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const drawn   = pf.generateKenoDraw(serverSeed, clientSeed, nonce);
    const hits    = picks.filter(p => drawn.includes(p)).length;
    const mult    = getKenoMultiplier(picks.length, hits);
    const payout  = parseFloat((bet * mult).toFixed(2));
    const profit  = parseFloat((payout - bet).toFixed(2));
    const won     = payout > 0;

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'keno', `Keno (${picks.length} picks)`, session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'keno', `Keno win x${mult}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'keno', betAmount: bet,
      multiplier: mult, payout, profit, won,
      result: { picks, drawn, hits, mult },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'keno', req.user.username, bet, payout, mult);
    res.json({ drawn, hits, multiplier: mult, payout, profit, won, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Keno error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// HILO  (predict if next card is higher or lower)
// ══════════════════════════════════════════════════════════════
const SUITS = ['♠', '♥', '♦', '♣'];
const RANKS = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];

router.post('/hilo/start', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount } = req.body;
    const bet = parseFloat(betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    await GameSession.deleteMany({ userId: req.user._id, gameType: 'hilo', active: true });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const deck = pf.generateDeckShuffle(serverSeed, clientSeed, nonce);

    const firstCard = deck[0];
    await updateBalance(req.user._id, -bet, 'loss', 'hilo', 'Hilo bet', session);

    const gs = await GameSession.create([{
      userId: req.user._id, gameType: 'hilo', betAmount: bet,
      multiplier: 1, payout: 0, profit: -bet, won: false, active: true,
      result: { deck, currentIndex: 0, currentCard: firstCard, history: [], multiplier: 1 },
      serverSeed, clientSeed, nonce, hash: pf.hashServerSeed(serverSeed),
    }], { session });

    await session.commitTransaction();
    res.json({
      sessionId: gs[0]._id,
      currentCard: firstCard,
      serverSeedHash: pf.hashServerSeed(serverSeed),
      balance: req.user.balance - bet,
    });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Failed to start Hilo' });
  } finally { session.endSession(); }
});

router.post('/hilo/guess', auth, async (req, res) => {
  try {
    const { sessionId, guess } = req.body; // guess: 'higher' | 'lower' | 'skip'
    if (!['higher', 'lower', 'skip'].includes(guess))
      return res.status(400).json({ error: 'Invalid guess' });

    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'hilo', active: true });
    if (!gs) return res.status(404).json({ error: 'No active Hilo game' });

    const { deck, currentIndex, currentCard, history, multiplier } = gs.result;
    if (currentIndex >= deck.length - 1) return res.status(400).json({ error: 'No more cards' });

    const nextCard   = deck[currentIndex + 1];
    const curVal     = cardRank(currentCard.rank);
    const nextVal    = cardRank(nextCard.rank);

    let correct = false;
    let newMult = multiplier;

    if (guess === 'skip') {
      // Skip — no change to multiplier, just advance card
      correct = true;
    } else {
      correct = guess === 'higher' ? nextVal > curVal : nextVal < curVal;
      if (nextVal === curVal) correct = true; // tie = push for this card

      if (correct) {
        // Multiplier increases based on probability
        const higherCount = RANKS.filter((_, i) => i > RANKS.indexOf(currentCard.rank)).length * 4;
        const lowerCount  = RANKS.filter((_, i) => i < RANKS.indexOf(currentCard.rank)).length * 4;
        const prob        = guess === 'higher' ? higherCount / 52 : lowerCount / 52;
        const cardMult    = prob > 0 ? parseFloat((0.99 / prob).toFixed(3)) : 1;
        newMult           = parseFloat((multiplier * cardMult).toFixed(4));
      }
    }

    history.push({ card: currentCard, guess, nextCard, correct, multiplier: newMult });
    gs.result.currentCard  = nextCard;
    gs.result.currentIndex = currentIndex + 1;
    gs.result.history      = history;
    gs.result.multiplier   = newMult;
    gs.multiplier          = newMult;
    gs.markModified('result');

    if (!correct) {
      gs.active = false; gs.won = false;
      await gs.save();
      return res.json({ correct: false, nextCard, history, balance: req.user.balance });
    }

    await gs.save();
    const currentPayout = parseFloat((gs.betAmount * newMult).toFixed(2));
    res.json({ correct: true, nextCard, multiplier: newMult, currentPayout, history });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Guess failed' });
  }
});

router.post('/hilo/cashout', auth, async (req, res) => {
  try {
    const { sessionId } = req.body;
    const gs = await GameSession.findOne({ _id: sessionId, userId: req.user._id, gameType: 'hilo', active: true });
    if (!gs) return res.status(404).json({ error: 'No active Hilo game' });
    if (gs.result.history.length === 0) return res.status(400).json({ error: 'Make at least one correct guess first' });

    const payout = parseFloat((gs.betAmount * gs.multiplier).toFixed(2));
    gs.active = false; gs.won = true; gs.payout = payout; gs.profit = payout - gs.betAmount;
    await gs.save();

    const newBal = await updateBalance(req.user._id, payout, 'win', 'hilo', `Hilo cashout x${gs.multiplier}`);
    broadcastWin(req, 'hilo', req.user.username, gs.betAmount, payout, gs.multiplier);
    res.json({ won: true, multiplier: gs.multiplier, payout, balance: newBal });
  } catch (e) {
    res.status(500).json({ error: e.message || 'Cashout failed' });
  }
});

// ══════════════════════════════════════════════════════════════
// COIN FLIP
// ══════════════════════════════════════════════════════════════
router.post('/coinflip', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, choice } = req.body;
    const bet = parseFloat(betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });
    if (!['heads','tails'].includes(choice)) return res.status(400).json({ error: 'Choose heads or tails' });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const flip       = pf.generateFloat(serverSeed, clientSeed, nonce) < 0.5 ? 'heads' : 'tails';
    const won        = flip === choice;
    const multiplier = 1.98;
    const payout     = won ? parseFloat((bet * multiplier).toFixed(2)) : 0;
    const profit     = parseFloat((payout - bet).toFixed(2));

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'coinflip', `Flip: ${choice}`, session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'coinflip', `Flip win x${multiplier}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'coinflip', betAmount: bet,
      multiplier, payout, profit, won, result: { flip, choice },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'coinflip', req.user.username, bet, payout, multiplier);
    res.json({ result: flip, won, payout, profit, multiplier, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// WHEEL
// ══════════════════════════════════════════════════════════════
const WHEEL_SEGMENTS = [
  { label:'2x',   multiplier:2,   weight:25 },
  { label:'3x',   multiplier:3,   weight:15 },
  { label:'5x',   multiplier:5,   weight:8  },
  { label:'10x',  multiplier:10,  weight:4  },
  { label:'0x',   multiplier:0,   weight:30 },
  { label:'1.5x', multiplier:1.5, weight:18 },
];

router.post('/wheel', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const bet = parseFloat(req.body.betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const total = WHEEL_SEGMENTS.reduce((s, sg) => s + sg.weight, 0);
    let r = pf.generateFloat(serverSeed, clientSeed, nonce) * total;
    let segIndex = 0;
    for (let i = 0; i < WHEEL_SEGMENTS.length; i++) {
      r -= WHEEL_SEGMENTS[i].weight;
      if (r <= 0) { segIndex = i; break; }
    }
    const segment = WHEEL_SEGMENTS[segIndex];
    const won    = segment.multiplier > 0;
    const payout = won ? parseFloat((bet * segment.multiplier).toFixed(2)) : 0;
    const profit = parseFloat((payout - bet).toFixed(2));

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'wheel', 'Wheel spin', session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'wheel', `Wheel x${segment.multiplier}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'wheel', betAmount: bet,
      multiplier: segment.multiplier, payout, profit, won,
      result: { segIndex, label: segment.label },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'wheel', req.user.username, bet, payout, segment.multiplier);
    res.json({ segmentIndex: segIndex, segment, won, payout, profit, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// PLINKO
// ══════════════════════════════════════════════════════════════
const PLINKO_MULTS = {
  low:    [1.4,1.2,1.1,1.0,0.5,1.0,1.1,1.2,1.4],
  medium: [5.6,2.1,1.1,0.5,0.3,0.5,1.1,2.1,5.6],
  high:   [29,4,1.5,0.3,0.2,0.3,1.5,4,29],
};

router.post('/plinko', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, risk = 'medium' } = req.body;
    const bet = parseFloat(betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });
    if (!PLINKO_MULTS[risk]) return res.status(400).json({ error: 'Invalid risk' });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const path = [];
    let pos = 4;
    for (let row = 0; row < 8; row++) {
      const goRight = pf.generateFloat(serverSeed, clientSeed, nonce + row) >= 0.5;
      path.push(goRight ? 'R' : 'L');
      pos += goRight ? 1 : -1;
      pos = Math.max(0, Math.min(8, pos));
    }
    const mults      = PLINKO_MULTS[risk];
    const mult       = mults[Math.min(pos, mults.length - 1)];
    const payout     = parseFloat((bet * mult).toFixed(2));
    const profit     = parseFloat((payout - bet).toFixed(2));
    const won        = payout > bet;

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'plinko', `Plinko ${risk}`, session);
    let finalBal = newBal;
    if (payout > 0) finalBal = await updateBalance(req.user._id, payout, won ? 'win' : 'loss', 'plinko', `Plinko x${mult}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'plinko', betAmount: bet,
      multiplier: mult, payout, profit, won, result: { path, pos, risk, mult },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'plinko', req.user.username, bet, payout, mult);
    res.json({ path, bucketIndex: pos, multiplier: mult, payout, profit, won, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// SLOTS
// ══════════════════════════════════════════════════════════════
const SLOT_SYMBOLS = ['🍒','🍋','💎','7️⃣','⭐','🔔','🍇','🎰'];
const SLOT_PAYS    = { '🍒':2,'🍋':3,'💎':10,'7️⃣':20,'⭐':5,'🔔':4,'🍇':3,'🎰':50 };

function spinReels(serverSeed, clientSeed, nonce) {
  const reels = [];
  let n = nonce;
  for (let col = 0; col < 3; col++) {
    const column = [];
    for (let row = 0; row < 3; row++) {
      const idx = Math.floor(pf.generateFloat(serverSeed, clientSeed, n++) * SLOT_SYMBOLS.length);
      column.push(SLOT_SYMBOLS[idx]);
    }
    reels.push(column);
  }
  return reels;
}

function calcSlotWin(reels) {
  let totalMult = 0; const wins = [];
  for (let row = 0; row < 3; row++) {
    const line = [reels[0][row], reels[1][row], reels[2][row]];
    if (line[0] === line[1] && line[1] === line[2]) {
      const m = SLOT_PAYS[line[0]] || 1; totalMult += m;
      wins.push({ type:'row', row, symbol:line[0], mult:m });
    }
  }
  const d1 = [reels[0][0], reels[1][1], reels[2][2]];
  const d2 = [reels[0][2], reels[1][1], reels[2][0]];
  if (d1[0]===d1[1]&&d1[1]===d1[2]) { const m=parseFloat((SLOT_PAYS[d1[0]]*1.5).toFixed(2)); totalMult+=m; wins.push({type:'diag1',symbol:d1[0],mult:m}); }
  if (d2[0]===d2[1]&&d2[1]===d2[2]) { const m=parseFloat((SLOT_PAYS[d2[0]]*1.5).toFixed(2)); totalMult+=m; wins.push({type:'diag2',symbol:d2[0],mult:m}); }
  return { totalMult:parseFloat(totalMult.toFixed(2)), wins };
}

router.post('/slots', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const bet = parseFloat(req.body.betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const reels          = spinReels(serverSeed, clientSeed, nonce);
    const { totalMult, wins } = calcSlotWin(reels);
    const payout         = totalMult > 0 ? parseFloat((bet * totalMult).toFixed(2)) : 0;
    const profit         = parseFloat((payout - bet).toFixed(2));
    const won            = payout > 0;

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'slots', 'Slots spin', session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'slots', `Slots x${totalMult}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'slots', betAmount: bet,
      multiplier: totalMult, payout, profit, won, result: { reels, wins },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'slots', req.user.username, bet, payout, totalMult);
    res.json({ reels, wins, totalMultiplier: totalMult, payout, profit, won, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// BLACKJACK
// ══════════════════════════════════════════════════════════════
function handValue(hand) {
  let v = 0, aces = 0;
  for (const c of hand) {
    if (['J','Q','K'].includes(c.rank)) v += 10;
    else if (c.rank === 'A') { v += 11; aces++; }
    else v += parseInt(c.rank);
  }
  while (v > 21 && aces-- > 0) v -= 10;
  return v;
}

router.post('/blackjack/deal', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const bet = parseFloat(req.body.betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    await GameSession.deleteMany({ userId: req.user._id, gameType: 'blackjack', active: true });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const deck        = pf.generateDeckShuffle(serverSeed, clientSeed, nonce);
    const playerHand  = [deck.pop(), deck.pop()];
    const dealerHand  = [deck.pop(), deck.pop()];
    const playerVal   = handValue(playerHand);

    await updateBalance(req.user._id, -bet, 'loss', 'blackjack', 'Blackjack deal', session);

    if (playerVal === 21) {
      const dealerVal = handValue(dealerHand);
      const bjWon     = dealerVal !== 21;
      const mult      = bjWon ? 2.5 : 1.0;
      const payout    = parseFloat((bet * mult).toFixed(2));
      let finalBal    = req.user.balance - bet;
      if (payout > 0) finalBal = await updateBalance(req.user._id, payout, bjWon ? 'win' : 'loss', 'blackjack', `BJ ${bjWon?'Blackjack':'Push'}`, session);

      await GameSession.create([{ userId:req.user._id, gameType:'blackjack', betAmount:bet, multiplier:mult, payout, profit:payout-bet, won:bjWon, result:{playerHand,dealerHand,outcome:bjWon?'blackjack':'push'}, serverSeed:pf.hashServerSeed(serverSeed),clientSeed,nonce }], { session });
      await session.commitTransaction();
      return res.json({ playerHand, dealerHand, playerValue:21, dealerValue:dealerVal, gameOver:true, outcome:bjWon?'blackjack':'push', payout, balance:finalBal });
    }

    const gs = await GameSession.create([{
      userId: req.user._id, gameType: 'blackjack', betAmount: bet,
      multiplier: 1, payout: 0, profit: -bet, won: false, active: true,
      result: { playerHand, dealerHand, deck: deck.slice(0, 30), bet },
      serverSeed, clientSeed, nonce, hash: pf.hashServerSeed(serverSeed),
    }], { session });

    await session.commitTransaction();
    res.json({ sessionId: gs[0]._id, playerHand, dealerCard: dealerHand[0], playerValue: playerVal, gameOver: false, balance: req.user.balance - bet });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Deal failed' });
  } finally { session.endSession(); }
});

router.post('/blackjack/hit', auth, async (req, res) => {
  try {
    const gs = await GameSession.findOne({ _id: req.body.sessionId, userId: req.user._id, gameType: 'blackjack', active: true });
    if (!gs) return res.status(404).json({ error: 'No active game' });
    const { playerHand, dealerHand, deck, bet } = gs.result;
    const newCard = deck.pop();
    playerHand.push(newCard);
    const playerVal = handValue(playerHand);
    gs.result = { playerHand, dealerHand, deck, bet };
    gs.markModified('result');

    if (playerVal > 21) {
      gs.active = false; gs.won = false;
      await gs.save();
      return res.json({ playerHand, playerValue: playerVal, dealerHand, gameOver: true, outcome: 'bust', balance: req.user.balance });
    }
    await gs.save();
    res.json({ playerHand, playerValue: playerVal, newCard, gameOver: false });
  } catch (e) { res.status(500).json({ error: e.message || 'Hit failed' }); }
});

router.post('/blackjack/stand', auth, async (req, res) => {
  try {
    const gs = await GameSession.findOne({ _id: req.body.sessionId, userId: req.user._id, gameType: 'blackjack', active: true });
    if (!gs) return res.status(404).json({ error: 'No active game' });
    const { playerHand, dealerHand, deck, bet } = gs.result;

    while (handValue(dealerHand) < 17) dealerHand.push(deck.pop());

    const pv = handValue(playerHand), dv = handValue(dealerHand);
    let outcome, mult, payout;
    if (dv > 21 || pv > dv)   { outcome='win';  mult=2.0; }
    else if (pv === dv)        { outcome='push'; mult=1.0; }
    else                       { outcome='lose'; mult=0;   }

    payout = parseFloat((bet * mult).toFixed(2));
    const won = outcome === 'win';
    gs.active = false; gs.won = won; gs.multiplier = mult; gs.payout = payout; gs.profit = payout - bet;
    gs.result = { playerHand, dealerHand, deck, bet, outcome };
    gs.markModified('result');
    await gs.save();

    let finalBal = req.user.balance;
    if (payout > 0) finalBal = await updateBalance(req.user._id, payout, won ? 'win' : 'loss', 'blackjack', `BJ ${outcome}`);

    broadcastWin(req, 'blackjack', req.user.username, bet, payout, mult);
    res.json({ playerHand, dealerHand, playerValue: pv, dealerValue: dv, outcome, payout, profit: payout-bet, balance: finalBal });
  } catch (e) { res.status(500).json({ error: e.message || 'Stand failed' }); }
});

// ══════════════════════════════════════════════════════════════
// ROULETTE
// ══════════════════════════════════════════════════════════════
const RED_NUMS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

router.post('/roulette', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    const { betAmount, betType, betValue } = req.body;
    const bet = parseFloat(betAmount);
    const err = validateBet(bet, req.user.balance);
    if (err) return res.status(400).json({ error: err });

    const { serverSeed, clientSeed, nonce } = await getSeeds(req.user);
    const roll  = Math.floor(pf.generateFloat(serverSeed, clientSeed, nonce) * 37);
    const isRed = RED_NUMS.has(roll);
    const isBlack = roll !== 0 && !isRed;

    let mult = 0;
    switch (betType) {
      case 'number': if (parseInt(betValue) === roll) mult = 35; break;
      case 'red':    if (isRed)   mult = 2; break;
      case 'black':  if (isBlack) mult = 2; break;
      case 'odd':    if (roll !== 0 && roll % 2 !== 0) mult = 2; break;
      case 'even':   if (roll !== 0 && roll % 2 === 0) mult = 2; break;
      case 'dozen1': if (roll >= 1  && roll <= 12) mult = 3; break;
      case 'dozen2': if (roll >= 13 && roll <= 24) mult = 3; break;
      case 'dozen3': if (roll >= 25 && roll <= 36) mult = 3; break;
      case 'half1':  if (roll >= 1  && roll <= 18) mult = 2; break;
      case 'half2':  if (roll >= 19 && roll <= 36) mult = 2; break;
      default: return res.status(400).json({ error: 'Invalid bet type' });
    }

    const payout = parseFloat((bet * mult).toFixed(2));
    const profit = parseFloat((payout - bet).toFixed(2));
    const won    = mult > 0;

    const newBal = await updateBalance(req.user._id, -bet, 'loss', 'roulette', `Roulette: ${betType}`, session);
    let finalBal = newBal;
    if (won) finalBal = await updateBalance(req.user._id, payout, 'win', 'roulette', `Roulette x${mult}`, session);

    await GameSession.create([{
      userId: req.user._id, gameType: 'roulette', betAmount: bet,
      multiplier: mult, payout, profit, won,
      result: { roll, betType, betValue, isRed, isBlack },
      serverSeed: pf.hashServerSeed(serverSeed), clientSeed, nonce,
    }], { session });

    await session.commitTransaction();
    broadcastWin(req, 'roulette', req.user.username, bet, payout, mult);
    res.json({ roll, isRed, isBlack, won, multiplier: mult, payout, profit, balance: finalBal });
  } catch (e) {
    await session.abortTransaction();
    res.status(500).json({ error: e.message || 'Game error' });
  } finally { session.endSession(); }
});

// ══════════════════════════════════════════════════════════════
// STATS & HISTORY
// ══════════════════════════════════════════════════════════════
router.get('/history', auth, async (req, res) => {
  const history = await GameSession.find({ userId: req.user._id })
    .sort({ createdAt: -1 }).limit(50).lean();
  res.json({ history });
});

router.get('/recent', async (req, res) => {
  const recent = await GameSession.find({ won: true })
    .sort({ createdAt: -1 }).limit(30)
    .populate('userId', 'username avatarSeed')
    .lean();
  res.json({ recent });
});

router.get('/leaderboard', async (req, res) => {
  const rows = await GameSession.aggregate([
    { $match: { won: true, createdAt: { $gte: new Date(Date.now() - 7*24*60*60*1000) } } },
    { $group: { _id: '$userId', totalProfit: { $sum: '$profit' }, gamesPlayed: { $sum: 1 }, bestMult: { $max: '$multiplier' } } },
    { $sort: { totalProfit: -1 } },
    { $limit: 20 },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'user' } },
    { $unwind: '$user' },
    { $project: { username: '$user.username', avatarSeed: '$user.avatarSeed', vipLevel: '$user.vipLevel', totalProfit: 1, gamesPlayed: 1, bestMult: 1 } },
  ]);
  res.json({ leaderboard: rows });
});

// Provably fair verify
router.post('/verify', auth, async (req, res) => {
  const { serverSeed, clientSeed, nonce, gameType } = req.body;
  try {
    const result = pf.verify(serverSeed, clientSeed, nonce, gameType);
    res.json(result);
  } catch (e) {
    res.status(400).json({ error: 'Verification failed' });
  }
});

// Change client seed
router.post('/seed', auth, async (req, res) => {
  const { clientSeed } = req.body;
  if (!clientSeed || clientSeed.length < 6 || clientSeed.length > 64)
    return res.status(400).json({ error: 'Client seed must be 6-64 characters' });
  await User.findByIdAndUpdate(req.user._id, { clientSeed, nonce: 0 });
  res.json({ message: 'Client seed updated', clientSeed });
});

module.exports = router;
