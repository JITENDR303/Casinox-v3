require('dotenv').config();
const mongoose = require('mongoose');
const User = require('./models/User');

const ADMIN_USERNAME = process.env.ADMIN_USERNAME || 'admin';
const ADMIN_EMAIL    = process.env.ADMIN_EMAIL    || 'admin@casinox.com';
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || 'Admin@123456';

async function seed() {
  await mongoose.connect(process.env.MONGODB_URI, { serverSelectionTimeoutMS: 10000 });
  console.log('✅ MongoDB connected');

  const existing = await User.findOne({ $or: [{ username: ADMIN_USERNAME }, { email: ADMIN_EMAIL }] });

  if (existing) {
    if (existing.role !== 'admin') {
      existing.role = 'admin';
      await existing.save();
      console.log(`✅ Existing user "${existing.username}" promoted to admin`);
    } else {
      console.log(`ℹ️  Admin user "${existing.username}" already exists`);
    }
    await mongoose.disconnect();
    return;
  }

  const admin = new User({
    username:     ADMIN_USERNAME,
    email:        ADMIN_EMAIL,
    passwordHash: ADMIN_PASSWORD,
    role:         'admin',
    balance:      10000,
  });

  await admin.save();
  console.log('✅ Admin user created!');
  console.log(`   Username : ${ADMIN_USERNAME}`);
  console.log(`   Email    : ${ADMIN_EMAIL}`);
  console.log(`   Password : ${ADMIN_PASSWORD}`);
  console.log('   Balance  : ₹10,000');

  await mongoose.disconnect();
}

seed().catch(err => {
  console.error('❌ Error:', err.message);
  process.exit(1);
});
