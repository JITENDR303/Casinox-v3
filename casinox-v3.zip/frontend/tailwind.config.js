export default {
  content: ['./index.html','./src/**/*.{js,jsx}'],
  theme: {
    extend: {
      fontFamily: { sans: ['Inter','system-ui','sans-serif'], mono: ['ui-monospace','monospace'] },
    },
  },
  plugins: [],
};
