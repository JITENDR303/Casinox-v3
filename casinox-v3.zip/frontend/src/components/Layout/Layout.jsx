import React, { useState } from 'react';
import { Outlet, Link } from 'react-router-dom';
import Sidebar from './Sidebar';
import { useStore } from '../../store';
import { useSocket } from '../../hooks/useSocket';
import LiveChat from './LiveChat';

function Header({ onMenuToggle }) {
  const { user, onlineCount } = useStore();
  return (
    <header className="h-14 bg-[#0b0b16]/90 backdrop-blur border-b border-white/[0.06] flex items-center justify-between px-4 sticky top-0 z-10">
      <button onClick={onMenuToggle} className="lg:hidden p-2 text-slate-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors">☰</button>
      <div className="flex items-center gap-2 text-xs text-slate-600">
        <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
        <span>{onlineCount} online</span>
      </div>
      <div className="flex items-center gap-2">
        <Link to="/wallet" className="flex items-center gap-1.5 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 text-emerald-400 px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all">
          ₹{parseFloat(user?.balance || 0).toFixed(2)}
        </Link>
        <Link to="/wallet" className="bg-indigo-600 hover:bg-indigo-500 text-white px-3 py-1.5 rounded-xl text-xs font-bold transition-colors">
          + Deposit
        </Link>
      </div>
    </header>
  );
}

export default function Layout() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [chatOpen,    setChatOpen]    = useState(false);
  useSocket();

  return (
    <div className="flex h-screen bg-[#090912] text-white overflow-hidden">
      <Sidebar open={sidebarOpen} onClose={() => setSidebarOpen(false)} />
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <Header onMenuToggle={() => setSidebarOpen(o => !o)} />
        <main className="flex-1 overflow-y-auto">
          <div className="max-w-6xl mx-auto p-4 pb-24 lg:pb-8">
            <Outlet />
          </div>
        </main>
      </div>

      <button onClick={() => setChatOpen(o => !o)}
        className="fixed bottom-20 right-4 lg:bottom-6 lg:right-6 z-20 w-12 h-12 rounded-full bg-indigo-600 hover:bg-indigo-500 shadow-lg shadow-indigo-500/25 flex items-center justify-center text-xl transition-all hover:scale-110">
        💬
      </button>

      {chatOpen && <LiveChat onClose={() => setChatOpen(false)} />}

      <nav className="fixed bottom-0 left-0 right-0 lg:hidden bg-[#0b0b16] border-t border-white/[0.06] flex z-10 safe-area-bottom">
        {[{to:'/', icon:'🏠', label:'Home'},{to:'/wallet', icon:'💰', label:'Wallet'},{to:'/leaderboard', icon:'🏆', label:'Rank'},{to:'/profile', icon:'👤', label:'Profile'}].map(i => (
          <a key={i.to} href={i.to} className="flex-1 flex flex-col items-center py-2 gap-0.5 text-slate-500 hover:text-white transition-colors">
            <span className="text-xl">{i.icon}</span>
            <span className="text-[9px] font-medium">{i.label}</span>
          </a>
        ))}
      </nav>
    </div>
  );
}
