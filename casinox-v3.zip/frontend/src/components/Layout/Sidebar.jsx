import React, { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { useStore } from '../../store';

const GAMES = [
  { path:'/crash',     label:'Crash',     emoji:'📈', hot:true,  color:'#ef4444' },
  { path:'/mines',     label:'Mines',     emoji:'💣', hot:true,  color:'#f59e0b' },
  { path:'/limbo',     label:'Limbo',     emoji:'🚀', hot:true,  color:'#6366f1' },
  { path:'/dice',      label:'Dice',      emoji:'🎲', color:'#3b82f6' },
  { path:'/plinko',    label:'Plinko',    emoji:'🎯', color:'#8b5cf6' },
  { path:'/hilo',      label:'HiLo',      emoji:'🃏', color:'#10b981' },
  { path:'/tower',     label:'Tower',     emoji:'🏗️', color:'#f97316' },
  { path:'/keno',      label:'Keno',      emoji:'🎱', color:'#06b6d4' },
  { path:'/blackjack', label:'Blackjack', emoji:'🂡', color:'#10b981' },
  { path:'/roulette',  label:'Roulette',  emoji:'🎡', color:'#ec4899' },
  { path:'/slots',     label:'Slots',     emoji:'🎰', color:'#f59e0b' },
  { path:'/wheel',     label:'Wheel',     emoji:'🎪', color:'#06b6d4' },
  { path:'/coinflip',  label:'Coin Flip', emoji:'🪙', color:'#84cc16' },
];

const NAV = [
  { path:'/',           label:'Home',        icon:'🏠' },
  { path:'/wallet',     label:'Wallet',      icon:'💰' },
  { path:'/leaderboard',label:'Leaderboard', icon:'🏆' },
  { path:'/profile',    label:'Profile',     icon:'👤' },
];

const VIP_NAMES  = ['Bronze','Silver','Gold','Platinum','Diamond','Legend'];
const VIP_COLORS = ['text-amber-600','text-slate-300','text-amber-400','text-cyan-400','text-purple-400','text-rose-400'];

export default function Sidebar({ open, onClose }) {
  const { user, logout } = useStore();
  const navigate = useNavigate();
  const [gamesOpen, setGamesOpen] = useState(true);

  const handleLogout = () => { logout(); navigate('/auth'); onClose?.(); };

  const linkClass = ({ isActive }) =>
    `flex items-center gap-3 px-3 py-2 rounded-xl text-sm font-medium transition-all duration-150 group ${
      isActive
        ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-500/30'
        : 'text-slate-400 hover:text-white hover:bg-white/5'
    }`;

  return (
    <>
      {open && <div className="fixed inset-0 bg-black/60 z-20 lg:hidden" onClick={onClose} />}
      <aside className={`
        fixed top-0 left-0 h-full z-30 flex flex-col w-64
        bg-[#0b0b16] border-r border-white/[0.06]
        transition-transform duration-300
        ${open ? 'translate-x-0' : '-translate-x-full'}
        lg:translate-x-0 lg:static
      `}>
        {/* Logo */}
        <div className="flex items-center gap-3 px-5 py-5 border-b border-white/[0.06]">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xl shadow-lg shadow-indigo-500/20">
            🎰
          </div>
          <div>
            <span className="text-lg font-black bg-gradient-to-r from-indigo-400 to-purple-400 bg-clip-text text-transparent">CasinoX</span>
            <p className="text-[10px] text-slate-600 -mt-0.5">v3.0 Premium</p>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto scrollbar-hide px-3 py-4 space-y-0.5">
          {/* Main nav */}
          {NAV.map(item => (
            <NavLink key={item.path} to={item.path} end={item.path==='/'} className={linkClass} onClick={onClose}>
              <span className="text-base w-6 flex-shrink-0 text-center">{item.icon}</span>
              <span>{item.label}</span>
            </NavLink>
          ))}

          {/* Games section */}
          <div className="pt-3">
            <button onClick={() => setGamesOpen(o => !o)}
              className="w-full flex items-center justify-between px-3 py-1.5 text-[11px] font-bold text-slate-600 uppercase tracking-widest hover:text-slate-400 transition-colors">
              <span>Casino Games</span>
              <span className={`transition-transform duration-200 ${gamesOpen ? 'rotate-180' : ''}`}>▾</span>
            </button>

            {gamesOpen && (
              <div className="space-y-0.5 mt-1">
                {GAMES.map(game => (
                  <NavLink key={game.path} to={game.path} className={linkClass} onClick={onClose}>
                    <span className="text-base w-6 flex-shrink-0 text-center">{game.emoji}</span>
                    <span className="flex-1">{game.label}</span>
                    {game.hot && (
                      <span className="text-[9px] bg-red-500 text-white px-1.5 py-0.5 rounded-full font-black tracking-wide">
                        HOT
                      </span>
                    )}
                  </NavLink>
                ))}
              </div>
            )}
          </div>

          {/* Admin */}
          {['admin','moderator'].includes(user?.role) && (
            <NavLink to="/admin" className={linkClass} onClick={onClose}>
              <span className="text-base w-6 flex-shrink-0 text-center">⚙️</span>
              <span>Admin Panel</span>
              <span className="text-[9px] bg-amber-500 text-white px-1.5 py-0.5 rounded-full font-black">ADMIN</span>
            </NavLink>
          )}
        </div>

        {/* User footer */}
        <div className="border-t border-white/[0.06] p-3">
          <div className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-white/5 transition-colors">
            <div className="relative flex-shrink-0">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center font-black text-sm">
                {user?.username?.[0]?.toUpperCase()}
              </div>
              <div className="absolute -bottom-1 -right-1 w-3.5 h-3.5 bg-emerald-400 rounded-full border-2 border-[#0b0b16]" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-bold text-white truncate">{user?.username}</p>
              <div className="flex items-center gap-1.5">
                <span className={`text-[10px] font-bold ${VIP_COLORS[user?.vipLevel || 0]}`}>
                  {VIP_NAMES[user?.vipLevel || 0]}
                </span>
                <span className="text-slate-600">•</span>
                <span className="text-[10px] text-emerald-400 font-mono">₹{parseFloat(user?.balance || 0).toFixed(2)}</span>
              </div>
            </div>
            <button onClick={handleLogout} title="Logout"
              className="text-slate-600 hover:text-red-400 transition-colors text-lg p-1">
              ⏏
            </button>
          </div>
        </div>
      </aside>
    </>
  );
}
