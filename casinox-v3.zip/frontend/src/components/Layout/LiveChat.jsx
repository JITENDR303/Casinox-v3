import React, { useState, useEffect, useRef } from 'react';
import { getSocket } from '../../hooks/useSocket';
import { useStore } from '../../store';

const VIP_BADGE = ['','🥈','🥇','💎','👑','🔥'];

export default function LiveChat({ onClose }) {
  const [messages, setMessages] = useState([]);
  const [input,    setInput]    = useState('');
  const bottomRef = useRef(null);
  const { user }  = useStore();

  useEffect(() => {
    const socket = getSocket();
    if (!socket) return;
    const onHistory = (msgs) => setMessages(msgs || []);
    const onMessage = (msg)  => setMessages(p => [...p.slice(-99), msg]);
    socket.on('chat:history', onHistory);
    socket.on('chat:message', onMessage);
    return () => { socket.off('chat:history', onHistory); socket.off('chat:message', onMessage); };
  }, []);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = (e) => {
    e.preventDefault();
    const socket = getSocket();
    if (!input.trim() || !socket) return;
    socket.emit('chat:send', { message: input.trim() });
    setInput('');
  };

  return (
    <div className="fixed bottom-20 right-4 lg:bottom-20 lg:right-6 z-30 w-72 h-96 bg-[#0f0f1a] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-white/5 bg-white/2">
        <div className="flex items-center gap-2">
          <span className="text-sm">💬</span>
          <span className="text-sm font-bold text-white">Live Chat</span>
          <span className="text-[10px] text-emerald-400 bg-emerald-400/10 px-1.5 py-0.5 rounded-full">LIVE</span>
        </div>
        <button onClick={onClose} className="text-slate-500 hover:text-white transition-colors text-lg">✕</button>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 scrollbar-hide">
        {messages.map((m, i) => (
          <div key={i} className="flex gap-2">
            <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-[10px] font-black flex-shrink-0">
              {m.username?.[0]?.toUpperCase()}
            </div>
            <div>
              <span className="text-[11px] font-bold text-indigo-400">{m.username}</span>
              {m.vipLevel > 0 && <span className="ml-1 text-[10px]">{VIP_BADGE[m.vipLevel]}</span>}
              <p className="text-xs text-slate-300 mt-0.5 break-words">{m.message}</p>
            </div>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      <form onSubmit={send} className="p-3 border-t border-white/5 flex gap-2">
        <input value={input} onChange={e => setInput(e.target.value)}
          placeholder={user ? 'Say something...' : 'Login to chat'}
          disabled={!user} maxLength={200}
          className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-xs text-white placeholder-slate-500 outline-none focus:border-indigo-500 transition-colors disabled:opacity-40"/>
        <button type="submit" disabled={!user || !input.trim()}
          className="bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/5 text-white px-3 py-1.5 rounded-lg text-xs transition-colors">
          ↑
        </button>
      </form>
    </div>
  );
}
