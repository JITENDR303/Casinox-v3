import React from 'react';
import { useStore } from '../../store';

export default function BetInput({ value, onChange, disabled, label = 'Bet Amount' }) {
  const { user } = useStore();
  const balance  = parseFloat(user?.balance || 0);
  const bet      = parseFloat(value || 0);

  const set  = (v) => onChange(String(Math.max(1, parseFloat(v) || 1)));
  const half = () => set(Math.max(1, bet / 2).toFixed(2));
  const dbl  = () => set(Math.min(balance, bet * 2).toFixed(2));
  const max  = () => set(balance.toFixed(2));

  return (
    <div className="space-y-2">
      <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block">{label}</label>
      <div className={`flex items-center gap-2 bg-white/5 border rounded-xl px-3 py-2.5 transition-colors ${disabled ? 'opacity-50 border-white/5' : 'border-white/10 focus-within:border-indigo-500'}`}>
        <span className="text-slate-400 text-sm font-bold">₹</span>
        <input type="number" value={value} onChange={e => onChange(e.target.value)}
          min="1" step="1" disabled={disabled}
          className="flex-1 bg-transparent text-white font-mono font-bold outline-none disabled:cursor-not-allowed"
          placeholder="0"/>
      </div>
      <div className="grid grid-cols-4 gap-1.5">
        {[['½', half], ['2×', dbl], ['Max', max], ['Min', () => set(1)]].map(([l, fn]) => (
          <button key={l} onClick={fn} disabled={disabled}
            className="bg-white/5 hover:bg-white/10 border border-white/10 text-slate-400 hover:text-white text-xs py-1.5 rounded-lg transition-all disabled:opacity-40">
            {l}
          </button>
        ))}
      </div>
      <div className="flex gap-1.5 flex-wrap">
        {[10, 50, 100, 500].filter(v => v <= balance).map(v => (
          <button key={v} onClick={() => onChange(String(v))} disabled={disabled}
            className="bg-white/5 hover:bg-indigo-600/20 border border-white/10 hover:border-indigo-500/30 text-slate-400 hover:text-indigo-300 text-xs px-2 py-1 rounded-lg transition-all disabled:opacity-40">
            +₹{v}
          </button>
        ))}
      </div>
    </div>
  );
}
