import { create } from 'zustand';
import axios from 'axios';

const API = axios.create({ baseURL: '/api' });
API.interceptors.request.use(cfg => {
  const t = localStorage.getItem('cx_token');
  if (t) cfg.headers.Authorization = `Bearer ${t}`;
  return cfg;
});

export const useStore = create((set) => ({
  user: null,
  token: localStorage.getItem('cx_token'),
  liveBets: [],
  onlineCount: 0,

  setUser:        (user)    => set({ user }),
  updateBalance:  (balance) => set(s => ({ user: s.user ? { ...s.user, balance } : null })),
  addLiveBet:     (bet)     => set(s => ({ liveBets: [bet, ...s.liveBets].slice(0, 25) })),
  setOnlineCount: (count)   => set({ onlineCount: count }),

  login: async (username, password) => {
    try {
      const { data } = await API.post('/auth/login', { username, password });
      localStorage.setItem('cx_token', data.token);
      set({ user: data.user, token: data.token });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.response?.data?.error || 'Login failed' };
    }
  },

  register: async (username, email, password, referralCode) => {
    try {
      const { data } = await API.post('/auth/register', { username, email, password, referralCode });
      localStorage.setItem('cx_token', data.token);
      set({ user: data.user, token: data.token });
      return { success: true };
    } catch (err) {
      return { success: false, error: err.response?.data?.error || 'Registration failed' };
    }
  },

  logout: () => {
    localStorage.removeItem('cx_token');
    set({ user: null, token: null });
  },

  fetchUser: async () => {
    try {
      const { data } = await API.get('/auth/me');
      set({ user: data.user });
    } catch {
      localStorage.removeItem('cx_token');
      set({ user: null, token: null });
    }
  },
}));

export { API };
