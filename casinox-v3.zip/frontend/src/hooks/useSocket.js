import { useEffect, useRef } from 'react';
import { io } from 'socket.io-client';
import { useStore } from '../store';

let socket = null;

export function useSocket() {
  const { token, updateBalance, addLiveBet, setOnlineCount } = useStore();
  const initialized = useRef(false);

  useEffect(() => {
    if (initialized.current) return;
    initialized.current = true;

    socket = io('/', {
      auth: { token },
      transports: ['websocket', 'polling'],
      reconnectionAttempts: 5,
      reconnectionDelay: 1000,
    });

    socket.on('live:bet',       (bet)       => addLiveBet(bet));
    socket.on('online:count',   ({ count }) => setOnlineCount(count));
    socket.on('balance:update', ({ balance }) => updateBalance(balance));

    socket.on('connect_error', (err) => console.warn('Socket error:', err.message));
  }, []);

  return socket;
}

export const getSocket = () => socket;
