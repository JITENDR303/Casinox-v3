import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

export default function CoinFlipPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [choice, setChoice] = useState('heads');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const [flipping, setFlipping] = useState(false);
  const [history, setHistory] = useState([]);

  const play = async () => {
    if (loading) return;
    setLoading(true);
    setFlipping(true);
    setResult(null);
    try {
      await new Promise(r => setTimeout(r, 800)); // animation delay
      const { data } = await API.post('/games/coinflip', { betAmount: parseFloat(bet), choice });
      setResult(data);
      setFlipping(false);
      updateBalance(data.balance);
      setHistory(h => [{ ...data, choice, bet: parseFloat(bet) }, ...h].slice(0, 10));
      if (data.won) toast.success(`🎉 You won ₹${data.payout?.toFixed(2)}!`);
      else toast.error(`😔 It was ${data.result}. Better luck next time!`);
    } catch (err) {
      setFlipping(false);
      toast.error(err.response?.data?.error || 'Error');
    } finally { setLoading(false); }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🪙</span>
        <div>
          <h1 className="text-2xl font-black text-white">Coin Flip</h1>
          <p className="text-sm text-slate-400">Heads or Tails — 1.98x payout</p>
        </div>
      </div>

      {/* Coin display */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-8 flex flex-col items-center gap-6">
        <div className={`w-32 h-32 rounded-full flex items-center justify-center text-6xl transition-all duration-500 ${
          flipping ? 'animate-spin' : ''
        } ${
          result ? (result.result === 'heads' ? 'bg-amber-500/20 border-4 border-amber-500' : 'bg-slate-500/20 border-4 border-slate-500') : 'bg-white/5 border-4 border-white/10'
        }`}>
          {result ? (result.result === 'heads' ? '👑' : '🦅') : (choice === 'heads' ? '👑' : '🦅')}
        </div>

        {result && (
          <div className={`text-center ${result.won ? 'text-emerald-400' : 'text-red-400'}`}>
            <p className="text-2xl font-black">{result.won ? '🎉 You Win!' : '😔 You Lose'}</p>
            {result.won && <p className="text-lg font-bold">+₹{result.payout?.toFixed(2)}</p>}
          </div>
        )}

        {/* Choice buttons */}
        <div className="flex gap-4 w-full">
          {['heads', 'tails'].map(side => (
            <button
              key={side}
              onClick={() => setChoice(side)}
              className={`flex-1 py-3 rounded-xl font-bold text-sm transition-all capitalize flex items-center justify-center gap-2 ${
                choice === side
                  ? 'bg-indigo-600 text-white border border-indigo-500'
                  : 'bg-white/5 text-slate-400 border border-white/10 hover:bg-white/10'
              }`}
            >
              <span>{side === 'heads' ? '👑' : '🦅'}</span>
              {side}
            </button>
          ))}
        </div>
      </div>

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={loading} />
        <button
          onClick={play}
          disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all"
        >
          {loading ? 'Flipping...' : 'Flip Coin 🪙'}
        </button>
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
          <h3 className="text-sm font-semibold text-slate-400 mb-3">Recent Flips</h3>
          <div className="flex gap-2 flex-wrap">
            {history.map((h, i) => (
              <span key={i} className={`px-2 py-1 rounded-lg text-xs font-bold ${h.won ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                {h.result === 'heads' ? '👑' : '🦅'} {h.result}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
