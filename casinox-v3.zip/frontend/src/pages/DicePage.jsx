import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

export default function DicePage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [target, setTarget] = useState(50);
  const [direction, setDirection] = useState('over');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);

  const winChance = direction === 'over' ? (100 - target) : target;
  const multiplier = (0.99 / (winChance / 100)).toFixed(4);

  const roll = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/dice', { betAmount: parseFloat(bet), target, direction });
      setResult(data);
      updateBalance(data.balance);
      setHistory(h => [data, ...h].slice(0, 10));
      if (data.won) toast.success(`🎲 Rolled ${data.roll.toFixed(2)} — Won ₹${data.payout.toFixed(2)}!`);
      else toast.error(`🎲 Rolled ${data.roll.toFixed(2)} — Better luck next time`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Roll failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎲</span>
        <div>
          <h1 className="text-2xl font-black text-white">Dice</h1>
          <p className="text-sm text-slate-400">Roll over or under your target</p>
        </div>
      </div>

      {/* Result display */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-6">
        <div className="text-center mb-6">
          <p className="text-6xl font-black font-mono text-white transition-all duration-300">
            {result ? result.roll.toFixed(2) : '—'}
          </p>
          {result && (
            <p className={`text-lg font-bold mt-2 ${result.won ? 'text-emerald-400' : 'text-red-400'}`}>
              {result.won ? `🎉 Won ₹${result.payout.toFixed(2)}` : '😔 Lost'}
            </p>
          )}
        </div>

        {/* Slider track */}
        <div className="relative h-10 flex items-center">
          <div className="w-full h-2 rounded-full overflow-hidden flex">
            <div
              className={`h-full transition-all ${direction === 'under' ? 'bg-emerald-500' : 'bg-red-500/30'}`}
              style={{ width: `${target}%` }}
            />
            <div
              className={`h-full transition-all ${direction === 'over' ? 'bg-emerald-500' : 'bg-red-500/30'}`}
              style={{ width: `${100 - target}%` }}
            />
          </div>
          {/* Target marker */}
          <div
            className="absolute w-4 h-4 bg-white rounded-full border-2 border-indigo-500 shadow-lg cursor-pointer -translate-x-1/2"
            style={{ left: `${target}%` }}
          />
          {/* Roll result marker */}
          {result && (
            <div
              className={`absolute w-3 h-3 rounded-full -translate-x-1/2 transition-all duration-500 ${result.won ? 'bg-emerald-400' : 'bg-red-400'}`}
              style={{ left: `${result.roll}%`, top: '-4px' }}
            />
          )}
          <input
            type="range"
            min="2" max="98"
            value={target}
            onChange={e => setTarget(parseInt(e.target.value))}
            className="absolute inset-0 w-full opacity-0 cursor-pointer h-full"
          />
        </div>

        <div className="flex justify-between text-xs text-slate-500 mt-1">
          <span>0</span>
          <span className="text-white font-bold">{target}</span>
          <span>100</span>
        </div>
      </div>

      {/* Stats row */}
      <div className="grid grid-cols-3 gap-3">
        {[
          { label: 'Multiplier', value: `${multiplier}x`, color: 'text-indigo-400' },
          { label: 'Win Chance', value: `${winChance.toFixed(1)}%`, color: 'text-amber-400' },
          { label: 'Payout', value: `₹${(parseFloat(bet || 0) * parseFloat(multiplier)).toFixed(2)}`, color: 'text-emerald-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/3 border border-white/5 rounded-xl p-3 text-center">
            <p className="text-xs text-slate-500">{s.label}</p>
            <p className={`font-bold font-mono ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Direction toggle */}
      <div className="flex gap-2">
        {['over', 'under'].map(d => (
          <button
            key={d}
            onClick={() => setDirection(d)}
            className={`flex-1 py-2.5 rounded-xl font-bold text-sm capitalize transition-all ${
              direction === d ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10'
            }`}
          >
            Roll {d} {d === 'over' ? '⬆️' : '⬇️'} {target}
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={loading} />
        <button
          onClick={roll}
          disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all active:scale-95"
        >
          {loading ? '🎲 Rolling...' : 'Roll Dice 🎲'}
        </button>
      </div>

      {/* History pills */}
      {history.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          {history.map((h, i) => (
            <span
              key={i}
              className={`text-xs px-2.5 py-1 rounded-lg font-mono font-bold ${
                h.won ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'
              }`}
            >
              {h.roll.toFixed(0)}
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
