import React, { useState, useCallback } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const MINE_COUNTS = [1, 3, 5, 10, 15, 20, 24];

export default function MinesPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [mines, setMines] = useState(3);
  const [gameActive, setGameActive] = useState(false);
  const [sessionId, setSessionId] = useState(null);
  const [tiles, setTiles] = useState(Array(25).fill('hidden')); // 'hidden' | 'gem' | 'mine'
  const [multiplier, setMultiplier] = useState(1);
  const [currentPayout, setCurrentPayout] = useState(0);
  const [minePositions, setMinePositions] = useState([]);
  const [loading, setLoading] = useState(false);
  const [revealedCount, setRevealedCount] = useState(0);

  const startGame = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/mines/start', { betAmount: parseFloat(bet), minesCount: mines });
      setSessionId(data.sessionId);
      setGameActive(true);
      setTiles(Array(25).fill('hidden'));
      setMultiplier(1);
      setCurrentPayout(0);
      setRevealedCount(0);
      setMinePositions([]);
      updateBalance(data.balance);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to start');
    } finally { setLoading(false); }
  };

  const revealTile = async (index) => {
    if (!gameActive || tiles[index] !== 'hidden' || loading) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/mines/reveal', { sessionId, tileIndex: index });

      if (data.isMine) {
        const newTiles = [...tiles];
        newTiles[index] = 'mine';
        data.minePositions.forEach(p => { if (newTiles[p] === 'hidden') newTiles[p] = 'mine-revealed'; });
        setTiles(newTiles);
        setGameActive(false);
        setMinePositions(data.minePositions);
        toast.error('💥 Boom! You hit a mine!');
      } else {
        const newTiles = [...tiles];
        newTiles[index] = 'gem';
        setTiles(newTiles);
        setMultiplier(data.multiplier);
        setCurrentPayout(data.currentPayout || data.payout || 0);
        setRevealedCount(data.safeRevealed);

        if (data.autoWon) {
          setGameActive(false);
          updateBalance(data.balance);
          toast.success(`🎉 All gems found! Won ₹${data.payout?.toFixed(2)}`);
        }
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error');
    } finally { setLoading(false); }
  };

  const cashout = async () => {
    if (!gameActive || revealedCount === 0 || loading) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/mines/cashout', { sessionId });
      const newTiles = [...tiles];
      data.minePositions.forEach(p => { if (newTiles[p] === 'hidden') newTiles[p] = 'mine-revealed'; });
      setTiles(newTiles);
      setGameActive(false);
      updateBalance(data.balance);
      toast.success(`💎 Cashed out ₹${data.payout?.toFixed(2)} at ${data.multiplier}x!`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Cashout failed');
    } finally { setLoading(false); }
  };

  const getTileStyle = (state) => {
    switch (state) {
      case 'gem': return 'bg-emerald-500/20 border-emerald-500/50 text-emerald-400 scale-95';
      case 'mine': return 'bg-red-500/30 border-red-500/50 text-red-400 animate-pulse';
      case 'mine-revealed': return 'bg-red-900/20 border-red-800/30 text-red-600';
      default: return 'bg-white/5 border-white/10 hover:bg-indigo-500/10 hover:border-indigo-500/30 cursor-pointer active:scale-95';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">💣</span>
        <div>
          <h1 className="text-2xl font-black text-white">Mines</h1>
          <p className="text-sm text-slate-400">Reveal gems, avoid mines</p>
        </div>
      </div>

      <div className="grid md:grid-cols-[280px_1fr] gap-6">
        {/* Controls */}
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-5 h-fit">
          <BetInput value={bet} onChange={setBet} disabled={gameActive} />

          {/* Mines selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Mines Count</label>
            <div className="grid grid-cols-4 gap-1.5">
              {MINE_COUNTS.map(m => (
                <button
                  key={m}
                  onClick={() => !gameActive && setMines(m)}
                  disabled={gameActive}
                  className={`py-2 rounded-lg text-sm font-bold transition-all ${
                    mines === m
                      ? 'bg-red-600 text-white'
                      : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white disabled:opacity-50'
                  }`}
                >
                  {m}
                </button>
              ))}
            </div>
          </div>

          {/* Stats */}
          {gameActive && (
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Multiplier</span>
                <span className="font-bold text-emerald-400">{multiplier}x</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-slate-400">Current Win</span>
                <span className="font-bold text-white font-mono">₹{currentPayout.toFixed(2)}</span>
              </div>
            </div>
          )}

          {/* Action button */}
          {!gameActive ? (
            <button
              onClick={startGame}
              disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
              className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all"
            >
              {loading ? 'Starting...' : 'Start Game'}
            </button>
          ) : (
            <button
              onClick={cashout}
              disabled={loading || revealedCount === 0}
              className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all animate-pulse"
            >
              {loading ? 'Processing...' : `Cash Out ₹${currentPayout.toFixed(2)}`}
            </button>
          )}
        </div>

        {/* Grid */}
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5">
          <div className="grid grid-cols-5 gap-2.5">
            {tiles.map((state, i) => (
              <button
                key={i}
                onClick={() => revealTile(i)}
                disabled={!gameActive || state !== 'hidden' || loading}
                className={`aspect-square rounded-xl border text-2xl flex items-center justify-center transition-all duration-200 ${getTileStyle(state)}`}
              >
                {state === 'gem' && '💎'}
                {state === 'mine' && '💥'}
                {state === 'mine-revealed' && '💣'}
                {state === 'hidden' && (gameActive ? '❓' : '')}
              </button>
            ))}
          </div>

          {!gameActive && revealedCount === 0 && (
            <p className="text-center text-slate-500 text-sm mt-4">Place a bet and start the game to reveal tiles</p>
          )}
        </div>
      </div>
    </div>
  );
}
