import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

function Card({ card, hidden }) {
  if (hidden) return (
    <div className="w-14 h-20 rounded-lg bg-indigo-900 border-2 border-indigo-700 flex items-center justify-center text-2xl">🂠</div>
  );
  const isRed = ['♥', '♦'].includes(card?.suit);
  return (
    <div className={`w-14 h-20 rounded-lg bg-white border-2 border-slate-200 flex flex-col items-start justify-between p-1.5 shadow-md`}>
      <span className={`text-sm font-black ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.rank}</span>
      <span className={`text-xl self-center ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.suit}</span>
      <span className={`text-sm font-black self-end rotate-180 ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.rank}</span>
    </div>
  );
}

const OUTCOMES = {
  win:       { text: '🎉 You Win!',    color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20' },
  lose:      { text: '😔 Dealer Wins', color: 'text-red-400',     bg: 'bg-red-500/10 border-red-500/20' },
  push:      { text: '🤝 Push',        color: 'text-amber-400',   bg: 'bg-amber-500/10 border-amber-500/20' },
  bust:      { text: '💥 Bust!',       color: 'text-red-400',     bg: 'bg-red-500/10 border-red-500/20' },
  blackjack: { text: '🃏 Blackjack!',  color: 'text-amber-400',   bg: 'bg-amber-500/10 border-amber-500/20' },
};

export default function BlackjackPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [sessionId, setSessionId] = useState(null);
  const [playerHand, setPlayerHand] = useState([]);
  const [dealerHand, setDealerHand] = useState([]);
  const [dealerCard, setDealerCard] = useState(null);
  const [playerValue, setPlayerValue] = useState(0);
  const [dealerValue, setDealerValue] = useState(null);
  const [gameState, setGameState] = useState('idle'); // idle | playing | over
  const [outcome, setOutcome] = useState(null);
  const [payout, setPayout] = useState(0);
  const [loading, setLoading] = useState(false);

  const deal = async () => {
    if (loading) return;
    setLoading(true);
    setOutcome(null);
    setDealerValue(null);
    try {
      const { data } = await API.post('/games/blackjack/deal', { betAmount: parseFloat(bet) });
      updateBalance(data.balance);

      if (data.gameOver) {
        setPlayerHand(data.playerHand);
        setDealerHand(data.dealerHand);
        setPlayerValue(data.playerValue);
        setDealerValue(data.dealerValue);
        setOutcome(data.outcome);
        setPayout(data.payout);
        setGameState('over');
        toast(OUTCOMES[data.outcome]?.text);
      } else {
        setSessionId(data.sessionId);
        setPlayerHand(data.playerHand);
        setDealerCard(data.dealerCard);
        setDealerHand([]);
        setPlayerValue(data.playerValue);
        setGameState('playing');
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Deal failed');
    } finally { setLoading(false); }
  };

  const hit = async () => {
    if (loading || gameState !== 'playing') return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/blackjack/hit', { sessionId });
      setPlayerHand(data.playerHand);
      setPlayerValue(data.playerValue);

      if (data.gameOver) {
        setDealerHand(data.dealerHand);
        setDealerValue(null);
        setOutcome(data.outcome);
        setPayout(0);
        setGameState('over');
        toast.error('💥 Bust! Over 21!');
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Hit failed');
    } finally { setLoading(false); }
  };

  const stand = async () => {
    if (loading || gameState !== 'playing') return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/blackjack/stand', { sessionId });
      setPlayerHand(data.playerHand);
      setDealerHand(data.dealerHand);
      setPlayerValue(data.playerValue);
      setDealerValue(data.dealerValue);
      setOutcome(data.outcome);
      setPayout(data.payout);
      setGameState('over');
      updateBalance(data.balance);

      const o = OUTCOMES[data.outcome];
      if (data.outcome === 'win') toast.success(o.text);
      else if (data.outcome === 'push') toast(o.text);
      else toast.error(o.text);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Stand failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🃏</span>
        <div>
          <h1 className="text-2xl font-black text-white">Blackjack</h1>
          <p className="text-sm text-slate-400">Beat the dealer to 21</p>
        </div>
      </div>

      {/* Table */}
      <div className="bg-emerald-900/20 border border-emerald-900/30 rounded-2xl p-6 space-y-6">
        {/* Dealer */}
        <div>
          <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">Dealer {dealerValue !== null ? `(${dealerValue})` : ''}</p>
          <div className="flex gap-2">
            {gameState === 'idle' ? (
              <div className="w-14 h-20 rounded-lg bg-white/5 border-2 border-white/10" />
            ) : gameState === 'playing' ? (
              <>
                <Card card={dealerCard} />
                <div className="w-14 h-20 rounded-lg bg-indigo-900 border-2 border-indigo-700 flex items-center justify-center text-2xl">🂠</div>
              </>
            ) : (
              dealerHand.map((card, i) => <Card key={i} card={card} />)
            )}
          </div>
        </div>

        {/* Outcome banner */}
        {outcome && (
          <div className={`text-center py-3 rounded-xl border ${OUTCOMES[outcome]?.bg}`}>
            <p className={`text-xl font-black ${OUTCOMES[outcome]?.color}`}>{OUTCOMES[outcome]?.text}</p>
            {payout > 0 && <p className="text-sm text-slate-300">Payout: ₹{payout?.toFixed(2)}</p>}
          </div>
        )}

        {/* Player */}
        <div>
          <p className="text-xs text-slate-400 mb-3 uppercase tracking-wider">You {playerValue > 0 ? `(${playerValue})` : ''}</p>
          <div className="flex gap-2">
            {gameState === 'idle' ? (
              <div className="w-14 h-20 rounded-lg bg-white/5 border-2 border-white/10" />
            ) : (
              playerHand.map((card, i) => <Card key={i} card={card} />)
            )}
          </div>
        </div>
      </div>

      {/* Actions */}
      {gameState === 'playing' ? (
        <div className="grid grid-cols-2 gap-3">
          <button onClick={hit} disabled={loading} className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-white/10 text-white font-bold py-3 rounded-xl transition-colors">
            {loading ? '...' : 'Hit 👆'}
          </button>
          <button onClick={stand} disabled={loading} className="bg-red-600 hover:bg-red-500 disabled:bg-white/10 text-white font-bold py-3 rounded-xl transition-colors">
            {loading ? '...' : 'Stand ✋'}
          </button>
        </div>
      ) : (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
          <BetInput value={bet} onChange={setBet} disabled={gameState === 'playing'} />
          <button
            onClick={deal}
            disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
          >
            {loading ? 'Dealing...' : gameState === 'over' ? 'Deal Again 🃏' : 'Deal Cards 🃏'}
          </button>
        </div>
      )}
    </div>
  );
}
