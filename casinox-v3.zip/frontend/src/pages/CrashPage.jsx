import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useSocket } from '../hooks/useSocket';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

export default function CrashPage() {
  const socket = useSocket();
  const { user, updateBalance } = useStore();

  const [phase, setPhase] = useState('waiting'); // waiting | running | crashed
  const [multiplier, setMultiplier] = useState(1.0);
  const [crashAt, setCrashAt] = useState(null);
  const [countdown, setCountdown] = useState(7);
  const [bet, setBet] = useState('10');
  const [autoCashout, setAutoCashout] = useState('');
  const [myBet, setMyBet] = useState(null);
  const [cashedOut, setCashedOut] = useState(false);
  const [cashoutData, setCashoutData] = useState(null);
  const [players, setPlayers] = useState([]);
  const [history, setHistory] = useState([]);
  const canvasRef = useRef(null);
  const pointsRef = useRef([]);
  const animRef = useRef(null);

  // Draw graph
  const drawGraph = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    const pts = pointsRef.current;
    if (pts.length < 2) {
      // Draw baseline
      ctx.fillStyle = '#0f0f1a';
      ctx.fillRect(0, 0, w, h);
      ctx.strokeStyle = '#1e1e3a';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(30, h - 20);
      ctx.lineTo(w - 10, h - 20);
      ctx.stroke();
      return;
    }

    const maxMult = Math.max(...pts.map(p => p.m), 2);
    const toX = (i) => 30 + (i / (pts.length - 1)) * (w - 40);
    const toY = (m) => (h - 20) - ((m - 1) / (maxMult - 1)) * (h - 40);

    ctx.fillStyle = '#0f0f1a';
    ctx.fillRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = '#1e1e3a';
    ctx.lineWidth = 1;
    for (let m = 1; m <= maxMult; m += Math.max(1, Math.floor((maxMult - 1) / 4))) {
      const y = toY(m);
      ctx.beginPath();
      ctx.moveTo(30, y);
      ctx.lineTo(w, y);
      ctx.stroke();
      ctx.fillStyle = '#4a4a6a';
      ctx.font = '10px monospace';
      ctx.fillText(`${m}x`, 2, y + 4);
    }

    // Gradient fill
    const grad = ctx.createLinearGradient(0, 0, 0, h);
    const color = phase === 'crashed' ? '#ef4444' : '#6366f1';
    grad.addColorStop(0, color + '40');
    grad.addColorStop(1, color + '00');
    ctx.beginPath();
    ctx.moveTo(toX(0), h - 20);
    pts.forEach((p, i) => ctx.lineTo(toX(i), toY(p.m)));
    ctx.lineTo(toX(pts.length - 1), h - 20);
    ctx.closePath();
    ctx.fillStyle = grad;
    ctx.fill();

    // Line
    ctx.strokeStyle = phase === 'crashed' ? '#ef4444' : '#6366f1';
    ctx.lineWidth = 3;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    pts.forEach((p, i) => {
      if (i === 0) ctx.moveTo(toX(i), toY(p.m));
      else ctx.lineTo(toX(i), toY(p.m));
    });
    ctx.stroke();

    // Current point glow
    if (pts.length && phase !== 'crashed') {
      const last = pts[pts.length - 1];
      const cx = toX(pts.length - 1);
      const cy = toY(last.m);
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fillStyle = '#6366f1';
      ctx.fill();
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#6366f120';
      ctx.fill();
    }
  }, [phase]);

  useEffect(() => {
    drawGraph();
  }, [multiplier, phase, drawGraph]);

  // Socket events
  useEffect(() => {
    if (!socket) return;

    socket.on('crash:state', ({ phase: p, multiplier: m, players: pl }) => {
      setPhase(p);
      setMultiplier(m);
      setPlayers(pl || []);
    });

    socket.on('crash:waiting', ({ countdown: c }) => {
      setPhase('waiting');
      setCountdown(c);
      setMultiplier(1.0);
      setCrashAt(null);
      setMyBet(null);
      setCashedOut(false);
      setCashoutData(null);
      pointsRef.current = [];
      drawGraph();

      // Countdown timer
      let ct = c;
      const timer = setInterval(() => {
        ct--;
        setCountdown(ct);
        if (ct <= 0) clearInterval(timer);
      }, 1000);
    });

    socket.on('crash:start', () => {
      setPhase('running');
      pointsRef.current = [];
    });

    socket.on('crash:tick', ({ multiplier: m }) => {
      setMultiplier(m);
      pointsRef.current.push({ m });
      drawGraph();
    });

    socket.on('crash:crash', ({ crashAt: ca }) => {
      setPhase('crashed');
      setCrashAt(ca);
      setHistory(h => [ca, ...h].slice(0, 12));
      if (myBet && !cashedOut) toast.error(`💥 Crashed at ${ca}x!`);
    });

    socket.on('crash:players', ({ players: pl }) => setPlayers(pl || []));

    socket.on('crash:betplaced', ({ bet: b, balance: bal }) => {
      setMyBet(b);
      updateBalance(bal);
    });

    socket.on('crash:cashedout', ({ multiplier: m, payout, balance: bal }) => {
      setCashedOut(true);
      setCashoutData({ multiplier: m, payout });
      updateBalance(bal);
      toast.success(`🚀 Cashed out at ${m}x — Won ₹${payout.toFixed(2)}!`);
    });

    socket.on('crash:error', ({ message }) => toast.error(message));

    return () => {
      ['crash:state','crash:waiting','crash:start','crash:tick','crash:crash','crash:players','crash:betplaced','crash:cashedout','crash:error']
        .forEach(ev => socket.off(ev));
    };
  }, [socket, myBet, cashedOut, drawGraph]);

  const placeBet = () => {
    if (!socket || !user) return;
    socket.emit('crash:bet', { betAmount: parseFloat(bet), autoCashout: autoCashout ? parseFloat(autoCashout) : null });
  };

  const cashout = () => {
    if (!socket) return;
    socket.emit('crash:cashout');
  };

  const multColor = (m) => {
    if (m < 1.5) return 'text-slate-400';
    if (m < 2) return 'text-blue-400';
    if (m < 5) return 'text-emerald-400';
    if (m < 10) return 'text-amber-400';
    return 'text-red-400';
  };

  return (
    <div className="max-w-4xl mx-auto space-y-5">
      <div className="flex items-center gap-3">
        <span className="text-3xl">📈</span>
        <div>
          <h1 className="text-2xl font-black text-white">Crash</h1>
          <p className="text-sm text-slate-400">Cash out before it crashes!</p>
        </div>
      </div>

      {/* Graph */}
      <div className="bg-[#0f0f1a] border border-white/5 rounded-2xl overflow-hidden relative">
        {/* Multiplier overlay */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          {phase === 'waiting' && (
            <div className="text-center">
              <p className="text-slate-400 text-sm mb-2">Starting in</p>
              <p className="text-7xl font-black text-white">{countdown}</p>
            </div>
          )}
          {phase === 'running' && (
            <div className="text-center">
              <p className={`text-7xl font-black font-mono transition-all ${multiplier >= 2 ? 'text-emerald-400' : 'text-white'}`}>
                {multiplier.toFixed(2)}x
              </p>
              {myBet && !cashedOut && (
                <p className="text-emerald-400 text-sm mt-2 animate-pulse">
                  +₹{(myBet * multiplier).toFixed(2)}
                </p>
              )}
            </div>
          )}
          {phase === 'crashed' && (
            <div className="text-center">
              <p className="text-red-400 text-2xl font-black mb-1">💥 CRASHED</p>
              <p className="text-6xl font-black text-red-400">{crashAt}x</p>
            </div>
          )}
        </div>

        <canvas
          ref={canvasRef}
          width={700}
          height={280}
          className="w-full"
          style={{ display: 'block' }}
        />
      </div>

      {/* History chips */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {history.map((m, i) => (
          <span key={i} className={`flex-shrink-0 text-xs px-2.5 py-1 rounded-lg font-mono font-bold ${
            m < 1.5 ? 'bg-red-500/20 text-red-400' :
            m < 2 ? 'bg-slate-500/20 text-slate-300' :
            m < 10 ? 'bg-emerald-500/20 text-emerald-400' :
            'bg-amber-500/20 text-amber-400'
          }`}>
            {m}x
          </span>
        ))}
      </div>

      <div className="grid md:grid-cols-[1fr_280px] gap-5">
        {/* Players list */}
        <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
          <div className="px-4 py-3 border-b border-white/5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Players ({players.length})</p>
          </div>
          <div className="divide-y divide-white/5 max-h-48 overflow-y-auto">
            {players.length === 0 ? (
              <p className="text-slate-500 text-xs text-center py-6">No bets yet this round</p>
            ) : players.map((p, i) => (
              <div key={i} className="flex items-center justify-between px-4 py-2">
                <div className="flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs">
                    {p.username?.[0]?.toUpperCase()}
                  </div>
                  <span className="text-sm text-white">{p.username}</span>
                </div>
                <span className="text-sm font-mono text-emerald-400">₹{p.bet}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Bet controls */}
        <div className="bg-white/3 border border-white/5 rounded-2xl p-4 space-y-4 h-fit">
          {cashedOut && cashoutData ? (
            <div className="text-center py-4">
              <p className="text-emerald-400 text-xl font-black">🚀 Cashed Out!</p>
              <p className="text-white text-2xl font-black font-mono">{cashoutData.multiplier}x</p>
              <p className="text-emerald-400 font-mono">+₹{cashoutData.payout.toFixed(2)}</p>
            </div>
          ) : (
            <>
              <BetInput value={bet} onChange={setBet} disabled={phase !== 'waiting' || !!myBet} />

              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">
                  Auto Cashout (optional)
                </label>
                <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-2">
                  <input
                    type="number"
                    value={autoCashout}
                    onChange={e => setAutoCashout(e.target.value)}
                    placeholder="e.g. 2.00"
                    step="0.1"
                    min="1.01"
                    disabled={phase !== 'waiting' || !!myBet}
                    className="flex-1 bg-transparent text-white font-mono text-sm outline-none disabled:opacity-50 placeholder-slate-500"
                  />
                  <span className="text-slate-400 text-sm">x</span>
                </div>
              </div>

              {phase === 'waiting' && !myBet && (
                <button
                  onClick={placeBet}
                  disabled={!user || parseFloat(bet) > parseFloat(user?.balance || 0)}
                  className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all"
                >
                  Place Bet 🎯
                </button>
              )}

              {phase === 'waiting' && myBet && (
                <div className="text-center py-2">
                  <p className="text-emerald-400 text-sm font-semibold">✓ Bet placed: ₹{myBet}</p>
                  <p className="text-slate-500 text-xs">Waiting for round to start…</p>
                </div>
              )}

              {phase === 'running' && myBet && !cashedOut && (
                <button
                  onClick={cashout}
                  className="w-full bg-emerald-500 hover:bg-emerald-400 text-white font-black py-4 rounded-xl transition-all animate-pulse text-lg"
                >
                  CASH OUT<br />
                  <span className="text-base font-mono">₹{(myBet * multiplier).toFixed(2)}</span>
                </button>
              )}

              {phase === 'running' && !myBet && (
                <p className="text-center text-slate-500 text-sm py-2">Wait for next round to bet</p>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
