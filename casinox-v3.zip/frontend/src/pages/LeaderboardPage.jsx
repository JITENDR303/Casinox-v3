import React, { useEffect, useState } from 'react';
import { API } from '../store';

const MEDAL = ['🥇', '🥈', '🥉'];

export default function LeaderboardPage() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    API.get('/games/leaderboard')
      .then(({ data }) => setData(data.leaderboard || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🏆</span>
        <div>
          <h1 className="text-2xl font-black text-white">Leaderboard</h1>
          <p className="text-sm text-slate-400">Top winners this week</p>
        </div>
      </div>

      {/* Top 3 podium */}
      {!loading && data.length >= 3 && (
        <div className="flex items-end justify-center gap-4 py-4">
          {[data[1], data[0], data[2]].map((entry, i) => {
            const rankIndex = i === 0 ? 1 : i === 1 ? 0 : 2;
            const heights = ['h-28', 'h-36', 'h-24'];
            const colors = ['bg-slate-400/10 border-slate-400/20', 'bg-amber-400/10 border-amber-400/30', 'bg-amber-600/10 border-amber-600/20'];
            if (!entry) return null;
            return (
              <div key={rankIndex} className={`flex flex-col items-center gap-2 ${heights[i]}`}>
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-lg font-black">
                  {entry.username?.[0]?.toUpperCase()}
                </div>
                <p className="text-xs font-bold text-white text-center truncate w-20 text-center">{entry.username}</p>
                <div className={`flex-1 w-full rounded-t-xl border flex flex-col items-center justify-end pb-2 min-w-[80px] ${colors[i]}`}>
                  <span className="text-xl">{MEDAL[rankIndex]}</span>
                  <p className="text-xs font-bold text-emerald-400 font-mono">₹{parseFloat(entry.totalProfit || 0).toFixed(0)}</p>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Full list */}
      <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
        <div className="px-4 py-3 border-b border-white/5 grid grid-cols-4 text-xs font-semibold text-slate-400 uppercase tracking-wider">
          <span>Rank</span>
          <span>Player</span>
          <span className="text-right">Profit</span>
          <span className="text-right">Best Multi</span>
        </div>

        {loading ? (
          <div className="text-center py-12 text-slate-500">Loading...</div>
        ) : data.length === 0 ? (
          <div className="text-center py-12 text-slate-500">No data yet. Start playing!</div>
        ) : (
          <div className="divide-y divide-white/5">
            {data.map((entry, i) => (
              <div key={i} className={`grid grid-cols-4 items-center px-4 py-3 hover:bg-white/2 transition-colors ${i < 3 ? 'bg-white/1' : ''}`}>
                <div className="flex items-center gap-2">
                  {i < 3
                    ? <span className="text-xl">{MEDAL[i]}</span>
                    : <span className="text-sm font-bold text-slate-500 w-6 text-center">#{i + 1}</span>
                  }
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-bold">
                    {entry.username?.[0]?.toUpperCase()}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white">{entry.username}</p>
                    {entry.vipLevel > 0 && (
                      <p className="text-xs text-amber-400">VIP {entry.vipLevel}</p>
                    )}
                  </div>
                </div>
                <p className="text-right text-sm font-bold font-mono text-emerald-400">
                  +₹{parseFloat(entry.totalProfit || 0).toFixed(0)}
                </p>
                <p className="text-right text-sm font-mono text-amber-400">
                  {parseFloat(entry.bestMult || 0).toFixed(2)}x
                </p>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
