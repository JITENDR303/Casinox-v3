import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const RANK_ORDER = ['2','3','4','5','6','7','8','9','10','J','Q','K','A'];

function PlayingCard({ card, hidden = false, animated = false }) {
  const isRed = card && ['♥','♦'].includes(card.suit);
  return (
    <div className={`w-20 h-28 rounded-xl border-2 flex flex-col items-center justify-between p-2 shadow-xl transition-all duration-300 ${
      animated ? 'scale-110 shadow-indigo-500/30' : ''
    } ${
      hidden
        ? 'bg-indigo-900/80 border-indigo-700'
        : 'bg-white border-slate-200'
    }`}>
      {hidden ? (
        <div className="flex-1 flex items-center justify-center text-3xl">🂠</div>
      ) : (
        <>
          <span className={`text-sm font-black self-start ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.rank}</span>
          <span className={`text-3xl ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.suit}</span>
          <span className={`text-sm font-black self-end rotate-180 ${isRed ? 'text-red-500' : 'text-slate-900'}`}>{card?.rank}</span>
        </>
      )}
    </div>
  );
}

export default function HiloPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet]           = useState('10');
  const [sessionId, setSessionId]   = useState(null);
  const [currentCard, setCurrentCard]   = useState(null);
  const [nextCard, setNextCard]         = useState(null);
  const [history, setHistory]           = useState([]);
  const [multiplier, setMultiplier]     = useState(1);
  const [currentPayout, setCurrentPayout] = useState(0);
  const [gameState, setGameState]       = useState('idle'); // idle | playing | over
  const [outcome, setOutcome]           = useState(null);
  const [loading, setLoading]           = useState(false);
  const [lastGuess, setLastGuess]       = useState(null);
  const [showNextCard, setShowNextCard] = useState(false);

  const rankIdx = currentCard ? RANK_ORDER.indexOf(currentCard.rank) : -1;
  const higherChance = currentCard ? parseFloat(((RANK_ORDER.length - rankIdx - 1) / RANK_ORDER.length * 100).toFixed(1)) : 0;
  const lowerChance  = currentCard ? parseFloat((rankIdx / RANK_ORDER.length * 100).toFixed(1)) : 0;

  const deal = async () => {
    if (loading) return;
    setLoading(true);
    setHistory([]); setNextCard(null); setOutcome(null); setShowNextCard(false);
    try {
      const { data } = await API.post('/games/hilo/start', { betAmount: parseFloat(bet) });
      setSessionId(data.sessionId);
      setCurrentCard(data.currentCard);
      setMultiplier(1);
      setCurrentPayout(parseFloat(bet));
      setGameState('playing');
      updateBalance(data.balance);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Deal failed');
    } finally { setLoading(false); }
  };

  const guess = async (g) => {
    if (loading || gameState !== 'playing') return;
    setLoading(true);
    setLastGuess(g);
    setShowNextCard(false);
    try {
      const { data } = await API.post('/games/hilo/guess', { sessionId, guess: g });
      setShowNextCard(true);
      setNextCard(data.nextCard);

      setTimeout(() => {
        if (!data.correct) {
          setGameState('over');
          setOutcome('lose');
          setHistory(data.history || []);
          toast.error(`😔 ${data.nextCard.rank}${data.nextCard.suit} — Wrong guess!`);
        } else {
          setCurrentCard(data.nextCard);
          setNextCard(null);
          setShowNextCard(false);
          setMultiplier(data.multiplier);
          setCurrentPayout(data.currentPayout);
          setHistory(data.history || []);
        }
        setLoading(false);
      }, 600);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Guess failed');
      setLoading(false);
    }
  };

  const cashout = async () => {
    if (loading || gameState !== 'playing' || history.length === 0) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/hilo/cashout', { sessionId });
      setGameState('over');
      setOutcome('win');
      updateBalance(data.balance);
      toast.success(`💰 Cashed out ₹${data.payout?.toFixed(2)} at ${data.multiplier}x!`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Cashout failed');
    } finally { setLoading(false); }
  };

  const rankLabel = (rank) => {
    const labels = { 'J':'Jack','Q':'Queen','K':'King','A':'Ace' };
    return labels[rank] || rank;
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🃏</span>
        <div>
          <h1 className="text-2xl font-black text-white">Hilo</h1>
          <p className="text-sm text-slate-400">Predict if the next card is higher or lower</p>
        </div>
      </div>

      {/* Card display */}
      <div className="bg-gradient-to-b from-slate-800/50 to-slate-900/50 border border-white/5 rounded-2xl p-8">
        <div className="flex items-center justify-center gap-6 mb-6">
          {/* Previous card */}
          {history.length > 0 && history[history.length - 2] && (
            <div className="opacity-40">
              <PlayingCard card={history[history.length - 2]?.card} />
            </div>
          )}

          {/* Current card */}
          {currentCard ? (
            <div className="flex flex-col items-center gap-2">
              <PlayingCard card={currentCard} animated={gameState === 'playing'} />
              <span className="text-xs text-slate-400">{rankLabel(currentCard.rank)} of {currentCard.suit}</span>
            </div>
          ) : (
            <PlayingCard hidden />
          )}

          {/* Arrow */}
          {lastGuess && (
            <div className={`text-3xl transition-all ${loading ? 'animate-pulse' : ''}`}>
              {lastGuess === 'higher' ? '⬆️' : lastGuess === 'lower' ? '⬇️' : '↔️'}
            </div>
          )}

          {/* Next card reveal */}
          {showNextCard && nextCard && (
            <div className="flex flex-col items-center gap-2">
              <PlayingCard card={nextCard} animated />
              <span className="text-xs text-slate-400">{rankLabel(nextCard.rank)} of {nextCard.suit}</span>
            </div>
          )}
        </div>

        {/* Rank indicator */}
        {currentCard && gameState === 'playing' && (
          <div className="flex items-center gap-1 mb-4">
            {RANK_ORDER.map((r, i) => (
              <div key={r}
                className={`flex-1 h-1.5 rounded-full transition-all ${
                  r === currentCard.rank ? 'bg-white scale-y-150' :
                  i < rankIdx ? 'bg-red-500/40' : 'bg-emerald-500/40'
                }`}
              />
            ))}
          </div>
        )}

        {/* Stats */}
        {gameState === 'playing' && (
          <div className="grid grid-cols-3 gap-3 text-center">
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Multiplier</p>
              <p className="font-bold text-emerald-400">{multiplier.toFixed(3)}x</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Payout</p>
              <p className="font-bold text-white font-mono">₹{currentPayout?.toFixed(2)}</p>
            </div>
            <div>
              <p className="text-xs text-slate-500 mb-0.5">Correct</p>
              <p className="font-bold text-indigo-400">{history.filter(h => h.correct).length}</p>
            </div>
          </div>
        )}

        {/* Outcome */}
        {gameState === 'over' && (
          <div className={`text-center py-3 rounded-xl ${outcome === 'win' ? 'bg-emerald-500/10' : 'bg-red-500/10'}`}>
            <p className={`text-xl font-black ${outcome === 'win' ? 'text-emerald-400' : 'text-red-400'}`}>
              {outcome === 'win' ? '🎉 Cashed Out!' : '😔 Wrong Guess'}
            </p>
          </div>
        )}
      </div>

      {/* Guess buttons */}
      {gameState === 'playing' && (
        <div className="grid grid-cols-3 gap-3">
          <button onClick={() => guess('higher')} disabled={loading}
            className="bg-emerald-600 hover:bg-emerald-500 disabled:bg-white/10 text-white font-bold py-4 rounded-xl transition-all flex flex-col items-center gap-1">
            <span className="text-xl">⬆️</span>
            <span className="text-sm">Higher</span>
            <span className="text-xs opacity-70">{higherChance}%</span>
          </button>
          <button onClick={cashout} disabled={loading || history.length === 0}
            className="bg-amber-500 hover:bg-amber-400 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-4 rounded-xl transition-all flex flex-col items-center gap-1">
            <span className="text-xl">💰</span>
            <span className="text-sm">Cash Out</span>
            <span className="text-xs opacity-70">₹{currentPayout?.toFixed(2)}</span>
          </button>
          <button onClick={() => guess('lower')} disabled={loading}
            className="bg-red-600 hover:bg-red-500 disabled:bg-white/10 text-white font-bold py-4 rounded-xl transition-all flex flex-col items-center gap-1">
            <span className="text-xl">⬇️</span>
            <span className="text-sm">Lower</span>
            <span className="text-xs opacity-70">{lowerChance}%</span>
          </button>
        </div>
      )}

      {/* Bet controls */}
      {gameState !== 'playing' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
          <BetInput value={bet} onChange={setBet} disabled={loading} />
          <button onClick={deal} disabled={loading || !user || parseFloat(bet) > (user?.balance || 0)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all">
            {loading ? 'Dealing...' : gameState === 'over' ? 'Play Again 🃏' : 'Deal Cards 🃏'}
          </button>
        </div>
      )}

      {/* History row */}
      {history.length > 0 && (
        <div className="flex gap-2 overflow-x-auto pb-1">
          {history.map((h, i) => (
            <div key={i} className={`flex-shrink-0 flex flex-col items-center gap-1 px-2 py-1.5 rounded-lg border text-xs ${
              h.correct ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                        : 'bg-red-500/10 border-red-500/20 text-red-400'
            }`}>
              <span>{h.card?.rank}{h.card?.suit}</span>
              <span>{h.guess === 'higher' ? '⬆' : h.guess === 'lower' ? '⬇' : '↔'}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
