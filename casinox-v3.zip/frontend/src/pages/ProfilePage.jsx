import React, { useEffect, useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import toast from 'react-hot-toast';

const VIP_LEVELS = [
  { level: 0, name: 'Bronze',   min: 0,      color: 'text-amber-600',  icon: '🥉' },
  { level: 1, name: 'Silver',   min: 1000,   color: 'text-slate-300',  icon: '🥈' },
  { level: 2, name: 'Gold',     min: 5000,   color: 'text-amber-400',  icon: '🥇' },
  { level: 3, name: 'Platinum', min: 25000,  color: 'text-cyan-400',   icon: '💎' },
  { level: 4, name: 'Diamond',  min: 100000, color: 'text-purple-400', icon: '👑' },
];

export default function ProfilePage() {
  const { user } = useStore();
  const [history, setHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState('history');
  const [pwForm, setPwForm] = useState({ current: '', newPw: '', confirm: '' });
  const [pwLoading, setPwLoading] = useState(false);

  useEffect(() => {
    API.get('/games/history')
      .then(({ data }) => setHistory(data.history || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const changePassword = async (e) => {
    e.preventDefault();
    if (pwForm.newPw !== pwForm.confirm) return toast.error('Passwords do not match');
    setPwLoading(true);
    try {
      await API.post('/auth/change-password', { currentPassword: pwForm.current, newPassword: pwForm.newPw });
      toast.success('Password updated!');
      setPwForm({ current: '', newPw: '', confirm: '' });
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed');
    } finally { setPwLoading(false); }
  };

  const wagered = parseFloat(user?.totalWagered || 0);
  const vipInfo = VIP_LEVELS.reduce((acc, v) => wagered >= v.min ? v : acc, VIP_LEVELS[0]);
  const nextVip = VIP_LEVELS[vipInfo.level + 1];
  const progress = nextVip
    ? Math.min(100, ((wagered - vipInfo.min) / (nextVip.min - vipInfo.min)) * 100)
    : 100;

  const totalGames = history.length;
  const wonGames   = history.filter(g => g.won).length;
  const winRate    = totalGames ? ((wonGames / totalGames) * 100).toFixed(1) : '0.0';
  const biggestWin = history.reduce((max, g) => Math.max(max, parseFloat(g.payout || 0)), 0);

  const GAME_ICONS = { crash:'📈', mines:'💣', dice:'🎲', slots:'🎰', coinflip:'🪙', wheel:'🎪', plinko:'🎯', blackjack:'🃏', roulette:'🎡' };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      {/* Header card */}
      <div className="bg-gradient-to-br from-indigo-900/40 to-purple-900/20 border border-indigo-500/20 rounded-2xl p-6 flex items-start gap-5">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-2xl font-black text-white shadow-lg flex-shrink-0">
          {user?.username?.[0]?.toUpperCase()}
        </div>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black text-white">{user?.username}</h1>
          <p className="text-sm text-slate-400">{user?.email}</p>
          <div className="flex items-center gap-2 mt-2">
            <span className={`text-sm font-bold ${vipInfo.color}`}>{vipInfo.icon} {vipInfo.name}</span>
            <span className="text-slate-600">•</span>
            <span className="text-sm text-emerald-400 font-mono">₹{parseFloat(user?.balance || 0).toFixed(2)}</span>
          </div>
        </div>
      </div>

      {/* VIP progress */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-3">
        <div className="flex justify-between items-center">
          <p className="text-sm font-semibold text-white">VIP Progress</p>
          {nextVip && <p className="text-xs text-slate-400">₹{(nextVip.min - wagered).toFixed(0)} to {nextVip.name}</p>}
        </div>
        <div className="h-2.5 bg-white/5 rounded-full overflow-hidden">
          <div
            className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full transition-all duration-500"
            style={{ width: `${progress}%` }}
          />
        </div>
        <div className="flex justify-between text-xs text-slate-500">
          <span>{vipInfo.icon} {vipInfo.name} (₹{vipInfo.min.toLocaleString()})</span>
          {nextVip && <span>{nextVip.icon} {nextVip.name} (₹{nextVip.min.toLocaleString()})</span>}
        </div>
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label: 'Total Wagered', value: `₹${wagered.toFixed(0)}`, color: 'text-blue-400' },
          { label: 'Total Won',     value: `₹${parseFloat(user?.totalWon || 0).toFixed(0)}`, color: 'text-emerald-400' },
          { label: 'Win Rate',      value: `${winRate}%`, color: 'text-amber-400' },
          { label: 'Biggest Win',   value: `₹${biggestWin.toFixed(2)}`, color: 'text-purple-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/3 border border-white/5 rounded-xl p-3 text-center">
            <p className="text-xs text-slate-500 mb-1">{s.label}</p>
            <p className={`font-bold font-mono ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Referral code */}
      <div className="bg-indigo-600/10 border border-indigo-500/20 rounded-2xl p-4 flex items-center justify-between gap-4">
        <div>
          <p className="text-sm font-semibold text-white">Your Referral Code</p>
          <p className="text-xs text-slate-400">Invite friends and earn bonuses</p>
        </div>
        <button
          onClick={() => { navigator.clipboard.writeText(user?.referralCode || ''); toast.success('Copied!'); }}
          className="flex items-center gap-2 bg-indigo-600/30 hover:bg-indigo-600/50 border border-indigo-500/30 px-4 py-2 rounded-xl transition-colors"
        >
          <code className="text-indigo-300 font-mono font-bold text-sm">{user?.referralCode}</code>
          <span className="text-slate-400 hover:text-white">📋</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-white/3 border border-white/5 rounded-xl p-1">
        {['history', 'security'].map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${
              tab === t ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t === 'history' ? '📋 Game History' : '🔐 Security'}
          </button>
        ))}
      </div>

      {/* History tab */}
      {tab === 'history' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
          {loading ? (
            <p className="text-center text-slate-500 py-8">Loading...</p>
          ) : history.length === 0 ? (
            <p className="text-center text-slate-500 py-8 text-sm">No game history yet. Start playing!</p>
          ) : (
            <div className="divide-y divide-white/5">
              {history.map((g, i) => (
                <div key={i} className="flex items-center justify-between px-4 py-3">
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{GAME_ICONS[g.gameType] || '🎲'}</span>
                    <div>
                      <p className="text-sm font-semibold text-white capitalize">{g.gameType}</p>
                      <p className="text-xs text-slate-500">{new Date(g.createdAt).toLocaleDateString()} • {g.multiplier}x</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className={`text-sm font-bold font-mono ${g.won ? 'text-emerald-400' : 'text-red-400'}`}>
                      {g.won ? `+₹${parseFloat(g.profit).toFixed(2)}` : `-₹${parseFloat(g.betAmount).toFixed(2)}`}
                    </p>
                    <p className="text-xs text-slate-500">Bet: ₹{parseFloat(g.betAmount).toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Security tab */}
      {tab === 'security' && (
        <form onSubmit={changePassword} className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-white">Change Password</h3>
          {[
            { label: 'Current Password', key: 'current', placeholder: 'Your current password' },
            { label: 'New Password',     key: 'newPw',   placeholder: 'At least 6 characters' },
            { label: 'Confirm New',      key: 'confirm', placeholder: 'Repeat new password' },
          ].map(f => (
            <div key={f.key}>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-1.5">{f.label}</label>
              <input
                type="password"
                placeholder={f.placeholder}
                value={pwForm[f.key]}
                onChange={e => setPwForm(p => ({ ...p, [f.key]: e.target.value }))}
                className="w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors"
                required
              />
            </div>
          ))}
          <button
            type="submit"
            disabled={pwLoading}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
          >
            {pwLoading ? 'Updating...' : 'Update Password 🔐'}
          </button>
        </form>
      )}
    </div>
  );
}
