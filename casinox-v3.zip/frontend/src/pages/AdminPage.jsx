import React, { useState, useEffect } from 'react';
import { API } from '../store';
import toast from 'react-hot-toast';

const StatCard = ({ label, value, sub, color = 'text-white', icon }) => (
  <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
    <p className="text-xs text-slate-500 mb-1">{icon} {label}</p>
    <p className={`text-xl font-black font-mono ${color}`}>{value}</p>
    {sub && <p className="text-xs text-slate-500 mt-0.5">{sub}</p>}
  </div>
);

export default function AdminPage() {
  const [tab, setTab] = useState('stats');
  const [stats, setStats] = useState(null);
  const [deposits, setDeposits] = useState([]);
  const [withdrawals, setWithdrawals] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [userSearch, setUserSearch] = useState('');
  const [balanceModal, setBalanceModal] = useState(null);
  const [balanceAmt, setBalanceAmt] = useState('');
  const [balanceReason, setBalanceReason] = useState('');
  const [rejectModal, setRejectModal] = useState(null);
  const [rejectReason, setRejectReason] = useState('');
  const [depFilter, setDepFilter] = useState('submitted');
  const [screenshotModal, setScreenshotModal] = useState(null);

  useEffect(() => { fetchAll(); }, []);
  useEffect(() => {
    if (tab === 'deposits') fetchDeposits();
    if (tab === 'withdrawals') fetchWithdrawals();
    if (tab === 'users') fetchUsers();
  }, [tab, depFilter]);

  const fetchAll = async () => {
    try {
      const [s, d, w, u] = await Promise.all([
        API.get('/admin/stats'),
        API.get('/wallet/admin/deposits?status=submitted'),
        API.get('/wallet/admin/withdrawals?status=pending'),
        API.get('/admin/users'),
      ]);
      setStats(s.data);
      setDeposits(d.data.deposits);
      setWithdrawals(w.data.withdrawals);
      setUsers(u.data.users);
    } catch (err) {
      toast.error('Failed to load admin data');
    } finally { setLoading(false); }
  };

  const fetchDeposits = async () => {
    const { data } = await API.get(`/wallet/admin/deposits?status=${depFilter}`);
    setDeposits(data.deposits);
  };

  const fetchWithdrawals = async () => {
    const { data } = await API.get('/wallet/admin/withdrawals?status=pending');
    setWithdrawals(data.withdrawals);
  };

  const fetchUsers = async () => {
    const { data } = await API.get(`/admin/users?search=${userSearch}`);
    setUsers(data.users);
  };

  const approveDeposit = async (id) => {
    try {
      await API.post(`/wallet/admin/deposit/${id}/approve`);
      toast.success('Deposit approved ✓');
      fetchDeposits();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const rejectDeposit = async (id) => {
    try {
      await API.post(`/wallet/admin/deposit/${id}/reject`, { reason: rejectReason });
      toast.success('Deposit rejected');
      setRejectModal(null); setRejectReason('');
      fetchDeposits();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const approveWithdraw = async (id) => {
    try {
      await API.post(`/wallet/admin/withdrawal/${id}/approve`);
      toast.success('Withdrawal approved ✓');
      fetchWithdrawals();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const rejectWithdraw = async (id) => {
    try {
      await API.post(`/wallet/admin/withdrawal/${id}/reject`, { reason: rejectReason });
      toast.success('Withdrawal rejected & balance refunded');
      setRejectModal(null); setRejectReason('');
      fetchWithdrawals();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const adjustBalance = async () => {
    if (!balanceAmt || !balanceModal) return;
    try {
      await API.post(`/admin/users/${balanceModal._id}/balance`, { amount: parseFloat(balanceAmt), reason: balanceReason });
      toast.success('Balance updated');
      setBalanceModal(null); setBalanceAmt(''); setBalanceReason('');
      fetchUsers();
    } catch (err) { toast.error(err.response?.data?.error || 'Failed'); }
  };

  const banUser = async (id, ban) => {
    try {
      await API.post(`/admin/users/${id}/ban`, { ban });
      toast.success(ban ? 'User banned' : 'User unbanned');
      fetchUsers();
    } catch (err) { toast.error('Failed'); }
  };

  const TABS = ['stats', 'deposits', 'withdrawals', 'users'];

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">Loading...</div>;

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">⚙️</span>
        <h1 className="text-2xl font-black text-white">Admin Dashboard</h1>
      </div>

      {/* Tab nav */}
      <div className="flex gap-2 flex-wrap">
        {TABS.map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`px-4 py-2 rounded-xl text-sm font-semibold capitalize transition-all ${
              tab === t ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:text-white'
            }`}
          >
            {t === 'deposits' && deposits.length > 0 ? `${t} (${deposits.length})` : t}
          </button>
        ))}
      </div>

      {/* STATS */}
      {tab === 'stats' && stats && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <StatCard icon="👥" label="Total Users" value={stats.users.total} sub={`+${stats.users.today} today`} color="text-blue-400" />
          <StatCard icon="⬇️" label="Total Deposits" value={`₹${parseFloat(stats.deposits.volume).toFixed(0)}`} sub={`${stats.deposits.total} transactions`} color="text-emerald-400" />
          <StatCard icon="⬆️" label="Total Withdrawals" value={`₹${parseFloat(stats.withdrawals.volume).toFixed(0)}`} sub={`${stats.withdrawals.total} transactions`} color="text-red-400" />
          <StatCard icon="💹" label="House Profit" value={`₹${stats.profit}`} sub={`${stats.houseEdge}% edge today`} color="text-amber-400" />
          <StatCard icon="🎲" label="Bets Today" value={stats.games.total} color="text-purple-400" />
          <StatCard icon="💰" label="Wagered Today" value={`₹${parseFloat(stats.games.wagered).toFixed(0)}`} color="text-indigo-400" />
          <StatCard icon="💸" label="Paid Out Today" value={`₹${parseFloat(stats.games.paid).toFixed(0)}`} color="text-pink-400" />
          <StatCard icon="🟢" label="Active Players" value={stats.activePlayers} sub="last 5 min" color="text-emerald-400" />
        </div>
      )}

      {/* DEPOSITS */}
      {tab === 'deposits' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            {['submitted', 'approved', 'rejected', 'pending'].map(s => (
              <button key={s} onClick={() => setDepFilter(s)}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold capitalize transition-all ${depFilter === s ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:text-white'}`}>{s}</button>
            ))}
          </div>
          <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-white/5 text-slate-400 text-xs uppercase">
                  <th className="px-4 py-3 text-left">User</th>
                  <th className="px-4 py-3 text-left">Amount</th>
                  <th className="px-4 py-3 text-left">TxnID</th>
                  <th className="px-4 py-3 text-left">Proof</th>
                  <th className="px-4 py-3 text-left">Time</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  {depFilter === 'submitted' && <th className="px-4 py-3 text-left">Actions</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {deposits.length === 0 && (
                  <tr><td colSpan={7} className="text-center py-8 text-slate-500">No {depFilter} deposits</td></tr>
                )}
                {deposits.map(d => (
                  <tr key={d._id || d.id} className="hover:bg-white/2">
                    <td className="px-4 py-3 text-white font-medium">{d.userId?.username || d.username || '—'}</td>
                    <td className="px-4 py-3 text-emerald-400 font-mono font-bold">₹{d.amount}</td>
                    <td className="px-4 py-3 text-slate-300 font-mono text-xs">{d.transactionId || d.transaction_id || '—'}</td>
                    <td className="px-4 py-3">
                      {d.screenshotUrl ? (
                        <button onClick={() => setScreenshotModal(d.screenshotUrl)} className="group relative">
                          <img src={d.screenshotUrl} alt="proof" className="w-10 h-10 object-cover rounded-lg border border-white/10 group-hover:border-indigo-500 transition-colors" />
                          <span className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-500 rounded-full border border-[#0f0f1a]" title="Screenshot attached" />
                        </button>
                      ) : (
                        <span className="text-xs text-slate-600">No proof</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-400 text-xs">{new Date(d.createdAt).toLocaleString()}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                        d.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400' :
                        d.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                        d.status === 'submitted' ? 'bg-amber-500/20 text-amber-400' :
                        'bg-slate-500/20 text-slate-400'
                      }`}>{d.status}</span>
                    </td>
                    {depFilter === 'submitted' && (
                      <td className="px-4 py-3 flex gap-2">
                        <button onClick={() => approveDeposit(d._id || d.id)} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold transition-colors">Approve</button>
                        <button onClick={() => setRejectModal({ id: d._id || d.id, type: 'deposit' })} className="bg-red-600 hover:bg-red-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold transition-colors">Reject</button>
                      </td>
                    )}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* WITHDRAWALS */}
      {tab === 'withdrawals' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-white/5 text-slate-400 text-xs uppercase">
                <th className="px-4 py-3 text-left">User</th>
                <th className="px-4 py-3 text-left">Amount</th>
                <th className="px-4 py-3 text-left">UPI ID</th>
                <th className="px-4 py-3 text-left">Time</th>
                <th className="px-4 py-3 text-left">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {withdrawals.length === 0 && (
                <tr><td colSpan={5} className="text-center py-8 text-slate-500">No pending withdrawals</td></tr>
              )}
              {withdrawals.map(w => (
                <tr key={w.id} className="hover:bg-white/2">
                  <td className="px-4 py-3 text-white font-medium">{w.username}</td>
                  <td className="px-4 py-3 text-red-400 font-mono font-bold">₹{w.amount}</td>
                  <td className="px-4 py-3 text-slate-300 font-mono text-xs">{w.upi_id}</td>
                  <td className="px-4 py-3 text-slate-400 text-xs">{new Date(w.createdAt).toLocaleString()}</td>
                  <td className="px-4 py-3 flex gap-2">
                    <button onClick={() => approveWithdraw(w.id)} className="bg-emerald-600 hover:bg-emerald-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold transition-colors">Approve</button>
                    <button onClick={() => setRejectModal({ id: w.id, type: 'withdrawal' })} className="bg-red-600 hover:bg-red-500 text-white text-xs px-3 py-1.5 rounded-lg font-semibold transition-colors">Reject</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* USERS */}
      {tab === 'users' && (
        <div className="space-y-3">
          <div className="flex gap-3">
            <input
              value={userSearch}
              onChange={e => setUserSearch(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && fetchUsers()}
              placeholder="Search by username or email..."
              className="flex-1 bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-2.5 text-sm text-white placeholder-slate-500 outline-none transition-colors"
            />
            <button onClick={fetchUsers} className="bg-indigo-600 hover:bg-indigo-500 text-white px-4 py-2.5 rounded-xl text-sm font-semibold transition-colors">Search</button>
          </div>
          <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden overflow-x-auto">
            <table className="w-full text-sm min-w-[700px]">
              <thead>
                <tr className="border-b border-white/5 text-slate-400 text-xs uppercase">
                  <th className="px-4 py-3 text-left">User</th>
                  <th className="px-4 py-3 text-left">Balance</th>
                  <th className="px-4 py-3 text-left">Wagered</th>
                  <th className="px-4 py-3 text-left">Deposited</th>
                  <th className="px-4 py-3 text-left">Status</th>
                  <th className="px-4 py-3 text-left">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-white/2">
                    <td className="px-4 py-3">
                      <p className="text-white font-medium">{u.username}</p>
                      <p className="text-xs text-slate-500">{u.email}</p>
                    </td>
                    <td className="px-4 py-3 text-emerald-400 font-mono">₹{parseFloat(u.balance).toFixed(2)}</td>
                    <td className="px-4 py-3 text-slate-300 font-mono">₹{parseFloat(u.totalWagered).toFixed(0)}</td>
                    <td className="px-4 py-3 text-blue-400 font-mono">₹{parseFloat(u.totalDeposited || 0).toFixed(0)}</td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full ${u.isBanned ? 'bg-red-500/20 text-red-400' : u.role === 'admin' ? 'bg-amber-500/20 text-amber-400' : 'bg-emerald-500/20 text-emerald-400'}`}>
                        {u.isBanned ? 'Banned' : u.role}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1.5">
                        <button onClick={() => setBalanceModal(u)} className="bg-indigo-600/50 hover:bg-indigo-600 text-white text-xs px-2 py-1 rounded-lg transition-colors">Balance</button>
                        <button onClick={() => banUser(u._id, !u.isBanned)} className={`text-xs px-2 py-1 rounded-lg transition-colors ${u.isBanned ? 'bg-emerald-600/50 hover:bg-emerald-600 text-white' : 'bg-red-600/50 hover:bg-red-600 text-white'}`}>
                          {u.isBanned ? 'Unban' : 'Ban'}
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Balance adjustment modal */}
      {balanceModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0f0f1a] border border-white/10 rounded-2xl p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-white">Adjust Balance — {balanceModal.username}</h3>
            <p className="text-sm text-slate-400">Current: ₹{parseFloat(balanceModal.balance).toFixed(2)}</p>
            <input
              type="number"
              value={balanceAmt}
              onChange={e => setBalanceAmt(e.target.value)}
              placeholder="Amount (use negative to deduct)"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-indigo-500"
            />
            <input
              value={balanceReason}
              onChange={e => setBalanceReason(e.target.value)}
              placeholder="Reason"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-indigo-500"
            />
            <div className="flex gap-3">
              <button onClick={adjustBalance} className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl font-semibold">Apply</button>
              <button onClick={() => setBalanceModal(null)} className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-2.5 rounded-xl font-semibold">Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Screenshot lightbox */}
      {screenshotModal && (
        <div className="fixed inset-0 bg-black/90 flex items-center justify-center z-50 p-4" onClick={() => setScreenshotModal(null)}>
          <div className="relative max-w-lg w-full" onClick={e => e.stopPropagation()}>
            <button onClick={() => setScreenshotModal(null)} className="absolute -top-10 right-0 text-slate-400 hover:text-white text-sm font-semibold">✕ Close</button>
            <img src={screenshotModal} alt="Payment proof" className="w-full rounded-2xl border border-white/10 shadow-2xl" />
          </div>
        </div>
      )}

      {/* Reject modal */}
      {rejectModal && (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
          <div className="bg-[#0f0f1a] border border-white/10 rounded-2xl p-6 w-full max-w-md space-y-4">
            <h3 className="text-lg font-bold text-white">Reject {rejectModal.type}</h3>
            <input
              value={rejectReason}
              onChange={e => setRejectReason(e.target.value)}
              placeholder="Reason for rejection"
              className="w-full bg-white/5 border border-white/10 rounded-xl px-4 py-3 text-sm text-white outline-none focus:border-indigo-500"
            />
            <div className="flex gap-3">
              <button
                onClick={() => rejectModal.type === 'deposit' ? rejectDeposit(rejectModal.id) : rejectWithdraw(rejectModal.id)}
                className="flex-1 bg-red-600 hover:bg-red-500 text-white py-2.5 rounded-xl font-semibold"
              >Reject</button>
              <button onClick={() => { setRejectModal(null); setRejectReason(''); }} className="flex-1 bg-white/5 hover:bg-white/10 text-slate-300 py-2.5 rounded-xl font-semibold">Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
