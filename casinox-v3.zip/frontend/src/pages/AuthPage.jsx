import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useStore } from '../store';
import toast from 'react-hot-toast';

export default function AuthPage() {
  const navigate = useNavigate();
  const { login, register, user, loading } = useStore();
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '', referralCode: '' });

  useEffect(() => { if (user) navigate('/'); }, [user]);

  const set = (k) => (e) => setForm(f => ({ ...f, [k]: e.target.value }));

  const submit = async (e) => {
    e.preventDefault();
    let res;
    if (mode === 'login') {
      res = await login(form.username, form.password);
    } else {
      if (!form.username || !form.email || !form.password)
        return toast.error('All fields required');
      res = await register(form.username, form.email, form.password, form.referralCode);
    }
    if (res.success) {
      toast.success(mode === 'login' ? 'Welcome back! 🎰' : 'Account created! You get ₹100 free! 🎉');
      navigate('/');
    } else {
      toast.error(res.error);
    }
  };

  const inputClass = `w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors`;

  return (
    <div className="min-h-screen bg-[#090912] flex items-center justify-center p-4">
      {/* Background glow */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/10 rounded-full blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 w-72 h-72 bg-purple-600/10 rounded-full blur-3xl" />
      </div>

      <div className="w-full max-w-md relative">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl text-4xl mb-4 shadow-2xl shadow-indigo-500/30">
            🎰
          </div>
          <h1 className="text-3xl font-black text-white">CasinoX</h1>
          <p className="text-slate-400 text-sm mt-1">Premium Gaming Platform</p>
        </div>

        {/* Card */}
        <div className="bg-white/3 border border-white/10 rounded-3xl p-8 shadow-2xl backdrop-blur-sm">
          {/* Tab toggle */}
          <div className="flex bg-white/5 rounded-xl p-1 mb-6">
            <button
              onClick={() => setMode('login')}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${mode === 'login' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Sign In
            </button>
            <button
              onClick={() => setMode('register')}
              className={`flex-1 py-2 rounded-lg text-sm font-semibold transition-all ${mode === 'register' ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'}`}
            >
              Register
            </button>
          </div>

          <form onSubmit={submit} className="space-y-4">
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">
                Username {mode === 'login' && 'or Email'}
              </label>
              <input
                className={inputClass}
                type="text"
                placeholder={mode === 'login' ? 'Enter username or email' : 'Choose a username (3-20 chars)'}
                value={form.username}
                onChange={set('username')}
                autoComplete="username"
                required
              />
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Email</label>
                <input
                  className={inputClass}
                  type="email"
                  placeholder="your@email.com"
                  value={form.email}
                  onChange={set('email')}
                  required
                />
              </div>
            )}

            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">Password</label>
              <input
                className={inputClass}
                type="password"
                placeholder={mode === 'register' ? 'At least 6 characters' : 'Your password'}
                value={form.password}
                onChange={set('password')}
                autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                required
              />
            </div>

            {mode === 'register' && (
              <div>
                <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1.5 block">
                  Referral Code <span className="text-slate-600 normal-case">(optional)</span>
                </label>
                <input
                  className={inputClass}
                  type="text"
                  placeholder="e.g. ABCD1234"
                  value={form.referralCode}
                  onChange={set('referralCode')}
                />
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 disabled:from-slate-700 disabled:to-slate-700 text-white font-bold py-3.5 rounded-xl transition-all shadow-lg hover:shadow-indigo-500/25 mt-2"
            >
              {loading ? '...' : mode === 'login' ? 'Sign In →' : 'Create Account →'}
            </button>
          </form>

          {mode === 'register' && (
            <div className="mt-5 p-4 bg-indigo-600/10 border border-indigo-500/20 rounded-xl">
              <p className="text-xs text-indigo-300 text-center">
                🎁 <strong>New accounts get ₹100 free</strong> to start playing!
              </p>
            </div>
          )}

          <p className="text-xs text-slate-600 text-center mt-5">
            By continuing you agree to our Terms of Service.
            Play responsibly. 18+
          </p>
        </div>
      </div>
    </div>
  );
}
