import React, { useState, useRef } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const SEGMENTS = [
  { label: '2x', multiplier: 2, color: '#22c55e' },
  { label: '0x', multiplier: 0, color: '#ef4444' },
  { label: '3x', multiplier: 3, color: '#3b82f6' },
  { label: '0x', multiplier: 0, color: '#ef4444' },
  { label: '1.5x', multiplier: 1.5, color: '#06b6d4' },
  { label: '0x', multiplier: 0, color: '#ef4444' },
  { label: '10x', multiplier: 10, color: '#f59e0b' },
  { label: '0x', multiplier: 0, color: '#ef4444' },
  { label: '5x', multiplier: 5, color: '#a855f7' },
  { label: '0x', multiplier: 0, color: '#ef4444' },
];

export default function WheelPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [spinning, setSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [result, setResult] = useState(null);
  const wheelRef = useRef(null);

  const spin = async () => {
    if (spinning) return;
    setSpinning(true);
    setResult(null);
    try {
      const { data } = await API.post('/games/wheel', { betAmount: parseFloat(bet) });

      // Animate wheel to the result segment
      const segAngle = 360 / SEGMENTS.length;
      const targetSegIndex = data.segmentIndex % SEGMENTS.length;
      const targetAngle = 360 - (targetSegIndex * segAngle + segAngle / 2);
      const totalRotation = rotation + 1440 + targetAngle - (rotation % 360);

      setRotation(totalRotation);

      setTimeout(() => {
        setResult(data);
        updateBalance(data.balance);
        setSpinning(false);
        if (data.won) toast.success(`🎉 ${data.segment.label}! Won ₹${data.payout?.toFixed(2)}`);
        else toast.error('😔 Better luck next spin!');
      }, 3500);
    } catch (err) {
      setSpinning(false);
      toast.error(err.response?.data?.error || 'Error');
    }
  };

  const segAngle = 360 / SEGMENTS.length;

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎡</span>
        <div>
          <h1 className="text-2xl font-black text-white">Wheel of Fortune</h1>
          <p className="text-sm text-slate-400">Spin to multiply your bet</p>
        </div>
      </div>

      {/* Wheel */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-8 flex flex-col items-center gap-6">
        <div className="relative w-64 h-64">
          {/* Pointer */}
          <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1 z-10 text-2xl">🔻</div>

          {/* SVG Wheel */}
          <svg
            ref={wheelRef}
            viewBox="-100 -100 200 200"
            className="w-full h-full transition-transform"
            style={{ transform: `rotate(${rotation}deg)`, transitionDuration: spinning ? '3.5s' : '0s', transitionTimingFunction: 'cubic-bezier(0.17, 0.67, 0.12, 1)' }}
          >
            {SEGMENTS.map((seg, i) => {
              const startAngle = (i * segAngle - 90) * (Math.PI / 180);
              const endAngle = ((i + 1) * segAngle - 90) * (Math.PI / 180);
              const r = 95;
              const x1 = Math.cos(startAngle) * r;
              const y1 = Math.sin(startAngle) * r;
              const x2 = Math.cos(endAngle) * r;
              const y2 = Math.sin(endAngle) * r;
              const midAngle = ((i + 0.5) * segAngle - 90) * (Math.PI / 180);
              const tx = Math.cos(midAngle) * 65;
              const ty = Math.sin(midAngle) * 65;
              return (
                <g key={i}>
                  <path
                    d={`M 0 0 L ${x1} ${y1} A ${r} ${r} 0 0 1 ${x2} ${y2} Z`}
                    fill={seg.color}
                    opacity="0.85"
                    stroke="#0f0f1a"
                    strokeWidth="1"
                  />
                  <text x={tx} y={ty} textAnchor="middle" dominantBaseline="middle" fill="white" fontSize="10" fontWeight="bold" transform={`rotate(${(i + 0.5) * segAngle}, ${tx}, ${ty})`}>
                    {seg.label}
                  </text>
                </g>
              );
            })}
            <circle r="12" fill="#0f0f1a" stroke="white" strokeWidth="2" />
          </svg>
        </div>

        {result && (
          <div className={`text-center ${result.won ? 'text-emerald-400' : 'text-slate-400'}`}>
            <p className="text-xl font-black">{result.won ? `🎉 ${result.segment.label} — ₹${result.payout?.toFixed(2)}` : '😔 No win this time'}</p>
          </div>
        )}
      </div>

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={spinning} />
        <button
          onClick={spin}
          disabled={spinning || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all"
        >
          {spinning ? '🎡 Spinning...' : 'Spin Wheel 🎡'}
        </button>
      </div>

      {/* Paytable */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
        <h3 className="text-sm font-semibold text-slate-400 mb-3">Paytable</h3>
        <div className="grid grid-cols-3 gap-2">
          {[...new Map(SEGMENTS.map(s => [s.label, s])).values()].map(seg => (
            <div key={seg.label} className="flex items-center gap-2 px-3 py-2 rounded-lg" style={{ backgroundColor: seg.color + '20', border: `1px solid ${seg.color}40` }}>
              <span className="w-2 h-2 rounded-full flex-shrink-0" style={{ backgroundColor: seg.color }} />
              <span className="text-sm font-bold text-white">{seg.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
