import React, { useState, useEffect } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import toast from 'react-hot-toast';

const AMOUNTS = [10, 20, 50, 100, 500, 1000, 2000];

function QRCode({ upiLink, size = 200 }) {
  return (
    <div className="flex flex-col items-center gap-3">
      <a href={upiLink} className="p-3 bg-white rounded-2xl block hover:opacity-90 transition-opacity" title="Tap to open in UPI app">
        <img src="/upi-qr.png" alt="UPI QR Code" width={size} height={size} className="rounded-lg object-contain" />
      </a>
      <p className="text-xs text-slate-500">Tap QR to open in UPI app (mobile)</p>
    </div>
  );
}

export default function WalletPage() {
  const { user, updateBalance } = useStore();
  const [tab, setTab] = useState('deposit');
  const [walletData, setWalletData] = useState(null);
  const [loading, setLoading] = useState(true);

  // Deposit state
  const [selectedAmount, setSelectedAmount] = useState(null);
  const [depositInfo, setDepositInfo] = useState(null);
  const [txnId, setTxnId] = useState('');
  const [upiIdUsed, setUpiIdUsed] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [depositStep, setDepositStep] = useState(1); // 1: select amount, 2: scan & pay, 3: submitted

  // Screenshot
  const [screenshot, setScreenshot] = useState(null);
  const [screenshotPreview, setScreenshotPreview] = useState(null);

  // Withdraw state
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawUpi, setWithdrawUpi] = useState('');
  const [withdrawLoading, setWithdrawLoading] = useState(false);

  useEffect(() => {
    fetchWallet();
  }, []);

  const fetchWallet = async () => {
    try {
      const { data } = await API.get('/wallet/overview');
      setWalletData(data);
      updateBalance(data.balance);
    } catch (err) {
      toast.error('Failed to load wallet');
    } finally { setLoading(false); }
  };

  const initiateDeposit = async () => {
    if (!selectedAmount) return toast.error('Select an amount');
    try {
      const { data } = await API.post('/wallet/deposit/initiate', { amount: selectedAmount });
      setDepositInfo(data);
      setDepositStep(2);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to initiate deposit');
    }
  };

  const handleScreenshot = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    if (file.size > 2 * 1024 * 1024) return toast.error('Screenshot must be under 2MB');
    const reader = new FileReader();
    reader.onload = (ev) => {
      setScreenshot(ev.target.result);
      setScreenshotPreview(ev.target.result);
    };
    reader.readAsDataURL(file);
  };

  const submitDeposit = async () => {
    if (!txnId.trim()) return toast.error('Enter your UPI Transaction ID');
    setSubmitting(true);
    try {
      await API.post('/wallet/deposit/submit', {
        depositId: depositInfo.deposit._id,
        transactionId: txnId.trim(),
        upiId: upiIdUsed.trim(),
        screenshotUrl: screenshot || '',
      });
      setDepositStep(3);
      toast.success('Deposit submitted! Admin will verify and credit your balance.');
      fetchWallet();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Submission failed');
    } finally { setSubmitting(false); }
  };

  const requestWithdraw = async () => {
    if (!withdrawAmount || !withdrawUpi) return toast.error('Fill all fields');
    setWithdrawLoading(true);
    try {
      const { data } = await API.post('/wallet/withdraw/request', {
        amount: parseFloat(withdrawAmount),
        upiId: withdrawUpi,
      });
      toast.success(data.message);
      setWithdrawAmount('');
      setWithdrawUpi('');
      fetchWallet();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Withdrawal failed');
    } finally { setWithdrawLoading(false); }
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text).then(() => toast.success('Copied!'));
  };

  if (loading) return <div className="flex items-center justify-center h-64 text-slate-400">Loading wallet...</div>;

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">💰</span>
        <div>
          <h1 className="text-2xl font-black text-white">Wallet</h1>
          <p className="text-sm text-slate-400">Manage your balance</p>
        </div>
      </div>

      {/* Balance cards */}
      <div className="grid grid-cols-2 gap-3">
        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-2xl p-4">
          <p className="text-xs text-emerald-400 mb-1">💰 Main Balance</p>
          <p className="text-2xl font-black text-white font-mono">₹{parseFloat(walletData?.balance || 0).toFixed(2)}</p>
        </div>
        <div className="bg-purple-500/10 border border-purple-500/20 rounded-2xl p-4">
          <p className="text-xs text-purple-400 mb-1">🎁 Bonus Balance</p>
          <p className="text-2xl font-black text-white font-mono">₹{parseFloat(walletData?.bonus_balance || 0).toFixed(2)}</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-2 bg-white/3 border border-white/5 rounded-xl p-1">
        {['deposit', 'withdraw', 'history'].map(t => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={`flex-1 py-2 rounded-lg text-sm font-semibold capitalize transition-all ${
              tab === t ? 'bg-indigo-600 text-white' : 'text-slate-400 hover:text-white'
            }`}
          >
            {t === 'deposit' ? '⬇️ Deposit' : t === 'withdraw' ? '⬆️ Withdraw' : '📋 History'}
          </button>
        ))}
      </div>

      {/* DEPOSIT TAB */}
      {tab === 'deposit' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-5">
          {depositStep === 1 && (
            <>
              <h3 className="font-bold text-white">Select Deposit Amount</h3>
              <div className="grid grid-cols-4 gap-2">
                {AMOUNTS.map(amt => (
                  <button
                    key={amt}
                    onClick={() => setSelectedAmount(amt)}
                    className={`py-3 rounded-xl font-bold text-sm transition-all ${
                      selectedAmount === amt
                        ? 'bg-indigo-600 text-white border border-indigo-500'
                        : 'bg-white/5 text-slate-300 border border-white/10 hover:bg-white/10'
                    }`}
                  >
                    ₹{amt}
                  </button>
                ))}
              </div>
              <button
                onClick={initiateDeposit}
                disabled={!selectedAmount}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
              >
                Generate QR Code →
              </button>
              <p className="text-xs text-slate-500 text-center">Secure UPI payment. Instant credit after verification.</p>
            </>
          )}

          {depositStep === 2 && depositInfo && (
            <>
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white">Scan & Pay ₹{depositInfo.amount}</h3>
                <button onClick={() => { setDepositStep(1); setDepositInfo(null); }} className="text-slate-400 hover:text-white text-sm">← Back</button>
              </div>

              <div className="flex flex-col items-center gap-4 py-2">
                <QRCode upiLink={depositInfo.upiLink} />
                <div className="text-center">
                  <p className="text-sm text-slate-400 mb-1">Pay to UPI ID:</p>
                  <div className="flex items-center gap-2">
                    <code className="bg-white/10 px-3 py-1.5 rounded-lg text-indigo-300 font-mono text-sm">{depositInfo.upiId}</code>
                    <button onClick={() => copyToClipboard(depositInfo.upiId)} className="text-slate-400 hover:text-white text-lg">📋</button>
                  </div>
                </div>
                <div className="w-full bg-amber-500/10 border border-amber-500/20 rounded-xl p-3 text-xs text-amber-400 text-center">
                  ⚠️ Pay exactly ₹{depositInfo.amount}. Amount mismatches may delay processing.
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-sm font-semibold text-white">After paying, enter your Transaction ID:</p>
                <input
                  value={txnId}
                  onChange={e => setTxnId(e.target.value)}
                  placeholder="UPI Transaction ID (e.g. T2312345678)"
                  className="w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors"
                />
                <input
                  value={upiIdUsed}
                  onChange={e => setUpiIdUsed(e.target.value)}
                  placeholder="Your UPI ID (optional)"
                  className="w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors"
                />

                {/* Screenshot upload */}
                <div>
                  <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">
                    Payment Screenshot <span className="text-indigo-400">(speeds up approval)</span>
                  </label>
                  <label className="flex flex-col items-center justify-center w-full border-2 border-dashed border-white/10 hover:border-indigo-500/50 rounded-xl cursor-pointer transition-colors overflow-hidden">
                    {screenshotPreview ? (
                      <div className="relative w-full">
                        <img src={screenshotPreview} alt="Payment screenshot" className="w-full max-h-48 object-contain bg-black/30" />
                        <span className="absolute top-2 right-2 bg-black/60 text-white text-xs px-2 py-0.5 rounded-full">tap to change</span>
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-2xl mb-1">📸</p>
                        <p className="text-sm text-slate-400">Attach payment screenshot</p>
                        <p className="text-xs text-slate-600 mt-0.5">JPG, PNG up to 2MB</p>
                      </div>
                    )}
                    <input type="file" accept="image/*" className="hidden" onChange={handleScreenshot} />
                  </label>
                </div>

                <button
                  onClick={submitDeposit}
                  disabled={!txnId.trim() || submitting}
                  className="w-full bg-emerald-600 hover:bg-emerald-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
                >
                  {submitting ? 'Submitting...' : 'I Have Paid — Submit ✓'}
                </button>
              </div>
            </>
          )}

          {depositStep === 3 && (
            <div className="text-center py-6 space-y-4">
              <div className="w-16 h-16 bg-emerald-500/20 rounded-full flex items-center justify-center text-4xl mx-auto">✅</div>
              <h3 className="text-xl font-bold text-white">Deposit Submitted!</h3>
              <p className="text-slate-400 text-sm">Your payment is under review. Balance will be credited within 30 minutes.</p>
              <button
                onClick={() => { setDepositStep(1); setSelectedAmount(null); setDepositInfo(null); setTxnId(''); setUpiIdUsed(''); setScreenshot(null); setScreenshotPreview(null); fetchWallet(); }}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-2 rounded-xl font-semibold transition-colors"
              >
                Make Another Deposit
              </button>
            </div>
          )}

          {/* Pending deposits */}
          {walletData?.deposits?.filter(d => d.status !== 'approved').length > 0 && (
            <div className="border-t border-white/5 pt-4">
              <p className="text-xs font-semibold text-slate-400 mb-2 uppercase">Pending Deposits</p>
              {walletData.deposits.filter(d => d.status !== 'approved').slice(0, 3).map(d => (
                <div key={d.id} className="flex items-center justify-between py-2">
                  <span className="text-sm text-white">₹{d.amount}</span>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    d.status === 'submitted' ? 'bg-amber-500/20 text-amber-400' :
                    d.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                    'bg-slate-500/20 text-slate-400'
                  }`}>{d.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* WITHDRAW TAB */}
      {tab === 'withdraw' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
          <h3 className="font-bold text-white">Withdraw Funds</h3>
          <div className="bg-slate-800/50 border border-slate-700 rounded-xl p-3 text-xs text-slate-400 space-y-1">
            <p>• Minimum withdrawal: ₹100</p>
            <p>• Maximum withdrawal: ₹10,000 per request</p>
            <p>• Processing time: up to 24 hours</p>
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">Amount</label>
              <input
                type="number"
                value={withdrawAmount}
                onChange={e => setWithdrawAmount(e.target.value)}
                placeholder="Enter amount (min ₹100)"
                min="100"
                max="10000"
                className="w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>
            <div>
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1 block">Your UPI ID</label>
              <input
                value={withdrawUpi}
                onChange={e => setWithdrawUpi(e.target.value)}
                placeholder="yourname@upi"
                className="w-full bg-white/5 border border-white/10 focus:border-indigo-500 rounded-xl px-4 py-3 text-sm text-white placeholder-slate-500 outline-none transition-colors"
              />
            </div>
            <button
              onClick={requestWithdraw}
              disabled={withdrawLoading || !withdrawAmount || !withdrawUpi}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
            >
              {withdrawLoading ? 'Requesting...' : 'Request Withdrawal ⬆️'}
            </button>
          </div>

          {walletData?.withdrawals?.length > 0 && (
            <div className="border-t border-white/5 pt-4 space-y-2">
              <p className="text-xs font-semibold text-slate-400 uppercase">Recent Withdrawals</p>
              {walletData.withdrawals.slice(0, 5).map(w => (
                <div key={w.id} className="flex items-center justify-between py-1">
                  <div>
                    <p className="text-sm text-white font-mono">₹{w.amount}</p>
                    <p className="text-xs text-slate-500">{w.upi_id}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full ${
                    w.status === 'approved' ? 'bg-emerald-500/20 text-emerald-400' :
                    w.status === 'rejected' ? 'bg-red-500/20 text-red-400' :
                    'bg-amber-500/20 text-amber-400'
                  }`}>{w.status}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* HISTORY TAB */}
      {tab === 'history' && (
        <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
          <div className="divide-y divide-white/5">
            {(walletData?.transactions || []).length === 0 ? (
              <p className="text-slate-500 text-center py-8 text-sm">No transactions yet</p>
            ) : walletData.transactions.map(tx => (
              <div key={tx.id} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="text-sm text-white capitalize">{tx.type.replace(/_/g, ' ')}</p>
                  <p className="text-xs text-slate-500">{tx.description} • {new Date(tx.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="text-right">
                  <p className={`text-sm font-mono font-bold ${parseFloat(tx.amount) >= 0 ? 'text-emerald-400' : 'text-red-400'}`}>
                    {parseFloat(tx.amount) >= 0 ? '+' : ''}₹{Math.abs(parseFloat(tx.amount)).toFixed(2)}
                  </p>
                  <p className="text-xs text-slate-500">Bal: ₹{parseFloat(tx.balanceAfter).toFixed(2)}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
