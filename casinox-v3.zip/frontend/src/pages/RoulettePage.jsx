import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const RED_NUMBERS = new Set([1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36]);

const BET_OPTIONS = [
  { key: 'red',    label: '🔴 Red',      color: 'bg-red-600 hover:bg-red-500',    payout: '2x' },
  { key: 'black',  label: '⚫ Black',    color: 'bg-slate-700 hover:bg-slate-600', payout: '2x' },
  { key: 'odd',    label: '🎲 Odd',      color: 'bg-slate-600 hover:bg-slate-500', payout: '2x' },
  { key: 'even',   label: '🎲 Even',     color: 'bg-slate-600 hover:bg-slate-500', payout: '2x' },
  { key: 'half1',  label: '1–18',        color: 'bg-slate-600 hover:bg-slate-500', payout: '2x' },
  { key: 'half2',  label: '19–36',       color: 'bg-slate-600 hover:bg-slate-500', payout: '2x' },
  { key: 'dozen1', label: '1st 12',      color: 'bg-indigo-700 hover:bg-indigo-600', payout: '3x' },
  { key: 'dozen2', label: '2nd 12',      color: 'bg-indigo-700 hover:bg-indigo-600', payout: '3x' },
  { key: 'dozen3', label: '3rd 12',      color: 'bg-indigo-700 hover:bg-indigo-600', payout: '3x' },
];

export default function RoulettePage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [betType, setBetType] = useState('red');
  const [betValue, setBetValue] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [spinning, setSpinning] = useState(false);

  const play = async () => {
    if (loading) return;
    setLoading(true);
    setSpinning(true);
    setResult(null);
    try {
      await new Promise(r => setTimeout(r, 1500));
      const { data } = await API.post('/games/roulette', { betAmount: parseFloat(bet), betType, betValue });
      setResult(data);
      setSpinning(false);
      updateBalance(data.balance);
      if (data.won) toast.success(`🎡 ${data.roll} — Won ₹${data.payout?.toFixed(2)} (${data.multiplier}x)!`);
      else toast.error(`🎡 ${data.roll} — Better luck next spin!`);
    } catch (err) {
      setSpinning(false);
      toast.error(err.response?.data?.error || 'Error');
    } finally { setLoading(false); }
  };

  const numColor = (n) => {
    if (n === 0) return 'bg-emerald-600';
    return RED_NUMBERS.has(n) ? 'bg-red-600' : 'bg-slate-800';
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎡</span>
        <div>
          <h1 className="text-2xl font-black text-white">Roulette</h1>
          <p className="text-sm text-slate-400">European Roulette — single zero</p>
        </div>
      </div>

      {/* Wheel display */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-6 flex flex-col items-center gap-4">
        <div className={`w-32 h-32 rounded-full border-4 border-white/20 flex items-center justify-center transition-all duration-500 ${spinning ? 'animate-spin' : ''}`}
          style={{ background: 'conic-gradient(#ef4444 0deg 10deg, #1e293b 10deg 20deg, #ef4444 20deg 30deg, #1e293b 30deg 40deg, #ef4444 40deg 50deg, #1e293b 50deg 60deg, #ef4444 60deg 70deg, #1e293b 70deg 80deg, #22c55e 80deg 90deg, #ef4444 90deg 100deg, #1e293b 100deg 360deg)' }}>
          {result && !spinning && (
            <div className={`w-16 h-16 rounded-full ${numColor(result.roll)} flex items-center justify-center`}>
              <span className="text-2xl font-black text-white">{result.roll}</span>
            </div>
          )}
          {!result && <span className="text-4xl">🎡</span>}
        </div>

        {result && !spinning && (
          <div className={`text-center ${result.won ? 'text-emerald-400' : 'text-slate-400'}`}>
            <p className="font-bold">
              {result.isRed ? '🔴 Red' : result.roll === 0 ? '🟢 Green' : '⚫ Black'} — {result.roll}
            </p>
            {result.won && <p className="text-lg font-black">Won ₹{result.payout?.toFixed(2)}</p>}
          </div>
        )}
      </div>

      {/* Number grid */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
        <p className="text-xs text-slate-400 mb-3">Or bet on a specific number (35x payout)</p>
        <div className="grid grid-cols-13 gap-1" style={{ gridTemplateColumns: 'repeat(13, 1fr)' }}>
          {[0, ...Array.from({length: 36}, (_, i) => i + 1)].map(n => (
            <button
              key={n}
              onClick={() => { setBetType('number'); setBetValue(String(n)); }}
              className={`aspect-square rounded text-xs font-bold transition-all ${numColor(n)} ${betType === 'number' && betValue === String(n) ? 'ring-2 ring-white scale-110' : 'opacity-70 hover:opacity-100'} text-white`}
            >
              {n}
            </button>
          ))}
        </div>
      </div>

      {/* Outside bets */}
      <div className="grid grid-cols-3 gap-2">
        {BET_OPTIONS.map(opt => (
          <button
            key={opt.key}
            onClick={() => { setBetType(opt.key); setBetValue(''); }}
            className={`py-3 px-3 rounded-xl text-sm font-bold transition-all ${opt.color} text-white ${betType === opt.key ? 'ring-2 ring-white' : 'opacity-70'}`}
          >
            <div>{opt.label}</div>
            <div className="text-xs opacity-70">{opt.payout}</div>
          </button>
        ))}
      </div>

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <div className="text-sm text-slate-400">
          Betting on: <span className="text-white font-semibold">
            {betType === 'number' ? `Number ${betValue}` : BET_OPTIONS.find(b => b.key === betType)?.label}
          </span>
        </div>
        <BetInput value={bet} onChange={setBet} disabled={loading} />
        <button
          onClick={play}
          disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0) || (betType === 'number' && !betValue)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-colors"
        >
          {loading ? 'Spinning...' : 'Spin 🎡'}
        </button>
      </div>
    </div>
  );
}
