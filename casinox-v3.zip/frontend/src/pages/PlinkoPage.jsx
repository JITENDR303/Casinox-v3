import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const MULTIPLIERS = {
  low:    [1.4, 1.2, 1.1, 1.0, 0.5, 1.0, 1.1, 1.2, 1.4],
  medium: [5.6, 2.1, 1.1, 0.5, 0.3, 0.5, 1.1, 2.1, 5.6],
  high:   [29,  4,   1.5, 0.3, 0.2, 0.3, 1.5, 4,   29 ],
};

const BUCKET_COLORS = {
  low:    ['#22c55e','#4ade80','#86efac','#bbf7d0','#d1fae5','#bbf7d0','#86efac','#4ade80','#22c55e'],
  medium: ['#f59e0b','#f97316','#22c55e','#ef4444','#dc2626','#ef4444','#22c55e','#f97316','#f59e0b'],
  high:   ['#7c3aed','#a855f7','#f97316','#ef4444','#dc2626','#ef4444','#f97316','#a855f7','#7c3aed'],
};

export default function PlinkoPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [risk, setRisk] = useState('medium');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [balls, setBalls] = useState([]);

  const drop = async () => {
    if (loading) return;
    setLoading(true);
    setResult(null);
    try {
      const { data } = await API.post('/games/plinko', { betAmount: parseFloat(bet), risk });
      setResult(data);
      updateBalance(data.balance);

      // Animate ball
      const ballId = Date.now();
      setBalls(b => [...b, { id: ballId, path: data.path, bucket: data.bucketIndex, done: false }]);
      setTimeout(() => {
        setBalls(b => b.filter(ball => ball.id !== ballId));
        if (data.won) toast.success(`🎯 ${data.multiplier}x — Won ₹${data.payout?.toFixed(2)}!`);
        else toast.error(`😔 ${data.multiplier}x — Lost ₹${parseFloat(bet).toFixed(2)}`);
      }, 2000);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error');
    } finally { setLoading(false); }
  };

  const ROWS = 8;
  const mults = MULTIPLIERS[risk];
  const colors = BUCKET_COLORS[risk];

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎯</span>
        <div>
          <h1 className="text-2xl font-black text-white">Plinko</h1>
          <p className="text-sm text-slate-400">Drop the ball, win big</p>
        </div>
      </div>

      <div className="bg-white/3 border border-white/5 rounded-2xl p-5">
        {/* Peg grid visual */}
        <div className="py-6 px-4">
          {Array.from({ length: ROWS }).map((_, row) => (
            <div key={row} className="flex justify-center gap-4 mb-3" style={{ gap: `${(ROWS - row) * 4 + 8}px` }}>
              {Array.from({ length: row + 3 }).map((_, col) => (
                <div key={col} className="w-2.5 h-2.5 rounded-full bg-slate-600 border border-slate-500" />
              ))}
            </div>
          ))}
        </div>

        {/* Buckets */}
        <div className="flex gap-1 mt-2">
          {mults.map((m, i) => (
            <div
              key={i}
              className="flex-1 py-2 rounded-lg text-center transition-all"
              style={{
                backgroundColor: colors[i] + '30',
                border: `1px solid ${colors[i]}60`,
                transform: result?.bucketIndex === i ? 'scale(1.1)' : 'scale(1)',
              }}
            >
              <span className="text-xs font-bold" style={{ color: colors[i] }}>{m}x</span>
            </div>
          ))}
        </div>
      </div>

      {result && (
        <div className={`text-center py-4 rounded-xl ${result.won ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-400' : 'bg-red-500/10 border border-red-500/20 text-red-400'}`}>
          <p className="text-xl font-black">{result.multiplier}x</p>
          <p className="text-sm">{result.won ? `Won ₹${result.payout?.toFixed(2)}` : `Lost ₹${parseFloat(bet).toFixed(2)}`}</p>
        </div>
      )}

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={loading} />

        <div className="space-y-2">
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Risk Level</label>
          <div className="grid grid-cols-3 gap-2">
            {['low', 'medium', 'high'].map(r => (
              <button
                key={r}
                onClick={() => setRisk(r)}
                className={`py-2 rounded-xl font-semibold text-sm capitalize transition-all ${
                  risk === r ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10'
                }`}
              >
                {r}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={drop}
          disabled={loading || !user || parseFloat(bet) > parseFloat(user?.balance || 0)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all"
        >
          {loading ? 'Dropping...' : 'Drop Ball 🎯'}
        </button>
      </div>
    </div>
  );
}
