import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const RISK_CONFIG = {
  easy:   { cols: 4, label: 'Easy',   color: 'text-emerald-400', baseMultiplier: 1.35 },
  medium: { cols: 3, label: 'Medium', color: 'text-amber-400',   baseMultiplier: 1.45 },
  hard:   { cols: 2, label: 'Hard',   color: 'text-orange-400',  baseMultiplier: 1.95 },
  expert: { cols: 2, label: 'Expert', color: 'text-red-400',     baseMultiplier: 2.5  },
};

const TOTAL_ROWS = 9;

export default function TowerPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet]           = useState('10');
  const [risk, setRisk]         = useState('medium');
  const [gameActive, setGameActive] = useState(false);
  const [sessionId, setSessionId]   = useState(null);
  const [currentRow, setCurrentRow] = useState(0);
  const [multiplier, setMultiplier] = useState(1);
  const [currentPayout, setCurrentPayout] = useState(0);
  const [revealedTrap, setRevealedTrap]    = useState(null); // { row, col }
  const [clickedCells, setClickedCells]    = useState({}); // { "row-col": 'safe'|'trap' }
  const [loading, setLoading]   = useState(false);
  const [gameOver, setGameOver] = useState(false);
  const [allTraps, setAllTraps] = useState(null);

  const config = RISK_CONFIG[risk];

  const startGame = async () => {
    if (loading) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/tower/start', { betAmount: parseFloat(bet), risk });
      setSessionId(data.sessionId);
      setGameActive(true);
      setCurrentRow(0);
      setMultiplier(1);
      setCurrentPayout(parseFloat(bet));
      setClickedCells({});
      setRevealedTrap(null);
      setGameOver(false);
      setAllTraps(null);
      updateBalance(data.balance);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to start');
    } finally { setLoading(false); }
  };

  const climb = async (col) => {
    if (!gameActive || loading || gameOver) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/tower/climb', { sessionId, chosenCol: col });

      if (data.isTrapped) {
        setClickedCells(prev => ({ ...prev, [`${currentRow}-${col}`]: 'trap' }));
        setAllTraps(data.rows);
        setGameActive(false);
        setGameOver(true);
        toast.error(`💥 Trapped on row ${currentRow + 1}!`);
      } else {
        setClickedCells(prev => ({ ...prev, [`${currentRow}-${col}`]: 'safe' }));
        setCurrentRow(data.nextRow);
        setMultiplier(data.multiplier);
        setCurrentPayout(data.currentPayout || data.payout);
        if (data.completed) {
          setAllTraps(data.rows);
          setGameActive(false);
          setGameOver(true);
          updateBalance(data.balance);
          toast.success(`🏆 Top reached! Won ₹${data.payout?.toFixed(2)} at ${data.multiplier}x!`);
        }
      }
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error');
    } finally { setLoading(false); }
  };

  const cashout = async () => {
    if (!gameActive || loading || currentRow === 0) return;
    setLoading(true);
    try {
      const { data } = await API.post('/games/tower/cashout', { sessionId });
      setAllTraps(data.rows);
      setGameActive(false);
      setGameOver(true);
      updateBalance(data.balance);
      toast.success(`💰 Cashed out ₹${data.payout?.toFixed(2)} at ${data.multiplier}x!`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Cashout failed');
    } finally { setLoading(false); }
  };

  const getCellStyle = (row, col) => {
    const key    = `${row}-${col}`;
    const state  = clickedCells[key];
    const isCurrentRow = row === currentRow && gameActive;

    if (state === 'safe')  return 'bg-emerald-500/30 border-emerald-400 text-emerald-300';
    if (state === 'trap')  return 'bg-red-500/30 border-red-400 text-red-300 animate-pulse';

    // Reveal all traps on game over
    if (allTraps && allTraps[row] === col && !state)
      return 'bg-red-900/20 border-red-800/30 text-red-600';

    if (isCurrentRow) return 'bg-indigo-500/10 border-indigo-400/50 text-indigo-300 hover:bg-indigo-500/30 cursor-pointer';
    if (row < currentRow) return 'bg-slate-800/30 border-slate-700/30 opacity-40';
    return 'bg-white/3 border-white/10 opacity-50';
  };

  const getRowMultiplier = (row) => {
    return parseFloat(Math.pow(config.baseMultiplier, row + 1).toFixed(2));
  };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🏗️</span>
        <div>
          <h1 className="text-2xl font-black text-white">Tower</h1>
          <p className="text-sm text-slate-400">Climb higher, win bigger — avoid the traps</p>
        </div>
      </div>

      <div className="grid md:grid-cols-[200px_1fr] gap-5">
        {/* Controls */}
        <div className="space-y-4 h-fit">
          <div className="bg-white/3 border border-white/5 rounded-2xl p-4 space-y-4">
            <BetInput value={bet} onChange={setBet} disabled={gameActive} />

            {/* Risk selector */}
            <div className="space-y-2">
              <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Risk</label>
              <div className="grid grid-cols-2 gap-1.5">
                {Object.entries(RISK_CONFIG).map(([key, cfg]) => (
                  <button key={key} onClick={() => !gameActive && setRisk(key)} disabled={gameActive}
                    className={`py-2 rounded-xl text-xs font-bold transition-all ${risk === key ? 'bg-indigo-600 text-white' : 'bg-white/5 text-slate-400 hover:bg-white/10 disabled:opacity-50'}`}>
                    {cfg.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Live stats */}
            {gameActive && (
              <div className="space-y-2 border-t border-white/5 pt-3">
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Row</span>
                  <span className="text-white font-bold">{currentRow}/{TOTAL_ROWS}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Multiplier</span>
                  <span className="text-emerald-400 font-bold">{multiplier}x</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-slate-400">Payout</span>
                  <span className="text-white font-mono font-bold">₹{currentPayout?.toFixed(2)}</span>
                </div>
              </div>
            )}

            {!gameActive ? (
              <button onClick={startGame} disabled={loading || !user || parseFloat(bet) > (user?.balance || 0)}
                className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all">
                {loading ? 'Starting...' : 'Start Climb 🏗️'}
              </button>
            ) : (
              <button onClick={cashout} disabled={loading || currentRow === 0}
                className="w-full bg-amber-500 hover:bg-amber-400 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all animate-pulse">
                Cash Out ₹{currentPayout?.toFixed(2)}
              </button>
            )}
          </div>
        </div>

        {/* Tower grid */}
        <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
          <div className="flex flex-col-reverse gap-2">
            {Array.from({ length: TOTAL_ROWS }, (_, row) => (
              <div key={row} className="flex gap-2 items-center">
                <div className="w-10 text-right text-xs font-mono text-slate-500 flex-shrink-0">
                  {getRowMultiplier(row)}x
                </div>
                <div className={`flex gap-2 flex-1`}>
                  {Array.from({ length: config.cols }, (_, col) => {
                    const key   = `${row}-${col}`;
                    const state = clickedCells[key];
                    return (
                      <button key={col}
                        onClick={() => row === currentRow && gameActive && climb(col)}
                        disabled={!gameActive || row !== currentRow || loading}
                        className={`flex-1 h-10 rounded-xl border-2 text-lg flex items-center justify-center transition-all duration-200 ${getCellStyle(row, col)} ${row === currentRow && gameActive && !loading ? 'active:scale-95' : ''}`}
                      >
                        {state === 'safe' && '💎'}
                        {state === 'trap' && '💥'}
                        {!state && allTraps && allTraps[row] === col && '💣'}
                        {!state && (!allTraps || allTraps[row] !== col) && (row === currentRow && gameActive ? '?' : '')}
                      </button>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>

          {/* Floor indicator */}
          <div className="mt-3 flex items-center gap-2 text-xs text-slate-500">
            <span className="w-10 text-right">1x</span>
            <div className="flex-1 h-1 bg-white/10 rounded-full">
              <div className="h-full bg-indigo-500 rounded-full transition-all duration-500" style={{ width: `${(currentRow / TOTAL_ROWS) * 100}%` }} />
            </div>
            <span>Top</span>
          </div>
        </div>
      </div>
    </div>
  );
}
