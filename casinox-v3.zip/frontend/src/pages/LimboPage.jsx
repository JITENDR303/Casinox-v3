import React, { useState, useRef } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const PRESET_TARGETS = [1.5, 2, 3, 5, 10, 25, 100];

export default function LimboPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet]           = useState('10');
  const [target, setTarget]     = useState('2.00');
  const [result, setResult]     = useState(null);
  const [loading, setLoading]   = useState(false);
  const [rolling, setRolling]   = useState(false);
  const [displayNum, setDisplayNum] = useState(null);
  const [history, setHistory]   = useState([]);
  const [autoBet, setAutoBet]   = useState(false);
  const [autoCount, setAutoCount]   = useState(0);
  const [autoRunning, setAutoRunning] = useState(false);
  const autoRef = useRef(false);

  const t = parseFloat(target);
  const winChance  = t >= 1.01 ? parseFloat((99 / t).toFixed(2)) : 0;
  const potentialPayout = parseFloat((parseFloat(bet || 0) * t).toFixed(2));

  const playOnce = async () => {
    if (!user || parseFloat(bet) > (user?.balance || 0)) return false;
    try {
      const { data } = await API.post('/games/limbo', {
        betAmount: parseFloat(bet),
        targetMultiplier: t,
      });
      return data;
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error');
      return null;
    }
  };

  const runAnimation = async (data) => {
    setRolling(true);
    // Count up animation
    const start  = 1.0;
    const end    = data.result;
    const steps  = 25;
    for (let i = 0; i <= steps; i++) {
      const v = start + ((end - start) * (i / steps));
      setDisplayNum(parseFloat(v.toFixed(2)));
      await new Promise(r => setTimeout(r, 30));
    }
    setDisplayNum(data.result);
    setRolling(false);
    return data;
  };

  const play = async () => {
    if (loading || rolling) return;
    if (isNaN(t) || t < 1.01) return toast.error('Target must be ≥ 1.01');
    setLoading(true);
    setResult(null);

    const data = await playOnce();
    if (!data) { setLoading(false); return; }

    await runAnimation(data);
    setResult(data);
    updateBalance(data.balance);
    setHistory(h => [data, ...h].slice(0, 12));
    if (data.won) toast.success(`🚀 ${data.result}x ≥ ${t}x — Won ₹${data.payout?.toFixed(2)}!`);
    setLoading(false);
  };

  const startAuto = async () => {
    if (isNaN(t) || t < 1.01) return toast.error('Target must be ≥ 1.01');
    autoRef.current = true;
    setAutoRunning(true);
    let count = 0;
    const limit = parseInt(autoCount) || 999999;

    while (autoRef.current && count < limit) {
      if (parseFloat(bet) > (user?.balance || 0)) { toast.error('Insufficient balance'); break; }
      setLoading(true);
      const data = await playOnce();
      if (!data) break;
      await runAnimation(data);
      setResult(data);
      updateBalance(data.balance);
      setHistory(h => [data, ...h].slice(0, 12));
      count++;
      setLoading(false);
      await new Promise(r => setTimeout(r, 300));
    }
    autoRef.current = false;
    setAutoRunning(false);
    setLoading(false);
  };

  const stopAuto = () => { autoRef.current = false; };

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🚀</span>
        <div>
          <h1 className="text-2xl font-black text-white">Limbo</h1>
          <p className="text-sm text-slate-400">Set your target — win if result beats it</p>
        </div>
      </div>

      {/* Main display */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-8 flex flex-col items-center gap-4">
        <div className={`text-7xl font-black font-mono transition-all duration-100 ${
          rolling ? 'text-indigo-400 opacity-80' :
          result?.won ? 'text-emerald-400' :
          result ? 'text-red-400' : 'text-white'
        }`}>
          {displayNum !== null ? `${displayNum}x` : '—'}
        </div>

        {result && !rolling && (
          <div className={`text-center ${result.won ? 'text-emerald-400' : 'text-red-400'}`}>
            <p className="font-bold text-lg">
              {result.won
                ? `🎉 ${result.result}x ≥ ${t}x — Won ₹${result.payout?.toFixed(2)}`
                : `😔 ${result.result}x < ${t}x — Lost`}
            </p>
          </div>
        )}

        {/* Stats row */}
        <div className="grid grid-cols-3 gap-4 w-full pt-2 border-t border-white/5">
          {[
            { label: 'Win Chance', value: `${winChance}%`, color: 'text-amber-400' },
            { label: 'Target',     value: `${t}x`,         color: 'text-indigo-400' },
            { label: 'Payout',     value: `₹${potentialPayout}`, color: 'text-emerald-400' },
          ].map(s => (
            <div key={s.label} className="text-center">
              <p className="text-xs text-slate-500">{s.label}</p>
              <p className={`font-bold font-mono ${s.color}`}>{s.value}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Target input */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <div>
          <label className="text-xs font-semibold text-slate-400 uppercase tracking-wider block mb-2">
            Target Multiplier
          </label>
          <div className="flex items-center gap-2 bg-white/5 border border-white/10 rounded-xl px-3 py-2.5">
            <input
              type="number"
              value={target}
              onChange={e => setTarget(e.target.value)}
              onBlur={e => {
                const v = parseFloat(e.target.value);
                if (!isNaN(v) && v >= 1.01) setTarget(v.toFixed(2));
              }}
              step="0.1" min="1.01" max="1000000"
              disabled={loading || rolling || autoRunning}
              className="flex-1 bg-transparent text-white font-mono font-bold text-lg outline-none disabled:opacity-50"
              placeholder="2.00"
            />
            <span className="text-slate-400 text-sm font-bold">×</span>
          </div>
          <div className="flex gap-1.5 mt-2 flex-wrap">
            {PRESET_TARGETS.map(p => (
              <button key={p} onClick={() => setTarget(p.toString())}
                disabled={loading || rolling || autoRunning}
                className={`px-2.5 py-1 text-xs rounded-lg border transition-all ${
                  parseFloat(target) === p
                    ? 'bg-indigo-600 border-indigo-500 text-white'
                    : 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10 hover:text-white disabled:opacity-50'
                }`}>
                {p}x
              </button>
            ))}
          </div>
        </div>

        <BetInput value={bet} onChange={setBet} disabled={loading || rolling || autoRunning} />

        {/* Auto bet */}
        <div className="flex items-center gap-3">
          <label className="flex items-center gap-2 cursor-pointer">
            <div onClick={() => setAutoBet(a => !a)}
              className={`w-10 h-5 rounded-full transition-all ${autoBet ? 'bg-indigo-600' : 'bg-white/10'} relative`}>
              <div className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${autoBet ? 'left-5' : 'left-0.5'}`} />
            </div>
            <span className="text-sm text-slate-400">Auto Bet</span>
          </label>
          {autoBet && (
            <input type="number" value={autoCount} onChange={e => setAutoCount(e.target.value)}
              placeholder="Rounds (∞)" min="1"
              className="flex-1 bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-white placeholder-slate-500 outline-none"
            />
          )}
        </div>

        {autoRunning ? (
          <button onClick={stopAuto}
            className="w-full bg-red-600 hover:bg-red-500 text-white font-bold py-3 rounded-xl transition-all">
            Stop Auto Bet ⏹
          </button>
        ) : (
          <button
            onClick={autoBet ? startAuto : play}
            disabled={loading || rolling || isNaN(t) || t < 1.01 || !user || parseFloat(bet) > (user?.balance || 0)}
            className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all">
            {loading || rolling ? '🚀 Launching...' : autoBet ? '▶ Start Auto Bet' : 'Launch 🚀'}
          </button>
        )}
      </div>

      {/* History */}
      {history.length > 0 && (
        <div className="flex gap-2 flex-wrap">
          {history.map((h, i) => (
            <span key={i} className={`px-2.5 py-1 rounded-lg text-xs font-mono font-bold border ${
              h.won ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400'
                    : 'bg-red-500/20 border-red-500/30 text-red-400'
            }`}>
              {h.result}x
            </span>
          ))}
        </div>
      )}
    </div>
  );
}
