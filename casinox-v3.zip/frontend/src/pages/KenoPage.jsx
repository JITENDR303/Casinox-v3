import React, { useState } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const KENO_MULTS = {
  1:  [0,3.8], 2:[0,1,11], 3:[0,0.5,3,47], 4:[0,0,2,9,100],
  5:  [0,0,1.5,4,20,310], 6:[0,0,1,2,7,50,750],
  7:  [0,0,0.5,1.5,4,15,120,2500], 8:[0,0,0.5,1,3,9,50,500,10000],
  9:  [0,0,0,0.5,2,4,20,100,2000,25000], 10:[0,0,0,0.5,1.5,3.5,10,50,500,5000,100000],
};

export default function KenoPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet]         = useState('10');
  const [picks, setPicks]     = useState(new Set());
  const [drawn, setDrawn]     = useState([]);
  const [hits, setHits]       = useState([]);
  const [loading, setLoading] = useState(false);
  const [animating, setAnimating] = useState(false);
  const [result, setResult]   = useState(null);
  const [history, setHistory] = useState([]);

  const maxPicks = 10;

  const togglePick = (n) => {
    if (loading || animating) return;
    setPicks(prev => {
      const next = new Set(prev);
      if (next.has(n)) { next.delete(n); }
      else if (next.size < maxPicks) { next.add(n); }
      else toast.error('Maximum 10 numbers');
      return next;
    });
    setDrawn([]); setHits([]); setResult(null);
  };

  const play = async () => {
    if (picks.size === 0) return toast.error('Pick at least 1 number');
    if (loading) return;
    setLoading(true);
    setDrawn([]); setHits([]); setResult(null);

    try {
      const { data } = await API.post('/games/keno', {
        betAmount: parseFloat(bet),
        picks: Array.from(picks),
      });

      updateBalance(data.balance);
      setAnimating(true);

      // Animate numbers appearing one by one
      for (let i = 0; i < data.drawn.length; i++) {
        await new Promise(r => setTimeout(r, 80));
        setDrawn(prev => [...prev, data.drawn[i]]);
        if (picks.has(data.drawn[i])) {
          setHits(prev => [...prev, data.drawn[i]]);
        }
      }

      setResult(data);
      setAnimating(false);
      setHistory(h => [data, ...h].slice(0, 8));

      if (data.won) toast.success(`🎯 ${data.hits} hits! Won ₹${data.payout?.toFixed(2)} (${data.multiplier}x)!`);
      else toast.error(`😔 ${data.hits} hits — no win this round`);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Error');
      setAnimating(false);
    } finally { setLoading(false); }
  };

  const clearPicks = () => { setPicks(new Set()); setDrawn([]); setHits([]); setResult(null); };

  const quickPick = (count) => {
    const nums = Array.from({ length: 80 }, (_, i) => i + 1);
    for (let i = nums.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [nums[i], nums[j]] = [nums[j], nums[i]];
    }
    setPicks(new Set(nums.slice(0, count)));
    setDrawn([]); setHits([]); setResult(null);
  };

  const currentMults = KENO_MULTS[picks.size] || [];

  const numState = (n) => {
    const isPick  = picks.has(n);
    const isDrawn = drawn.includes(n);
    const isHit   = hits.includes(n);
    if (isHit)   return 'hit';
    if (isDrawn) return 'drawn';
    if (isPick)  return 'picked';
    return 'default';
  };

  const numStyle = {
    hit:     'bg-emerald-500 border-emerald-400 text-white scale-110 shadow-lg shadow-emerald-500/30',
    drawn:   'bg-slate-600/60 border-slate-500 text-slate-300',
    picked:  'bg-indigo-600 border-indigo-400 text-white',
    default: 'bg-white/5 border-white/10 text-slate-400 hover:bg-white/10 hover:text-white cursor-pointer',
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center gap-3">
        <span className="text-3xl">🎯</span>
        <div>
          <h1 className="text-2xl font-black text-white">Keno</h1>
          <p className="text-sm text-slate-400">Pick up to 10 numbers — 20 drawn from 80</p>
        </div>
      </div>

      {/* Number grid */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
        <div className="flex items-center justify-between mb-3">
          <span className="text-xs font-semibold text-slate-400">
            {picks.size}/{maxPicks} numbers selected
          </span>
          <div className="flex gap-2">
            {[3,5,7,10].map(n => (
              <button key={n} onClick={() => quickPick(n)}
                className="text-xs px-2 py-1 bg-white/5 hover:bg-indigo-600/30 border border-white/10 hover:border-indigo-500/30 text-slate-400 hover:text-indigo-300 rounded-lg transition-all">
                Quick {n}
              </button>
            ))}
            <button onClick={clearPicks}
              className="text-xs px-2 py-1 bg-white/5 hover:bg-red-500/20 border border-white/10 hover:border-red-500/30 text-slate-400 hover:text-red-400 rounded-lg transition-all">
              Clear
            </button>
          </div>
        </div>

        <div className="grid grid-cols-10 gap-1.5">
          {Array.from({ length: 80 }, (_, i) => i + 1).map(n => {
            const st = numState(n);
            return (
              <button key={n} onClick={() => togglePick(n)}
                disabled={loading || animating}
                className={`aspect-square rounded-lg border text-xs font-bold transition-all duration-200 ${numStyle[st]}`}>
                {n}
              </button>
            );
          })}
        </div>
      </div>

      {/* Result summary */}
      {result && (
        <div className={`text-center py-4 rounded-2xl border ${result.won ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-white/3 border-white/5'}`}>
          <p className={`text-xl font-black ${result.won ? 'text-emerald-400' : 'text-slate-400'}`}>
            {result.hits} hits out of {picks.size} picks
          </p>
          {result.won
            ? <p className="text-lg text-white font-bold">₹{result.payout?.toFixed(2)} won at {result.multiplier}x!</p>
            : <p className="text-sm text-slate-500">Better luck next round</p>}
        </div>
      )}

      {/* Controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={loading || animating} />

        {/* Payout preview */}
        {picks.size > 0 && (
          <div className="space-y-1.5">
            <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Payout Table ({picks.size} picks)</p>
            <div className="grid grid-cols-4 gap-1.5">
              {currentMults.map((m, hits_count) => m > 0 && (
                <div key={hits_count}
                  className={`flex justify-between px-2.5 py-1.5 rounded-lg text-xs border transition-all ${
                    result && result.hits === hits_count
                      ? 'bg-emerald-500/20 border-emerald-500/30 text-emerald-400'
                      : 'bg-white/5 border-white/5 text-slate-400'
                  }`}>
                  <span>{hits_count} hits</span>
                  <span className="font-bold">{m}x</span>
                </div>
              ))}
            </div>
          </div>
        )}

        <button onClick={play}
          disabled={loading || animating || picks.size === 0 || parseFloat(bet) > (user?.balance || 0)}
          className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:bg-white/10 disabled:text-slate-500 text-white font-bold py-3 rounded-xl transition-all">
          {animating ? '🎯 Drawing numbers...' : loading ? 'Processing...' : `Play Keno 🎯 (${picks.size} picks)`}
        </button>
      </div>

      {/* Recent history */}
      {history.length > 0 && (
        <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Recent Rounds</p>
          <div className="space-y-2">
            {history.map((h, i) => (
              <div key={i} className="flex items-center justify-between py-1.5">
                <span className="text-sm text-slate-300">{h.hits} hits / {h.drawn?.length} drawn</span>
                <span className={`text-sm font-bold font-mono ${h.won ? 'text-emerald-400' : 'text-red-400'}`}>
                  {h.won ? `+₹${h.payout?.toFixed(2)}` : 'No win'}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
