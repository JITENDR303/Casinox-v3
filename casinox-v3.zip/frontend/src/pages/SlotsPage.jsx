import React, { useState, useRef } from 'react';
import { API } from '../store';
import { useStore } from '../store';
import BetInput from '../components/UI/BetInput';
import toast from 'react-hot-toast';

const SYMBOLS = ['🍒', '🍋', '💎', '7️⃣', '⭐', '🔔', '🍇', '🎰'];
const PAYOUTS = { '🍒': 2, '🍋': 3, '💎': 10, '7️⃣': 20, '⭐': 5, '🔔': 4, '🍇': 3, '🎰': 50 };

function Reel({ symbols, spinning, delay = 0 }) {
  return (
    <div className="w-20 h-20 bg-[#0a0a15] border-2 border-white/10 rounded-xl overflow-hidden flex items-center justify-center relative">
      <div
        className={`flex flex-col items-center transition-all`}
        style={{
          animation: spinning ? `slotSpin 0.6s ${delay}s ease-out` : 'none',
        }}
      >
        <span className={`text-4xl select-none ${spinning ? 'blur-sm' : ''} transition-all duration-200`}>
          {symbols}
        </span>
      </div>
    </div>
  );
}

export default function SlotsPage() {
  const { user, updateBalance } = useStore();
  const [bet, setBet] = useState('10');
  const [spinning, setSpinning] = useState(false);
  const [displayReels, setDisplayReels] = useState([
    ['🎰', '🎰', '🎰'],
    ['🎰', '🎰', '🎰'],
    ['🎰', '🎰', '🎰'],
  ]);
  const [result, setResult] = useState(null);
  const [history, setHistory] = useState([]);
  const [totalWon, setTotalWon] = useState(0);
  const [totalSpins, setTotalSpins] = useState(0);

  const spin = async () => {
    if (spinning || !user) return;
    setSpinning(true);
    setResult(null);

    // Animate random symbols during spin
    const spinInterval = setInterval(() => {
      setDisplayReels([
        [SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]],
        [SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]],
        [SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)], SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)]],
      ]);
    }, 80);

    try {
      const { data } = await API.post('/games/slots', { betAmount: parseFloat(bet) });

      setTimeout(() => {
        clearInterval(spinInterval);
        setDisplayReels(data.reels);
        setSpinning(false);
        setResult(data);
        updateBalance(data.balance);
        setTotalSpins(s => s + 1);
        if (data.won) {
          setTotalWon(w => w + data.payout);
          toast.success(`🎰 Win! ${data.wins.map(w => w.symbol).join(' ')} — ₹${data.payout.toFixed(2)} (${data.totalMultiplier}x)!`);
        }
        setHistory(h => [{ won: data.won, payout: data.payout, mult: data.totalMultiplier }, ...h].slice(0, 10));
      }, 900);
    } catch (err) {
      clearInterval(spinInterval);
      setSpinning(false);
      toast.error(err.response?.data?.error || 'Spin failed');
    }
  };

  const winLines = result?.wins || [];
  const highlightedRows = new Set(winLines.filter(w => w.type === 'row').map(w => w.line));

  return (
    <div className="max-w-xl mx-auto space-y-6">
      <style>{`
        @keyframes slotSpin {
          0%   { transform: translateY(-30px); opacity: 0; }
          60%  { transform: translateY(4px); }
          100% { transform: translateY(0); opacity: 1; }
        }
      `}</style>

      <div className="flex items-center gap-3">
        <span className="text-3xl">🎰</span>
        <div>
          <h1 className="text-2xl font-black text-white">Slots</h1>
          <p className="text-sm text-slate-400">Match symbols across reels to win</p>
        </div>
      </div>

      {/* Slot machine */}
      <div className="bg-gradient-to-b from-[#1a0a2e] to-[#0a0a1a] border border-purple-900/40 rounded-3xl p-6 shadow-2xl">
        {/* Title bar */}
        <div className="text-center mb-5">
          <span className="text-sm font-black tracking-[0.3em] text-purple-400 uppercase">CasinoX Slots</span>
        </div>

        {/* Reels grid (3 cols × 3 rows) */}
        <div className="flex justify-center gap-3 mb-4">
          {[0, 1, 2].map(col => (
            <div key={col} className="flex flex-col gap-2">
              {[0, 1, 2].map(row => (
                <div
                  key={row}
                  className={`w-20 h-20 rounded-xl border-2 flex items-center justify-center text-4xl transition-all duration-300
                    ${spinning ? 'border-purple-500/50 bg-purple-900/20' : ''}
                    ${!spinning && result && highlightedRows.has(row)
                      ? 'border-amber-400 bg-amber-500/10 shadow-[0_0_12px_#f59e0b60]'
                      : !spinning ? 'border-white/10 bg-[#0a0a15]' : ''
                    }`}
                >
                  <span className={`${spinning ? 'blur-sm animate-pulse' : 'animate-none'} transition-all`}>
                    {displayReels[col]?.[row] || '🎰'}
                  </span>
                </div>
              ))}
            </div>
          ))}
        </div>

        {/* Win lines indicator */}
        <div className="flex justify-center gap-2 mb-2 h-6">
          {winLines.map((w, i) => (
            <div key={i} className="px-2 py-0.5 rounded-full bg-amber-500/20 border border-amber-500/30 text-xs text-amber-400 font-bold">
              {w.symbol} {w.mult}x
            </div>
          ))}
        </div>

        {/* Spin button */}
        <button
          onClick={spin}
          disabled={spinning || parseFloat(bet) > parseFloat(user?.balance || 0)}
          className={`w-full py-4 rounded-2xl font-black text-lg transition-all mt-3 ${
            spinning
              ? 'bg-purple-900/50 text-purple-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white shadow-lg hover:shadow-purple-500/25 active:scale-[0.98]'
          }`}
        >
          {spinning ? '🎰 Spinning...' : '🎰 SPIN'}
        </button>
      </div>

      {/* Result */}
      {result && !spinning && (
        <div className={`text-center py-4 rounded-2xl border ${result.won ? 'bg-amber-500/10 border-amber-500/30' : 'bg-white/3 border-white/5'}`}>
          {result.won ? (
            <>
              <p className="text-2xl font-black text-amber-400">🎉 Winner!</p>
              <p className="text-lg font-bold text-white">₹{result.payout.toFixed(2)} <span className="text-slate-400 text-sm">({result.totalMultiplier}x)</span></p>
            </>
          ) : (
            <p className="text-slate-400 text-sm">No winning lines. Try again!</p>
          )}
        </div>
      )}

      {/* Bet controls */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-5 space-y-4">
        <BetInput value={bet} onChange={setBet} disabled={spinning} />
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3">
        <div className="bg-white/3 border border-white/5 rounded-xl p-3 text-center">
          <p className="text-xs text-slate-500">Spins</p>
          <p className="font-bold text-white">{totalSpins}</p>
        </div>
        <div className="bg-white/3 border border-white/5 rounded-xl p-3 text-center">
          <p className="text-xs text-slate-500">Total Won</p>
          <p className="font-bold text-emerald-400 font-mono">₹{totalWon.toFixed(2)}</p>
        </div>
        <div className="bg-white/3 border border-white/5 rounded-xl p-3 text-center">
          <p className="text-xs text-slate-500">Best Hit</p>
          <p className="font-bold text-amber-400">{history.length ? Math.max(...history.map(h => h.mult)) + 'x' : '—'}</p>
        </div>
      </div>

      {/* Paytable */}
      <div className="bg-white/3 border border-white/5 rounded-2xl p-4">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-3">Paytable</p>
        <div className="grid grid-cols-4 gap-2">
          {Object.entries(PAYOUTS).sort((a, b) => b[1] - a[1]).map(([sym, mult]) => (
            <div key={sym} className="flex flex-col items-center gap-1 bg-white/5 rounded-xl p-2">
              <span className="text-2xl">{sym}</span>
              <span className="text-xs font-bold text-amber-400">{mult}x</span>
            </div>
          ))}
        </div>
        <p className="text-xs text-slate-500 mt-3 text-center">Diagonal wins pay 1.5x multiplier</p>
      </div>
    </div>
  );
}
