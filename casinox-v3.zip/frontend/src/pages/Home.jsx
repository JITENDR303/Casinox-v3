import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { API } from '../store';
import { useStore } from '../store';

const GAMES = [
  { path:'/crash',     name:'Crash',     emoji:'📈', desc:'Cash out before it crashes',    gradient:'from-red-600 to-orange-500',     hot:true },
  { path:'/mines',     name:'Mines',     emoji:'💣', desc:'Reveal gems, avoid mines',       gradient:'from-amber-600 to-yellow-500',    hot:true },
  { path:'/limbo',     name:'Limbo',     emoji:'🚀', desc:'Set target, win if result beats it', gradient:'from-indigo-600 to-violet-500', hot:true },
  { path:'/dice',      name:'Dice',      emoji:'🎲', desc:'Roll over or under your target', gradient:'from-blue-600 to-cyan-500' },
  { path:'/plinko',    name:'Plinko',    emoji:'🎯', desc:'Drop the ball, win big',         gradient:'from-violet-600 to-purple-500' },
  { path:'/hilo',      name:'HiLo',      emoji:'🃏', desc:'Predict higher or lower card',   gradient:'from-emerald-600 to-teal-500' },
  { path:'/tower',     name:'Tower',     emoji:'🏗️', desc:'Climb rows, avoid traps',       gradient:'from-orange-600 to-amber-500' },
  { path:'/keno',      name:'Keno',      emoji:'🎱', desc:'Pick numbers, watch the draw',   gradient:'from-cyan-600 to-blue-500' },
  { path:'/blackjack', name:'Blackjack', emoji:'🂡', desc:'Beat the dealer to 21',          gradient:'from-emerald-600 to-green-500' },
  { path:'/roulette',  name:'Roulette',  emoji:'🎡', desc:'European roulette table',        gradient:'from-pink-600 to-rose-500' },
  { path:'/slots',     name:'Slots',     emoji:'🎰', desc:'Spin the lucky reels',           gradient:'from-amber-500 to-yellow-400' },
  { path:'/wheel',     name:'Wheel',     emoji:'🎪', desc:'Spin to multiply your bet',      gradient:'from-cyan-600 to-blue-500' },
  { path:'/coinflip',  name:'Coin Flip', emoji:'🪙', desc:'Heads or tails — 1.98x',       gradient:'from-lime-600 to-green-500' },
];

export default function Home() {
  const { user, liveBets } = useStore();
  const [leaderboard, setLeaderboard] = useState([]);
  const [dailyClaimed, setDailyClaimed] = useState(false);
  const [claimingDaily, setClaimingDaily] = useState(false);

  useEffect(() => {
    API.get('/games/leaderboard').then(({ data }) => setLeaderboard(data.leaderboard || [])).catch(() => {});
  }, []);

  const claimDaily = async () => {
    setClaimingDaily(true);
    try {
      const { data } = await API.post('/wallet/daily-reward');
      setDailyClaimed(true);
      alert(`🎁 Claimed ₹${data.reward}! Streak: ${data.streak} days`);
    } catch (err) {
      alert(err.response?.data?.error || 'Already claimed today');
    } finally { setClaimingDaily(false); }
  };

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-indigo-900/50 via-purple-900/30 to-slate-900 border border-white/10 p-8">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage:'radial-gradient(circle at 70% 50%, #6366f1 0%, transparent 60%)' }} />
        <div className="relative">
          <p className="text-indigo-400 text-sm font-semibold mb-2">Welcome back, {user?.username} 👋</p>
          <h1 className="text-3xl font-black text-white mb-2">Play & Win <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 to-purple-400">Big</span></h1>
          <p className="text-slate-400 mb-5">Provably fair • 13 games • Instant withdrawals</p>
          <div className="flex gap-3 flex-wrap">
            <Link to="/crash" className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition-colors">Play Crash 📈</Link>
            <Link to="/wallet" className="bg-white/10 hover:bg-white/20 text-white px-5 py-2.5 rounded-xl font-semibold text-sm transition-colors">Deposit 💰</Link>
            <button onClick={claimDaily} disabled={claimingDaily || dailyClaimed}
              className="bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/30 text-amber-400 px-5 py-2.5 rounded-xl font-semibold text-sm transition-colors disabled:opacity-50">
              {dailyClaimed ? '✅ Claimed' : claimingDaily ? '...' : '🎁 Daily Reward'}
            </button>
          </div>
        </div>
      </div>

      {/* Stats bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {[
          { label:'Your Balance', value:`₹${parseFloat(user?.balance||0).toFixed(2)}`,  icon:'💰', color:'text-emerald-400' },
          { label:'Total Wagered',value:`₹${parseFloat(user?.totalWagered||0).toFixed(0)}`, icon:'🎲', color:'text-blue-400' },
          { label:'Total Won',    value:`₹${parseFloat(user?.totalWon||0).toFixed(0)}`, icon:'🏆', color:'text-amber-400' },
          { label:'VIP Level',    value:`Level ${user?.vipLevel||0}`,                   icon:'⭐', color:'text-purple-400' },
        ].map(s => (
          <div key={s.label} className="bg-white/3 border border-white/5 rounded-xl p-4">
            <p className="text-xs text-slate-500 mb-1">{s.icon} {s.label}</p>
            <p className={`font-bold font-mono ${s.color}`}>{s.value}</p>
          </div>
        ))}
      </div>

      {/* Games grid */}
      <div>
        <h2 className="text-lg font-bold text-white mb-4">🎮 All Games</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {GAMES.map(game => (
            <Link key={game.path} to={game.path}
              className="relative group overflow-hidden bg-white/3 hover:bg-white/6 border border-white/5 hover:border-white/15 rounded-2xl p-4 transition-all duration-200 hover:-translate-y-0.5">
              {game.hot && <span className="absolute top-2.5 right-2.5 text-[9px] bg-red-500 text-white px-1.5 py-0.5 rounded-full font-black">HOT</span>}
              <div className={`w-11 h-11 rounded-xl bg-gradient-to-br ${game.gradient} flex items-center justify-center text-xl mb-3 group-hover:scale-110 transition-transform`}>
                {game.emoji}
              </div>
              <h3 className="font-bold text-white text-sm">{game.name}</h3>
              <p className="text-xs text-slate-500 mt-0.5 leading-snug">{game.desc}</p>
            </Link>
          ))}
        </div>
      </div>

      {/* Live feed + Leaderboard */}
      <div className="grid md:grid-cols-2 gap-6">
        <div>
          <h2 className="text-lg font-bold text-white mb-4">⚡ Live Bets</h2>
          <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
            {liveBets.length === 0 ? (
              <p className="text-slate-500 text-sm text-center py-8">Waiting for bets…</p>
            ) : (
              <div className="divide-y divide-white/5">
                {liveBets.slice(0,8).map((bet,i) => (
                  <div key={i} className="flex items-center justify-between px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-black">
                        {bet.username?.[0]?.toUpperCase()}
                      </div>
                      <div>
                        <p className="text-xs font-semibold text-white">{bet.username}</p>
                        <p className="text-[10px] text-slate-500 capitalize">{bet.game} • ₹{bet.bet}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className={`text-sm font-bold font-mono ${bet.won ? 'text-emerald-400':'text-red-400'}`}>
                        {bet.won?'+':''}₹{bet.payout?.toFixed(2)}
                      </p>
                      <p className="text-[10px] text-slate-500">{bet.multiplier}x</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div>
          <h2 className="text-lg font-bold text-white mb-4">🏆 Weekly Leaders</h2>
          <div className="bg-white/3 border border-white/5 rounded-2xl overflow-hidden">
            {leaderboard.length === 0 ? (
              <p className="text-slate-500 text-sm text-center py-8">No data yet</p>
            ) : (
              <div className="divide-y divide-white/5">
                {leaderboard.slice(0,6).map((e,i) => (
                  <div key={i} className="flex items-center justify-between px-4 py-3">
                    <div className="flex items-center gap-3">
                      <span className={`text-sm font-black w-5 ${i===0?'text-amber-400':i===1?'text-slate-300':i===2?'text-amber-600':'text-slate-500'}`}>{i+1}</span>
                      <div className="w-7 h-7 rounded-full bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center text-xs font-black">
                        {e.username?.[0]?.toUpperCase()}
                      </div>
                      <span className="text-sm font-medium text-white">{e.username}</span>
                    </div>
                    <span className="text-sm font-bold text-emerald-400 font-mono">+₹{parseFloat(e.totalProfit||0).toFixed(0)}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
