import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import { useStore } from './store';
import { useSocket } from './hooks/useSocket';
import Layout from './components/Layout/Layout';

// Pages
import Home          from './pages/Home';
import AuthPage      from './pages/AuthPage';
import DicePage      from './pages/DicePage';
import CrashPage     from './pages/CrashPage';
import SlotsPage     from './pages/SlotsPage';
import MinesPage     from './pages/MinesPage';
import CoinFlipPage  from './pages/CoinFlipPage';
import WheelPage     from './pages/WheelPage';
import PlinkoPage    from './pages/PlinkoPage';
import BlackjackPage from './pages/BlackjackPage';
import RoulettePage  from './pages/RoulettePage';
import TowerPage     from './pages/TowerPage';
import KenoPage      from './pages/KenoPage';
import LimboPage     from './pages/LimboPage';
import HiloPage      from './pages/HiloPage';
import WalletPage    from './pages/WalletPage';
import AdminPage     from './pages/AdminPage';
import LeaderboardPage from './pages/LeaderboardPage';
import ProfilePage   from './pages/ProfilePage';

function SocketInit() { useSocket(); return null; }

function Protected({ children, adminOnly = false }) {
  const { user } = useStore();
  if (!user) return <Navigate to="/auth" replace />;
  if (adminOnly && !['admin','moderator'].includes(user.role)) return <Navigate to="/" replace />;
  return children;
}

export default function App() {
  const { fetchUser, token } = useStore();
  useEffect(() => { if (token) fetchUser(); }, []);

  return (
    <BrowserRouter>
      <SocketInit />
      <Toaster position="top-right" toastOptions={{
        duration: 3000,
        style: { background:'#0f0f1a', border:'1px solid rgba(255,255,255,0.08)', color:'#e2e8f0', borderRadius:'14px', backdropFilter:'blur(12px)' },
        success: { iconTheme: { primary:'#10b981', secondary:'#0f0f1a' } },
        error:   { iconTheme: { primary:'#ef4444', secondary:'#0f0f1a' } },
      }} />
      <Routes>
        <Route path="/auth" element={<AuthPage />} />
        <Route path="/" element={<Protected><Layout /></Protected>}>
          <Route index       element={<Home />} />
          <Route path="dice"      element={<DicePage />} />
          <Route path="crash"     element={<CrashPage />} />
          <Route path="slots"     element={<SlotsPage />} />
          <Route path="mines"     element={<MinesPage />} />
          <Route path="coinflip"  element={<CoinFlipPage />} />
          <Route path="wheel"     element={<WheelPage />} />
          <Route path="plinko"    element={<PlinkoPage />} />
          <Route path="blackjack" element={<BlackjackPage />} />
          <Route path="roulette"  element={<RoulettePage />} />
          <Route path="tower"     element={<TowerPage />} />
          <Route path="keno"      element={<KenoPage />} />
          <Route path="limbo"     element={<LimboPage />} />
          <Route path="hilo"      element={<HiloPage />} />
          <Route path="wallet"    element={<WalletPage />} />
          <Route path="leaderboard" element={<LeaderboardPage />} />
          <Route path="profile"   element={<ProfilePage />} />
          <Route path="admin"     element={<Protected adminOnly><AdminPage /></Protected>} />
        </Route>
        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}
